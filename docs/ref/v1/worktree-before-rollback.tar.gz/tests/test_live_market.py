"""实时输入使用可控源与时钟；验证无网络时仍可复现交付、停止和故障。"""

from datetime import datetime, timezone
import subprocess
import sys

import pytest

from minbt import Strategy, replay, sim
from minbt.events import SessionEvent
from minbt.plugins.binance import live
from minbt.plugins.binance.live._freshness import Freshness, StaleMarketError
from minbt.plugins.binance.live._market import DataGapError, MarketInput, MarketMapper


BASE = datetime(2026, 1, 1, tzinfo=timezone.utc).timestamp()


class Clock:
    """墙钟与单调时间分开，可独立注入时间跳变和接收延迟。"""

    def __init__(self):
        self.utc = BASE
        self.mono = 0.0

    def time(self):
        return self.utc

    def monotonic(self):
        return self.mono

    def advance(self, seconds):
        self.utc += seconds
        self.mono += seconds


def kline(index, price, symbol="A", *, closed=True):
    close = int((BASE + (index + 1) * 60) * 1000) - 1
    data = {"E": close + 1, "k": {"s": symbol, "i": "1m", "x": closed, "t": close - 59999, "T": close,
                                        "o": str(price), "h": str(price), "l": str(price), "c": str(price),
                                        "v": "1", "q": str(price), "n": 1, "V": "0.5", "Q": str(price / 2)}}
    received = (close + 1) / 1000
    return MarketInput("kline", symbol, data, index, received, received, (index + 1) * 60, {})


class Source:
    """标准源工厂创建新对象，支持空闲、正常结束和明确故障。"""

    def __init__(self, events=(), clock=None, finish=True):
        self.events = events
        self.clock = clock or Clock()
        self.finish = finish
        self.stopped = self.closed = False

    def start(self, emit):
        self.emit = emit
        for item in self.events:
            emit(item if isinstance(item, SessionEvent) else SessionEvent("fixture", "market", item, received_at=item.received_at))
        if self.finish:
            emit(SessionEvent("fixture", "source_end", None))

    def observe(self, event):
        self.clock.utc = event.callback_utc
        self.clock.mono = event.callback_monotonic

    def check(self):
        pass

    def stop(self):
        self.stopped = True

    def close(self):
        self.closed = True


def exchange(source, symbols=("A",), **kwargs):
    return live.Exchange(symbols=symbols, interval="1m", environment="demo", _source_factory=lambda: source,
                         _utc=source.clock.time, _monotonic=source.clock.monotonic, **kwargs)


def test_same_strategy_and_sim_broker_have_identical_execution_under_both_clocks():
    # 三条可见价格手算：第二条 110 买入，第三条 120 估值，净收益 10。
    class Hold(Strategy):
        def on_bars(self, dt, bars):
            self.broker.order_target_size("A", 1)

    prices = (100, 110, 120)
    historical = replay.Exchange()
    historical.set_bars([{"dt": datetime.fromtimestamp(kline(i, p).data["k"]["T"] / 1000, timezone.utc),
                          "symbol": "A", "close": p} for i, p in enumerate(prices)])
    source = Source([kline(i, p) for i, p in enumerate(prices)])
    wall = exchange(source)
    brokers = []
    results = []
    for runner in (historical, wall):
        broker = sim.Broker(1000)
        brokers.append(broker)
        runner.add_strategy(Hold("hold", broker))
        results.append(runner.run())
    left, right = results
    assert [(f.qty, f.price, f.fee) for f in left.get_fills()] == [(f.qty, f.price, f.fee) for f in right.get_fills()]
    assert left.get_position_sizes() == right.get_position_sizes() == {"A": 1}
    assert left.get_total_pnl() == right.get_total_pnl()
    assert right.get_total_pnl().net_pnl == 10
    assert right.meta["clock"] == "wall" and right.meta["environment"] is None
    assert right.meta["market_environment"] == "demo" and not right.meta["uses_real_funds"]
    assert source.stopped and source.closed


def test_kline_alignment_waits_for_all_symbols_and_skips_open_and_duplicate_bars():
    mapper = MarketMapper(("A", "B"), "1m", 5, monotonic=lambda: 0)
    assert mapper.map(kline(0, 100, closed=False)) == []
    assert mapper.map(kline(0, 100)) == []
    assert mapper.map(kline(0, 100)) == []
    completed = mapper.map(kline(0, 200, "B"))
    assert len(completed) == 1 and [item.event.symbol for item in completed[0].items] == ["A", "B"]
    assert completed[0].dt.timestamp() == pytest.approx(BASE + 59.999)
    assert mapper.map(kline(0, 200, "B")) == []


def test_alignment_timeout_and_entire_missing_group_close_the_run():
    clock = Clock()
    mapper = MarketMapper(("A", "B"), "1m", 5, monotonic=clock.monotonic)
    mapper.map(kline(0, 100))
    clock.advance(5)
    with pytest.raises(DataGapError, match="alignment"):
        mapper.check_timeout()
    mapper = MarketMapper(("A",), "1m", 5, monotonic=clock.monotonic)
    mapper.arm_schedule(BASE)
    with pytest.raises(DataGapError, match="scheduled"):
        mapper.check_schedule(BASE + 66)


def test_same_millisecond_trade_and_books_remain_separate_and_ordered():
    mapper = MarketMapper(("A",), "1m", 5, monotonic=lambda: 0)
    payloads = [{"E": BASE * 1000, "p": str(p), "q": "1", "a": i, "m": False} for i, p in enumerate((10, 11))]
    batches = [mapper.map(MarketInput("agg_trade", "A", d, i, BASE, BASE, 0, {}))[0] for i, d in enumerate(payloads)]
    assert [b.items[0].event.data["price"] for b in batches] == [10, 11]
    assert batches[0].dt == batches[1].dt


def test_idle_source_still_checks_control_and_closes_resources():
    source = Source(finish=False)
    runner = exchange(source)
    runner.add_strategy(Strategy("idle", sim.Broker(1000)))
    actions = iter(("pause", "pause", "exit"))
    result = runner.run(control=lambda: next(actions), poll_interval=0.001)
    assert result.meta["status"] == "exited" and result.meta["step_count"] == 0
    assert source.stopped and source.closed


def test_source_failure_propagates_original_exception_and_closes_everything():
    error = RuntimeError("SDK wait failed")
    source = Source([SessionEvent("fixture", "source_error", error)], finish=False)
    runner = exchange(source)
    runner.add_strategy(Strategy("failed", sim.Broker(1000)))
    with pytest.raises(RuntimeError) as caught:
        runner.run()
    assert caught.value is error
    assert error.partial_result.meta["status"] == "failed"
    assert source.closed


@pytest.mark.parametrize("business_failure", [False, True])
def test_cleanup_failure_keeps_partial_result_and_original_business_error(business_failure):
    original = ValueError("source failed")
    closing = RuntimeError("source close failed")

    class Broken(Source):
        def close(self):
            self.closed = True
            raise closing

    events = [SessionEvent("fixture", "source_error", original)] if business_failure else [kline(0, 100)]
    source = Broken(events)
    runner = exchange(source)
    runner.add_strategy(Strategy("close-errors", sim.Broker(1000)))
    with pytest.raises(type(original if business_failure else closing)) as caught:
        runner.run()
    error = caught.value
    assert error is (original if business_failure else closing)
    assert error.partial_result.meta["status"] == "failed"
    assert closing in error.cleanup_errors and source.closed


def test_gap_does_not_replay_late_signals():
    class Probe(Strategy):
        def on_init(self):
            self.bars = []

        def on_bars(self, dt, bars):
            self.bars.append(dt)

    source = Source([kline(0, 100), SessionEvent("fixture", "connection", {"gap": True}), kline(1, 110)])
    runner = exchange(source)
    strategy = Probe("gap", sim.Broker(1000))
    runner.add_strategy(strategy)
    with pytest.raises(DataGapError):
        runner.run()
    assert len(strategy.bars) == 1 and source.closed


def test_invalid_combinations_fail_before_source_creation():
    calls = []
    runner = live.Exchange(symbols=["A"], interval="1m", environment="demo", _source_factory=lambda: calls.append(1))
    runner.add_strategy(Strategy("bad", sim.Broker(1000, execution="legacy_immediate")))
    with pytest.raises(ValueError, match="legacy_immediate"):
        runner.run()
    assert calls == []


def test_importing_core_and_live_module_does_not_load_sdk():
    process = subprocess.run([sys.executable, "-c", "import sys; import minbt.replay, minbt.sim, minbt.protocols; assert 'minbt.plugins' not in sys.modules; import minbt.plugins.binance.live; assert not any(n == 'crypto_api' or n.startswith('crypto_api.') for n in sys.modules)"], capture_output=True, text=True)
    assert process.returncode == 0, process.stderr


@pytest.mark.parametrize("delay,queue_age,elapsed", [(30, 0, 0), (0, 30, 0), (3, 0, 3)])
def test_freshness_detects_network_delay_sdk_wait_and_combined_total_age(delay, queue_age, elapsed):
    clock = Clock()
    health = Freshness(("A",), utc=clock.time, monotonic=clock.monotonic)
    health.calibrate(BASE * 1000, BASE, BASE, 0, 0)
    event = MarketInput("mark_price", "A", {"E": (BASE - delay - queue_age) * 1000, "p": "100"},
                        1, BASE - queue_age, BASE, 0, {})
    if elapsed:
        health.observe(event)
        clock.advance(elapsed)
        with pytest.raises(StaleMarketError, match="stale"):
            health.check()
    else:
        with pytest.raises(StaleMarketError, match="stale"):
            health.observe(event)


def test_clock_jump_expired_calibration_and_future_events_cannot_open_gate():
    clock = Clock()
    health = Freshness(("A",), utc=clock.time, monotonic=clock.monotonic)
    health.calibrate(BASE * 1000, BASE, BASE, 0, 0)
    clock.utc += 1
    with pytest.raises(StaleMarketError, match="jumped"):
        health.check_clock()
    clock.utc -= 1
    clock.advance(61)
    with pytest.raises(StaleMarketError, match="expired"):
        health.check_clock()
    health.calibrate(clock.utc * 1000, clock.utc, clock.utc, clock.mono, clock.mono)
    event = MarketInput("mark_price", "A", {"E": (clock.utc + 30) * 1000}, 1, clock.utc, clock.utc, clock.mono, {})
    with pytest.raises(StaleMarketError, match="future"):
        health.observe(event)
