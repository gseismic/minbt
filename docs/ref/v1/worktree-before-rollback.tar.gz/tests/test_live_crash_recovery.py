"""实际子进程不执行 finally 退出，核对 SQLite 已提交阶段和未发送证明边界。"""

import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

from test_live_account import FakeSDK, session


_CHILD = r'''
import json
import os
from pathlib import Path
import sqlite3
import sys
from threading import Event
from test_live_account import FakeSDK, session

root, stage = Path(sys.argv[1]), sys.argv[2]
sdk = FakeSDK()
if stage == "accepted":
    original = sdk.submit_market_order
    def accepted(**payload):
        original(**payload)
        (root / "remote.json").write_text(json.dumps(sdk.remote, default=str))
        os._exit(23)
    sdk.submit_market_order = accepted
else:
    sdk.before_send, sdk.release = Event(), Event()

with session(root / "state", sdk=sdk) as (broker, account, sdk, events, permissions):
    order = broker.submit_market_order("BTCUSDT", 1)
    (root / "client.txt").write_text(order.client_order_id)
    if stage == "queued":
        os._exit(23)
    while True:
        event = events.get(timeout=3)
        if event.kind == "prepare_request":
            account.apply(event)
            break
    if stage == "accepted":
        Event().wait(5)
        raise AssertionError("transport did not exit the process")
    assert sdk.before_send.wait(3)
    if stage == "prepared":
        os._exit(23)
    permissions.revoke("pause")
    sdk.release.set()
    while True:
        event = events.get(timeout=3)
        if event.kind == "request_result":
            assert event.payload[1] == "not_sent"
            break
    if stage == "proof_failed":
        original_put = account.store.put
        def fail_proof(kind, key, value):
            if kind == "requests" and value["phase"] == "not_sent":
                raise sqlite3.OperationalError("injected disk full before not_sent commit")
            return original_put(kind, key, value)
        account.store.put = fail_proof
        try:
            account.apply(event)
        except sqlite3.OperationalError:
            os._exit(23)
        raise AssertionError("failed proof was accepted")
    account.apply(event)
    assert order.execution_state == "not_sent"
    os._exit(23)
'''


@pytest.mark.parametrize("stage", ["queued", "prepared", "accepted", "proof_failed", "proof_committed"])
def test_process_crash_never_replays_old_trading_request(tmp_path, stage):
    root = Path(__file__).resolve().parents[1]
    env = dict(os.environ, PYTHONPATH=os.pathsep.join((str(root), str(root / "tests"))))
    child = subprocess.run([sys.executable, "-c", _CHILD, str(tmp_path), stage], env=env,
                           capture_output=True, text=True, timeout=12)
    assert child.returncode == 23, child.stdout + child.stderr
    client = (tmp_path / "client.txt").read_text()
    remote_file = tmp_path / "remote.json"
    sdk = FakeSDK(json.loads(remote_file.read_text()) if remote_file.exists() else None)
    with session(tmp_path / "state", sdk=sdk) as (broker, account, sdk, _, _):
        assert not sdk.sent
        order = next(o for o in broker.get_orders() if o.client_order_id == client)
        if stage in ("queued", "proof_committed"):
            assert order.status == "canceled" and order.execution_state == "not_sent"
            assert client not in sdk.queries and account.ready
        elif stage == "accepted":
            assert order.status == "pending" and order.exchange_order_id is not None
            assert client in sdk.queries and account.ready
        else:
            assert order.status == "unknown" and not account.ready
            assert client in sdk.queries
