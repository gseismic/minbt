"""验证新默认成交因果关系、目标占用和所有环境统一的生命周期。"""

from dataclasses import FrozenInstanceError
from datetime import datetime, timedelta, timezone

import pytest

from minbt import Strategy
from minbt import replay, sim
from minbt.data import Bar
from minbt.data.replay import BatchItem, TimeBatch
from minbt.errors import IncompleteAccountingError
from minbt.result import _snapshot_account


def dt(i):
    return datetime(2026, 1, 1, tzinfo=timezone.utc) + timedelta(minutes=i)


def batch(i, symbol="A", close=100, kind="kline", **data):
    return TimeBatch(dt(i), (BatchItem("prices", 0, 0, i, Bar(dt(i), symbol, kind, dict(close=close, **data))),))


def run(strategy, rows=None, **options):
    exchange = replay.Exchange()
    exchange.set_bars(rows or [{"dt": dt(i), "symbol": "A", "close": p} for i, p in enumerate((100, 110, 120))])
    exchange.add_strategy(strategy)
    return exchange.run(**options)


def test_default_submit_is_pending_until_next_executable_symbol_event():
    # 旧缓存价、其他标的事件、手动再次扫描挂单都不能虚构新成交机会。
    broker = sim.Broker(1000)
    broker.process_market_batch(batch(0))
    order = broker.submit_market_order("A", 1)
    assert order.status == "pending" and broker.get_position_size("A") == 0
    broker.process_pending_orders()
    broker.process_market_batch(batch(1, symbol="B", close=500))
    assert order.status == "pending"
    broker.process_market_batch(batch(2, close=110))
    assert (order.status, order.avg_price, broker.get_position_size("A")) == ("filled", 110, 1)
    assert len(broker.get_fills()) == 1


def test_order_notifications_are_frozen_and_not_reentrant():
    class Probe(Strategy):
        def on_init(self):
            self.events = []
            self.in_callback = False

        def on_bars(self, current, bars):
            self.in_callback = True
            if current == dt(0):
                self.order = self.broker.submit_market_order("A", -1)
                assert not any(e[0] == "order" for e in self.events)
            self.events.append(("bar", current))
            self.in_callback = False

        def on_order(self, order):
            assert not self.in_callback
            self.events.append(("order", order))

        def on_fill(self, fill):
            assert not self.in_callback
            self.events.append(("fill", fill))

        def on_account(self, account):
            assert not self.in_callback
            assert self.broker.get_position_sizes() == dict(account.positions)

    strategy = Probe("probe", sim.Broker(1000, fee_rate=0.01))
    result = run(strategy)
    orders = [e[1] for e in strategy.events if e[0] == "order"]
    assert [o.status for o in orders] == ["pending", "filled"]
    assert orders[0].filled_qty == 0 and orders[1].filled_qty == -1
    with pytest.raises(FrozenInstanceError):
        orders[0].status = "filled"
    fill = result.get_fills()[0]
    assert (fill.qty, fill.price, fill.fee) == (-1, 110, 1.1)
    assert [e[0] for e in strategy.events[:4]] == ["bar", "order", "order", "fill"]


def test_target_occupancy_reuses_same_target_and_releases_after_cancel():
    broker = sim.Broker(1000)
    broker.process_market_batch(batch(0))
    order = broker.order_target_size("A", 2)
    assert broker.order_target_size("A", 2) is order
    for conflict in (broker.order_target_size("A", 3), broker.submit_market_order("A", 1), broker.close_position("A")):
        assert (conflict.status, conflict.reason_code) == ("rejected", "target_in_flight")
    assert broker.cancel_order(order.id) is order
    assert order.status == "canceled"
    replacement = broker.order_target_size("A", 3)
    broker.process_market_batch(batch(1))
    assert replacement.status == "filled" and broker.get_position_size("A") == 3


@pytest.mark.parametrize("method,args,options", [
    ("submit_market_order", ("A", 1), {"price": 99}),
    ("order_target_size", ("A", 1), {"price_dt": dt(0)}),
    ("order_target_percent", ("A", 0.2), {"leverage": 2}),
    ("order_target_value", ("A", 100), {"price": 99}),
    ("submit_limit_order", ("A", 1, 99), {"price_dt": dt(0)}),
])
def test_new_execution_rejects_old_override_options_without_side_effects(method, args, options):
    broker = sim.Broker(1000)
    broker.process_market_batch(batch(0))
    with pytest.raises(ValueError, match="legacy_immediate"):
        getattr(broker, method)(*args, **options)
    assert broker.get_orders() == [] and broker.get_last_price("A") == 100


def test_execution_source_is_explicit_and_separate_from_valuation_source():
    broker = sim.Broker(1000, execution_price="orderbook.bid")
    broker.process_market_batch(batch(0))
    order = broker.submit_market_order("A", 1)
    broker.process_market_batch(batch(1, close=105))
    assert order.status == "pending"
    broker.process_market_batch(batch(2, kind="orderbook", bid=101))
    assert order.avg_price == 101 and broker.get_last_price("A") == 105


def test_paused_fill_notifications_are_readonly_and_ready_is_called_once():
    class Probe(Strategy):
        def on_init(self):
            self.ready_count = 0
            with pytest.raises(RuntimeError, match="read-only"):
                self.broker.add_portfolio("forbidden", 100)

        def on_ready(self):
            self.ready_count += 1
            self.broker.submit_market_order("A", 1)

        def on_fill(self, fill):
            with pytest.raises(RuntimeError, match="read-only"):
                self.broker.submit_market_order("A", 1)

        def on_finish(self):
            with pytest.raises(RuntimeError, match="read-only"):
                self.broker.close_position("A")

    strategy = Probe("pause", sim.Broker(1000))
    actions = iter(("continue", "pause", "continue"))
    result = run(strategy, control=lambda: next(actions))
    assert strategy.ready_count == 1
    assert result.get_position_sizes() == {"A": 1}
    assert result.get_orders()[0].avg_price == 110


def test_pending_reservations_prevent_cross_symbol_overcommit():
    broker = sim.Broker(150)
    broker.process_market_batch(batch(0, "A"))
    broker.process_market_batch(batch(0, "B"))
    first = broker.submit_market_order("A", 1)
    assert first.status == "pending"
    assert broker.submit_market_order("B", 1).status == "rejected"
    broker.cancel_order(first.id)
    assert broker.submit_market_order("B", 1).status == "pending"


def test_incomplete_accounting_freezes_other_facts_and_does_not_keep_live_error():
    broker = sim.Broker(1000)
    broker.process_market_batch(batch(0))
    broker.submit_market_order("A", 1)

    def incomplete():
        raise IncompleteAccountingError(("fee_asset:BNB",))

    broker.get_total_pnl = incomplete
    frozen = _snapshot_account(broker, 1000, [], [])
    assert frozen.pnl is None and frozen.accounting_status == "incomplete"
    assert frozen.orders[0].status == "pending"
    broker.get_total_pnl = lambda: None
    assert frozen.accounting_issues == ("fee_asset:BNB",)


def test_history_limit_bounds_strategy_and_result_without_resetting_pnl():
    class Hold(Strategy):
        def on_ready(self):
            self.broker.submit_market_order("A", 1)

    strategy = Hold("bounded", sim.Broker(1000))
    result = run(strategy, history_limit=1)
    assert result.get_equity_curve() == [(dt(2), 1010)]
    assert result.get_total_pnl().net_pnl == 10
    assert strategy.get_hist_equity() == [1010]
    assert result.meta["history_truncated"]


def test_sim_partial_sell_accumulates_signed_quantity_weighted_price_and_fees():
    quantities = iter((-0.4, -0.6))
    broker = sim.Broker(1000, fee_rate=0.01, fill_quantity=lambda order, price, current: next(quantities))
    broker.process_market_batch(batch(0))
    order = broker.submit_market_order("A", -1)
    broker.process_market_batch(batch(1, close=110))
    assert (order.status, order.filled_qty, order.remaining_qty, order.avg_price) == ("partially_filled", -0.4, -0.6, 110)
    broker.process_pending_orders()  # 同一条执行行情不能再消费一次模型。
    broker.process_market_batch(batch(2, close=120))
    assert order.status == "filled" and order.filled_qty == -1 and order.remaining_qty == 0
    assert order.avg_price == pytest.approx(116)
    fills = broker.get_fills()
    assert [(f.qty, f.price) for f in fills] == [(-0.4, 110), (-0.6, 120)]
    assert len({f.id for f in fills}) == 2
    assert [f.fee for f in fills] == pytest.approx([0.44, 0.72])
    assert broker.get_total_pnl().fees == pytest.approx(1.16)
    assert broker.get_total_pnl().net_pnl == pytest.approx(-5.16)


def test_sim_partial_target_stays_occupied_and_cancel_releases_only_remaining_quantity():
    broker = sim.Broker(1000, fill_quantity=lambda order, price, current: min(0.4, order.remaining_qty))
    broker.process_market_batch(batch(0))
    order = broker.order_target_size("A", 1)
    broker.process_market_batch(batch(1))
    assert broker.order_target_size("A", 1) is order
    assert broker.order_target_size("A", 2).reason_code == "target_in_flight"
    assert broker.cancel_order(order.id) is order
    assert order.status == "canceled" and order.filled_qty == 0.4
    assert broker.get_position_size("A") == 0.4
    replacement = broker.order_target_size("A", 1)
    assert replacement.qty == pytest.approx(0.6)


def test_sim_partial_entry_exit_arms_after_first_fill_and_cancels_remaining_entry():
    def model(order, price, current):
        if order.source == "close_position":
            return order.remaining_qty
        return 0.4 if not order.filled_qty else 0

    broker = sim.Broker(1000, fee_rate=0.01, fill_quantity=model)
    broker.process_market_batch(batch(0))
    order = broker.submit_market_order("A", 1, stop_loss_price=95)
    broker.process_market_batch(batch(1))
    assert broker.get_exit(order.id).active and order.status == "partially_filled"
    broker.set_exit(order.id, stop_loss_price=96)
    broker.process_market_batch(batch(2, close=90))
    assert order.status == "canceled" and order.filled_qty == 0.4
    closing = next(o for o in broker.get_orders() if o.source == "close_position")
    assert closing.qty == -0.4 and closing.status == "pending"
    broker.process_market_batch(batch(3, close=90))
    assert closing.status == "filled" and broker.get_position_size("A") == 0
    assert broker.get_total_pnl().net_pnl == pytest.approx(-4.76)


def test_sim_reservation_after_partial_fill_uses_only_unfilled_remainder():
    broker = sim.Broker(150, fill_quantity=lambda order, price, current: min(0.4, order.remaining_qty))
    broker.process_market_batch(batch(0))
    broker.process_market_batch(batch(0, symbol="B", close=50))
    broker.submit_market_order("A", 1)
    broker.process_market_batch(batch(1))
    assert broker.get_position_size("A") == 0.4
    assert broker.submit_market_order("B", 1).status == "pending"


@pytest.mark.parametrize("qty", [2, -1, float("nan"), True])
def test_sim_bad_fill_model_cannot_change_financial_ledger(qty):
    broker = sim.Broker(1000, fill_quantity=lambda order, price, current: qty)
    broker.process_market_batch(batch(0))
    broker.submit_market_order("A", 1)
    with pytest.raises((TypeError, ValueError)):
        broker.process_market_batch(batch(1))
    assert broker.get_position_size("A") == 0 and broker.get_fills() == []
    assert broker.get_cash(include_locked=True) == 1000


def test_sim_fill_model_receives_immutable_order_and_zero_only_consumes_current_quote():
    seen = []

    def model(order, price, current):
        seen.append((price, current))
        with pytest.raises(FrozenInstanceError):
            order.qty = 100
        return 0 if len(seen) == 1 else order.remaining_qty

    broker = sim.Broker(1000, fill_quantity=model)
    broker.process_market_batch(batch(0))
    order = broker.submit_market_order("A", 1)
    broker.process_market_batch(batch(1))
    broker.process_pending_orders()
    assert len(seen) == 1 and order.status == "pending"
    broker.process_market_batch(batch(2))
    assert len(seen) == 2 and order.status == "filled"


def test_ready_callback_precedes_first_writable_account_notification():
    class Probe(Strategy):
        def on_init(self):
            self.ready_seen = False
            self.accounts = 0

        def on_ready(self):
            self.ready_seen = True

        def on_account(self, account):
            if account.ready:
                assert self.ready_seen
                self.accounts += 1

    strategy = Probe("ready-order", sim.Broker(1000))
    run(strategy)
    assert strategy.accounts >= 1


def test_notification_overflow_is_bounded_and_revokes_permission():
    from types import SimpleNamespace
    from minbt._runtime import Runtime
    from minbt.events import SessionEvent

    runtime = Runtime(SimpleNamespace(clock="wall"), [], queue_size=2)
    for _ in range(2):
        runtime.emit(None, SessionEvent("fixture", "on_fill", None))
    with pytest.raises(RuntimeError, match="notification overflow"):
        runtime.emit(None, SessionEvent("fixture", "on_fill", None))
    assert len(runtime.notifications) == 2 and not runtime.permissions.enabled


def test_sim_normalized_target_reuses_one_intent_before_and_after_partial_fill():
    from minbt import Market

    broker = sim.Broker(10000, market=Market(lot_size=1),
                        fill_quantity=lambda order, price, current: min(2, order.remaining_qty))
    broker.process_market_batch(batch(0))
    order = broker.order_target_size("A", 5.4)
    assert order.qty == 5 and broker.order_target_size("A", 5.9) is order
    broker.process_market_batch(batch(1))
    assert order.status == "partially_filled" and order.filled_qty == 2
    assert broker.order_target_size("A", 5.4) is order
    assert broker.order_target_size("A", 5.9) is order
