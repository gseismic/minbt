"""原生保护用独立远端模型验证，只减仓在远端执行，不依赖本地撤单速度。"""

from copy import deepcopy
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from threading import Thread
from urllib.parse import parse_qs

import pytest

from minbt.errors import TradingPermissionError, UnsupportedCapabilityError
from test_live_account import APIError, FakeSDK, RequestOutcomeUnknownError, pump, session


class NativeSDK(FakeSDK):
    def __init__(self, remote=None):
        super().__init__(remote)
        self.remote.setdefault("algos", {})
        self.algo_queries = []
        self.reject_type = None
        self.unknown_create = self.unknown_cancel = False
        self.cancel_lost_before_execution = False
        self.wire_mutator = None
        self.last_entry_fill = None

    def _algo_send(self, payload, cancel=False):
        wire = {"clientAlgoId": payload["client_algo_id"]}
        if not cancel:
            wire.update(symbol=payload["symbol"], side=payload["side"], type=payload["type"],
                        triggerPrice=payload["trigger_price"], closePosition="true", workingType="MARK_PRICE")
        if self.wire_mutator is not None:
            self.wire_mutator(wire)
        self.guard.get()("trade.cancel_algo_order" if cancel else "trade.create_algo_order", wire)
        self.sent.append(("algo_cancel" if cancel else "algo_create", deepcopy(wire)))

    def submit_stop_loss_order(self, **payload):
        return self._algo_create(payload, "STOP_MARKET")

    def submit_take_profit_order(self, **payload):
        return self._algo_create(payload, "TAKE_PROFIT_MARKET")

    def _algo_create(self, payload, kind):
        assert set(payload) == {"symbol", "side", "trigger_price", "close_position", "working_type", "client_algo_id"}
        assert payload["close_position"] is True
        self._algo_send(dict(payload, type=kind))
        if self.reject_type == kind:
            raise APIError(-2021)
        row = {"algoId": len(self.remote["algos"]) + 100, "clientAlgoId": payload["client_algo_id"],
               "symbol": payload["symbol"], "algoType": "CONDITIONAL", "orderType": kind,
               "side": payload["side"], "positionSide": "BOTH", "workingType": "MARK_PRICE",
               "triggerPrice": payload["trigger_price"], "closePosition": True, "reduceOnly": False,
               "algoStatus": "NEW", "actualOrderId": ""}
        self.remote["algos"][payload["client_algo_id"]] = row
        if self.unknown_create:
            self.unknown_create = False
            raise RequestOutcomeUnknownError("algo response lost")
        return deepcopy(row)

    def cancel_algo_order(self, **payload):
        self._algo_send(payload, cancel=True)
        row = self.remote["algos"][payload["client_algo_id"]]
        if self.cancel_lost_before_execution:
            raise RequestOutcomeUnknownError("cancel timed out before execution")
        row["algoStatus"] = "CANCELED"
        if self.unknown_cancel:
            self.unknown_cancel = False
            raise RequestOutcomeUnknownError("cancel response lost")
        return deepcopy(row)

    def get_algo_order(self, *, client_algo_id):
        self.algo_queries.append(client_algo_id)
        if client_algo_id not in self.remote["algos"]:
            raise APIError(-2013)
        return deepcopy(self.remote["algos"][client_algo_id])

    def get_open_algo_orders(self):
        return [deepcopy(r) for r in self.remote["algos"].values() if r["algoStatus"] == "NEW"]

    def get_order(self, symbol, *, client_order_id=None, order_id=None):
        if order_id is not None:
            return deepcopy(next(r for r in self.remote["orders"].values() if r["orderId"] == order_id))
        return super().get_order(symbol, client_order_id=client_order_id)

    def cancel_order(self, **payload):
        if self.last_entry_fill is not None:
            qty, self.last_entry_fill = self.last_entry_fill, None
            self.fill(payload["client_order_id"], qty=qty)
        return super().cancel_order(**payload)

    def trigger(self, client, *, qty=None):
        row = self.remote["algos"][client]
        position = self.remote["position"]
        # 远端 closePosition 保证：空仓或减仓方向不符时不得生成开仓成交。
        eligible = position > 0 and row["side"] == "SELL" or position < 0 and row["side"] == "BUY"
        row["algoStatus"] = "FINISHED"
        if eligible:
            actual_client = "trigger-" + client
            actual_id = max((r["orderId"] for r in self.remote["orders"].values()), default=0) + 1
            actual = {"orderId": actual_id, "clientOrderId": actual_client, "symbol": row["symbol"],
                      "side": row["side"], "origQty": str(abs(position)), "executedQty": "0", "avgPrice": "0",
                      "type": "MARKET", "status": "NEW", "closePosition": True, "reduceOnly": True}
            self.remote["orders"][actual_client] = actual
            row["actualOrderId"] = str(actual_id)
            self.fill(actual_client, qty=str(abs(position)) if qty is None else qty, price=row["triggerPrice"])
        self.callback("user", {"e": "ALGO_UPDATE", "o": {"aid": row["algoId"]}})
        return row.get("actualOrderId")


def enter(broker, account, sdk, events, qty=1, **exits):
    order = broker.submit_market_order("BTCUSDT", qty, **exits)
    pump(account, events, lambda: order.execution_state == "accepted" and account.ready)
    sdk.fill(order.client_order_id, qty=str(abs(qty)))
    return order


def protected(tmp_path, qty=1):
    return session(tmp_path, sdk=NativeSDK(), exit_mode="native")


@pytest.mark.parametrize("qty,side", [(1, "SELL"), (-1, "BUY")])
def test_native_waits_for_position_and_sends_close_all_for_both_directions(tmp_path, qty, side):
    with protected(tmp_path) as (broker, account, sdk, events, _):
        order = broker.submit_market_order("BTCUSDT", qty, stop_loss_price=90, take_profit_price=110)
        pump(account, events, lambda: order.execution_state == "accepted" and account.ready)
        assert not sdk.remote["algos"]
        sdk.fill(order.client_order_id, qty="0.4")
        pump(account, events, lambda: account.ready and len(sdk.remote["algos"]) == 2)
        initial = set(sdk.remote["algos"])
        assert broker.get_exit_status(order.id)["status"] == "active"
        assert broker.get_exit(order.id).active
        sdk.fill(order.client_order_id, qty="0.6")
        pump(account, events, lambda: account.ready and order.status == "filled")
        assert set(sdk.remote["algos"]) == initial
        assert broker.get_position_size("BTCUSDT") == qty
        for kind, wire in sdk.sent:
            if kind == "algo_create":
                assert wire["type"] in ("STOP_MARKET", "TAKE_PROFIT_MARKET")
                assert wire["side"] == side and wire["closePosition"] == "true"
                assert not {"quantity", "reduceOnly"}.intersection(wire)


def test_native_rejects_trailing_and_bad_tick_before_entry_send(tmp_path):
    with protected(tmp_path) as (broker, _, sdk, _, _):
        with pytest.raises(UnsupportedCapabilityError):
            broker.submit_market_order("BTCUSDT", 1, trailing_stop_pct=0.05)
        with pytest.raises(ValueError, match="PRICE_FILTER"):
            broker.submit_market_order("BTCUSDT", 1, stop_loss_price="90.01")
        assert not sdk.sent
        pending = broker.order_target_size("BTCUSDT", 1)
        with pytest.raises(UnsupportedCapabilityError):
            broker.order_target_size("BTCUSDT", 1, trailing_stop_pct=0.05)
        assert broker.get_order(pending.id) is pending


def test_partial_protection_failure_does_not_reject_fill_or_flatten(tmp_path):
    with protected(tmp_path) as (broker, account, sdk, events, _):
        sdk.reject_type = "TAKE_PROFIT_MARKET"
        order = enter(broker, account, sdk, events, stop_loss_price=90, take_profit_price=110)
        pump(account, events, lambda: "BTCUSDT" in broker._protection.states and broker.get_exit_status(order.id)["status"] == "failed")
        assert order.status == "filled"
        assert broker.get_position_size("BTCUSDT") == 1
        assert len(sdk.remote["algos"]) == 1 and not account.ready
        assert not any(k == "cancel" for k, _ in sdk.sent)
        assert len([k for k, _ in sdk.sent if k == "create"]) == 1


def test_native_unknown_creation_queries_original_id_without_replacement(tmp_path):
    with protected(tmp_path) as (broker, account, sdk, events, _):
        sdk.unknown_create = True
        order = enter(broker, account, sdk, events, stop_loss_price=90)
        pump(account, events, lambda: account.ready and broker.get_exit_status(order.id)["status"] == "active")
        assert len(sdk.remote["algos"]) == 1
        client = next(iter(sdk.remote["algos"]))
        assert client in sdk.algo_queries
        assert len([1 for kind, _ in sdk.sent if kind == "algo_create"]) == 1


def test_native_replacement_keeps_old_protection_until_new_confirmed(tmp_path):
    with protected(tmp_path) as (broker, account, sdk, events, _):
        order = enter(broker, account, sdk, events, stop_loss_price=90)
        pump(account, events, lambda: account.ready)
        first = next(iter(sdk.remote["algos"]))
        broker.set_exit(order.id, stop_loss_price=95)
        assert broker.get_exit_status(order.id)["status"] == "updating"
        assert sdk.remote["algos"][first]["algoStatus"] == "NEW"
        pump(account, events, lambda: account.ready and len(sdk.remote["algos"]) == 2)
        kinds = [k for k, _ in sdk.sent if k.startswith("algo_")]
        assert kinds == ["algo_create", "algo_create", "algo_cancel"]
        assert sdk.remote["algos"][first]["algoStatus"] == "CANCELED"


@pytest.mark.parametrize("first_kind", ["STOP_MARKET", "TAKE_PROFIT_MARKET"])
def test_trigger_then_cancel_timeout_and_sibling_cannot_reopen_flat_position(tmp_path, first_kind):
    with protected(tmp_path) as (broker, account, sdk, events, permissions):
        order = enter(broker, account, sdk, events, stop_loss_price=90, take_profit_price=110)
        pump(account, events, lambda: account.ready)
        first = next(c for c, r in sdk.remote["algos"].items() if r["orderType"] == first_kind)
        sibling = next(c for c in sdk.remote["algos"] if c != first)
        sdk.cancel_lost_before_execution = True
        actual = sdk.trigger(first)
        pump(account, events, lambda: any(r.get("cancel_phase") == "unknown" for r in broker._protection.algos.values()))
        assert actual and broker.get_position_size("BTCUSDT") == 0
        assert not account.ready
        with pytest.raises(TradingPermissionError):
            broker.submit_market_order("BTCUSDT", 1)
        # 模拟另一侧在本地尚未确认撤销时自行触发，交易所 close-all 仍不能开仓。
        sdk.trigger(sibling)
        pump(account, events, lambda: account.ready)
        assert sdk.remote["position"] == 0 and broker.get_position_size("BTCUSDT") == 0
        assert order.status == "filled" and len(broker._fills) == 2
        permissions.open()
        assert broker.submit_market_order("BTCUSDT", 1).status == "pending"


def test_native_restart_keeps_original_prices_and_links_triggered_actual_order(tmp_path):
    with protected(tmp_path) as (broker, account, sdk, events, _):
        order = enter(broker, account, sdk, events, stop_loss_price=90, take_profit_price=110)
        pump(account, events, lambda: account.ready)
        remote = sdk.remote
        original = set(remote["algos"])
        life = broker.get_exit_status(order.id)["life_id"]
    second = NativeSDK(remote)
    with session(tmp_path, sdk=second, exit_mode="native") as (broker, account, sdk, events, _):
        assert account.ready
        assert set(remote["algos"]) == original and not second.sent
        assert broker.get_exit_status(order.id)["life_id"] == life
        sdk.trigger(next(iter(original)))
        pump(account, events, lambda: account.ready and broker.get_position_size("BTCUSDT") == 0)
        assert len(broker._fills) == 2
        assert not broker.get_health()["protection_issues"]


def test_native_restore_invalid_remote_contract_blocks_trading_without_cancel(tmp_path):
    with protected(tmp_path) as (broker, account, sdk, events, _):
        enter(broker, account, sdk, events, stop_loss_price=90)
        pump(account, events, lambda: account.ready)
        remote = sdk.remote
    next(iter(remote["algos"].values()))["closePosition"] = False
    second = NativeSDK(remote)
    with session(tmp_path, sdk=second, exit_mode="native") as (_, account, _, _, _):
        assert not account.ready and not second.sent


def test_add_reduce_and_clear_keep_prices_and_wait_for_remote_cancel_confirmation(tmp_path):
    with protected(tmp_path) as (broker, account, sdk, events, _):
        order = enter(broker, account, sdk, events, stop_loss_price=90, take_profit_price=110)
        pump(account, events, lambda: account.ready)
        clients = set(sdk.remote["algos"])
        enter(broker, account, sdk, events, qty=0.5)
        pump(account, events, lambda: account.ready)
        enter(broker, account, sdk, events, qty=-0.3)
        pump(account, events, lambda: account.ready)
        assert broker.get_position_size("BTCUSDT") == pytest.approx(1.2)
        assert set(sdk.remote["algos"]) == clients
        sdk.unknown_cancel = True
        broker.clear_exit(order.id)
        assert broker.get_exit_status(order.id)["status"] == "clearing" and not account.ready
        pump(account, events, lambda: account.ready)
        assert all(r["algoStatus"] == "CANCELED" for r in sdk.remote["algos"].values())
        assert broker.get_position_size("BTCUSDT") == pytest.approx(1.2)


def test_replacement_overlap_triggering_both_old_and_new_never_reverses_position(tmp_path):
    with protected(tmp_path) as (broker, account, sdk, events, _):
        order = enter(broker, account, sdk, events, stop_loss_price=90)
        pump(account, events, lambda: account.ready)
        broker.set_exit(order.id, stop_loss_price=95)
        pump(account, events, lambda: len(sdk.remote["algos"]) == 2)
        # 旧单的撤销尚未确认；在两张 close-all 都在交易所时让它们连续触发。
        for client in list(sdk.remote["algos"]):
            sdk.trigger(client)
        pump(account, events, lambda: account.ready)
        assert broker.get_position_size("BTCUSDT") == 0 and len(broker._fills) == 2


def test_native_trigger_cancels_entry_and_reduces_late_fill_from_cancel_race(tmp_path):
    with protected(tmp_path) as (broker, account, sdk, events, _):
        order = broker.submit_market_order("BTCUSDT", 1, stop_loss_price=90)
        pump(account, events, lambda: account.ready and order.execution_state == "accepted")
        sdk.fill(order.client_order_id, qty="0.4")
        pump(account, events, lambda: account.ready and len(sdk.remote["algos"]) == 1)
        sdk.last_entry_fill = "0.2"
        sdk.trigger(next(iter(sdk.remote["algos"])))
        pump(account, events, lambda: any(k == "create" and p.get("reduce_only") for k, p in sdk.sent))
        assert order.status == "canceled" and order.filled_qty == pytest.approx(0.6)
        assert broker.get_position_size("BTCUSDT") == pytest.approx(0.2)
        residual = next(o for o in broker.orders.values() if o.source == "close_position" and not o.is_done)
        pump(account, events, lambda: residual.execution_state == "accepted")
        sdk.fill(residual.client_order_id, qty="0.2", price="90")
        pump(account, events, lambda: account.ready and broker.get_position_size("BTCUSDT") == 0)
        assert len(broker._fills) == 4


def test_native_restart_after_offline_trigger_associates_actual_order_and_cleans_sibling(tmp_path):
    with protected(tmp_path) as (broker, account, sdk, events, _):
        enter(broker, account, sdk, events, stop_loss_price=90, take_profit_price=110)
        pump(account, events, lambda: account.ready)
        remote = sdk.remote
    # 模拟交易所在本地进程停机期间执行；旧进程不应用这批通知。
    sdk.trigger(next(iter(remote["algos"])))
    second = NativeSDK(remote)
    with session(tmp_path, sdk=second, exit_mode="native") as (broker, account, _, events, _):
        pump(account, events, lambda: account.ready)
        assert broker.get_position_size("BTCUSDT") == 0 and len(broker._fills) == 2
        assert [k for k, _ in second.sent] == ["algo_cancel"]
        assert all(r["algoStatus"] in ("FINISHED", "CANCELED") for r in remote["algos"].values())


@pytest.mark.parametrize("field,value", [("quantity", "1"), ("reduceOnly", "true"), ("side", "BUY"), ("closePosition", "false")])
def test_native_final_guard_rejects_mutated_wire_before_any_transport(tmp_path, field, value):
    with protected(tmp_path) as (broker, account, sdk, events, _):
        sdk.wire_mutator = lambda wire: wire.update({field: value})
        enter(broker, account, sdk, events, stop_loss_price=90)
        pump(account, events, lambda: any(r.kind == "protect" and r.phase == "not_sent" for r in account.requests.values()))
        assert not sdk.remote["algos"] and not any(k == "algo_create" for k, _ in sdk.sent)
        assert broker.get_position_size("BTCUSDT") == 1 and not account.ready


def test_actual_order_partial_fill_keeps_remaining_position_and_does_not_replace_prices(tmp_path):
    with protected(tmp_path) as (broker, account, sdk, events, _):
        enter(broker, account, sdk, events, stop_loss_price=90, take_profit_price=110)
        pump(account, events, lambda: account.ready)
        clients = set(sdk.remote["algos"])
        client = next(iter(clients))
        sdk.trigger(client, qty="0.4")
        pump(account, events, lambda: any(o.source == "close_position" and o.status == "partially_filled" for o in broker.orders.values()))
        assert broker.get_position_size("BTCUSDT") == pytest.approx(0.6)
        assert set(sdk.remote["algos"]) == clients
        sdk.fill("trigger-" + client, qty="0.6", price="90")
        pump(account, events, lambda: account.ready)
        assert broker.get_position_size("BTCUSDT") == 0 and len(broker._fills) == 3


@pytest.mark.parametrize("qty,side", [(1, "SELL"), (-1, "BUY")])
def test_native_sdk_http_payload_uses_close_all_and_rejects_mutually_exclusive_quantity(tmp_path, qty, side):
    usdm = pytest.importorskip("crypto_api.binance2.usdm")
    errors = pytest.importorskip("crypto_api.binance2.exceptions")
    captures = []
    remote_algos = {}

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            wire = {k: v[0] for k, v in parse_qs(self.rfile.read(int(self.headers["Content-Length"])).decode()).items()}
            captures.append(wire)
            row = {"algoId": len(captures), "clientAlgoId": wire["clientAlgoId"], "algoType": "CONDITIONAL",
                   "symbol": wire["symbol"], "side": wire["side"], "orderType": wire["type"], "positionSide": "BOTH",
                   "triggerPrice": wire["triggerPrice"], "closePosition": True, "reduceOnly": False,
                   "workingType": "MARK_PRICE", "algoStatus": "NEW", "actualOrderId": ""}
            remote_algos[row["clientAlgoId"]] = row
            body = json.dumps(row).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *_):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = Thread(target=server.serve_forever, kwargs={"poll_interval": 0.01}, daemon=True)
    thread.start()

    class HTTPNativeSDK(NativeSDK):
        def __init__(self):
            self.real = usdm.Broker(api_key="fixture-key", api_secret="fixture-secret", environment="demo",
                                    endpoints=usdm.Endpoints(rest=f"http://127.0.0.1:{server.server_port}"))
            super().__init__()
            self.remote["algos"] = remote_algos

        @contextmanager
        def send_permission(self, check):
            with super().send_permission(check), self.real.api.send_permission(check):
                yield

        def _algo_create(self, payload, kind):
            method = self.real.submit_stop_loss_order if kind == "STOP_MARKET" else self.real.submit_take_profit_order
            return method(**payload)

        def close(self):
            self.real.api.close()
            super().close()

    sdk = HTTPNativeSDK()
    try:
        with session(tmp_path, sdk=sdk, exit_mode="native") as (broker, account, _, events, _):
            enter(broker, account, sdk, events, qty=qty, stop_loss_price=90, take_profit_price=110)
            pump(account, events, lambda: account.ready and len(captures) == 2)
            for wire in captures:
                assert wire["type"] in ("STOP_MARKET", "TAKE_PROFIT_MARKET")
                assert wire["side"] == side and wire["closePosition"] == "true"
                assert not {"quantity", "reduceOnly"}.intersection(wire)
            with pytest.raises(errors.ParameterError):
                sdk.real.submit_stop_loss_order("BTCUSDT", side, "90", qty="1", close_position=True)
            assert len(captures) == 2
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
