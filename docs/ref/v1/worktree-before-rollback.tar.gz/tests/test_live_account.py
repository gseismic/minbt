"""外部账户采用录制式 fake SDK，验证真实边界而不访问交易所或使用资金。"""

from contextlib import contextmanager
from contextvars import ContextVar
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from dataclasses import replace
from datetime import datetime, timezone
from decimal import Decimal
from queue import Empty, Queue
import sqlite3
from threading import Barrier, Event
import time
from types import SimpleNamespace

import pytest

from minbt.data import Bar, BatchItem, TimeBatch
from minbt.permissions import TradingPermissions
from minbt import Strategy
from minbt.errors import IncompleteAccountingError
from minbt.events import SessionEvent
from minbt.plugins.binance import live
from minbt.plugins.binance.live._market import MarketInput
from minbt.plugins.binance.live import Broker
from minbt.plugins.binance.live._rules import SymbolRules
from minbt.plugins.binance.live._state import StateStore
from minbt.protocols import RunContext


def rule(symbol="BTCUSDT"):
    return {"symbol": symbol, "contractType": "PERPETUAL", "marginAsset": "USDT", "quoteAsset": "USDT", "status": "TRADING",
            "pricePrecision": 8, "quantityPrecision": 8,
            "filters": [{"filterType": "PRICE_FILTER", "tickSize": "0.1", "minPrice": "0.1", "maxPrice": "1000000"},
                        {"filterType": "LOT_SIZE", "stepSize": "0.001", "minQty": "0.001", "maxQty": "1000"},
                        {"filterType": "MARKET_LOT_SIZE", "stepSize": "0.001", "minQty": "0.001", "maxQty": "1000"},
                        {"filterType": "MIN_NOTIONAL", "notional": "5"}]}


class RequestOutcomeUnknownError(Exception):
    """模拟 SDK 的已发送未知回执，故意不提供任何自动重发能力。"""


class APIError(Exception):
    def __init__(self, code):
        self.code = code


class FakeSDK:
    """远端账户和 SDK 公共边界的最小录制模型；本地 Broker 不修改这些余额或仓位。"""

    def __init__(self, remote=None):
        self.remote = remote if remote is not None else {"orders": {}, "fills": [], "incomes": [], "wallet": Decimal("1000"), "position": Decimal("0"), "entry": Decimal("0")}
        self.callback = self.connection = None
        self.closed = Event()
        self.sent = []
        self.queries = []
        self.guard = ContextVar("fake_send_permission", default=None)
        self.before_send = self.release = None
        self.unknown = False
        self.api = SimpleNamespace(
            send_permission=self.send_permission,
            market=SimpleNamespace(get_exchange_info=lambda: {"symbols": [rule()]}),
            account=SimpleNamespace(get_multi_assets_mode=lambda: {"multiAssetsMargin": False}),
        )

    def on_connection(self, callback):
        self.connection = callback

    def subscribe(self, kind, callback):
        assert kind == "user"
        self.callback = callback

    def start(self):
        pass

    def wait(self):
        self.closed.wait()

    def stop(self):
        self.closed.set()

    def close(self):
        self.closed.set()

    @contextmanager
    def send_permission(self, check):
        token = self.guard.set(check)
        try:
            yield
        finally:
            self.guard.reset(token)

    def _send(self, method, payload):
        if self.before_send is not None:
            self.before_send.set()
            if not self.release.wait(5):
                raise RuntimeError("fixture limiter stalled")
        callback = self.guard.get()
        assert callback is not None
        wire = {"symbol": payload["symbol"]}
        if method == "create":
            wire.update(newClientOrderId=payload["client_order_id"], quantity=payload["qty"], side=payload["side"])
            if payload.get("reduce_only"):
                wire["reduceOnly"] = "true"
        else:
            wire["origClientOrderId"] = payload["client_order_id"]
        callback("trade.create_order" if method == "create" else "trade.cancel_order", wire)
        self.sent.append((method, dict(payload)))

    def get_position_mode(self):
        return {"dualSidePosition": False}

    def get_symbol_config(self):
        return [{"symbol": "BTCUSDT", "marginType": "CROSSED", "leverage": "1"}]

    def get_account(self):
        return {"canTrade": True, "assets": [{"asset": "USDT", "walletBalance": str(self.remote["wallet"]), "availableBalance": str(self.remote["wallet"])}]}

    def get_positions(self):
        return [{"symbol": "BTCUSDT", "positionSide": "BOTH", "positionAmt": str(self.remote["position"]),
                 "entryPrice": str(self.remote["entry"]), "unRealizedProfit": "0"}]

    def get_open_orders(self):
        return [deepcopy(o) for o in self.remote["orders"].values() if o["status"] in ("NEW", "PARTIALLY_FILLED")]

    def get_open_algo_orders(self):
        return []

    def get_order(self, symbol, *, client_order_id):
        self.queries.append(client_order_id)
        if client_order_id not in self.remote["orders"]:
            raise APIError(-2013)
        return deepcopy(self.remote["orders"][client_order_id])

    def get_fills(self, symbol, *, from_id=None, start_time=None, limit=500):
        return [deepcopy(f) for f in self.remote["fills"] if (from_id is None or int(f["id"]) >= from_id) and (start_time is None or f["time"] >= start_time)][:limit]

    def get_income_history(self, *, start_time, limit):
        return [deepcopy(r) for r in self.remote["incomes"] if r["time"] >= start_time][:limit]

    def submit_market_order(self, **payload):
        return self._create(payload, "MARKET")

    def submit_limit_order(self, **payload):
        return self._create(payload, "LIMIT")

    def _create(self, payload, order_type):
        assert isinstance(payload["qty"], str)
        self._send("create", payload)
        remote = {"orderId": len(self.remote["orders"]) + 1, "clientOrderId": payload["client_order_id"],
                  "symbol": payload["symbol"], "side": payload["side"], "origQty": payload["qty"],
                  "executedQty": "0", "avgPrice": "0", "type": order_type, "status": "NEW"}
        self.remote["orders"][payload["client_order_id"]] = remote
        if self.unknown:
            self.unknown = False
            raise RequestOutcomeUnknownError("response lost after send")
        return deepcopy(remote)

    def cancel_order(self, **payload):
        self._send("cancel", payload)
        row = self.remote["orders"][payload["client_order_id"]]
        row["status"] = "CANCELED"
        return deepcopy(row)

    def fill(self, client_id, qty="1", price="100", fee="0.1", asset="USDT"):
        remote = self.remote["orders"][client_id]
        qty, price, fee = Decimal(qty), Decimal(price), Decimal(fee)
        signed = qty if remote["side"] == "BUY" else -qty
        previous = self.remote["position"]
        realized = (price - self.remote["entry"]) * min(abs(previous), qty) * (1 if previous > 0 else -1) if previous * signed < 0 else Decimal("0")
        self.remote["wallet"] += realized - (fee if asset == "USDT" else 0)
        self.remote["position"] += signed
        if previous == 0:
            self.remote["entry"] = price
        remote["executedQty"] = str(Decimal(remote["executedQty"]) + qty)
        remote["avgPrice"] = str(price)
        remote["status"] = "FILLED" if Decimal(remote["executedQty"]) == Decimal(remote["origQty"]) else "PARTIALLY_FILLED"
        now = int(time.time() * 1000)
        trade = {"id": len(self.remote["fills"]) + 1, "orderId": remote["orderId"], "symbol": "BTCUSDT",
                 "qty": str(qty), "price": str(price), "commission": str(fee), "commissionAsset": asset,
                 "realizedPnl": str(realized), "side": remote["side"], "time": now}
        self.remote["fills"].append(trade)
        compact = {"c": client_id, "i": remote["orderId"], "s": "BTCUSDT", "S": remote["side"],
                   "X": remote["status"], "x": "TRADE", "z": remote["executedQty"], "ap": remote["avgPrice"],
                   "l": str(qty), "L": str(price), "n": str(fee), "N": asset, "rp": str(realized), "t": trade["id"], "T": now}
        event = {"e": "ORDER_TRADE_UPDATE", "E": now, "o": compact}
        self.callback("user", event)
        self.callback("user", {"e": "ACCOUNT_UPDATE", "E": now, "a": {"B": [{"a": "USDT", "wb": str(self.remote["wallet"])}],
                              "P": [{"s": "BTCUSDT", "ps": "BOTH", "pa": str(self.remote["position"]), "ep": str(self.remote["entry"]), "up": "0"}]}})
        return event


@contextmanager
def session(tmp_path, sdk=None, **options):
    sdk = sdk or FakeSDK()
    broker = Broker(api_key="fixture-key", api_secret="fixture-secret", environment="demo", symbols=["BTCUSDT"],
                    account_id="fixture", state_dir=tmp_path, sdk_factory=lambda **cfg: sdk, **options)
    account = broker.create_session()
    events = Queue()
    permissions = TradingPermissions()
    context = RunContext("fixture-run", "wall", lambda: datetime.now(timezone.utc), permissions, {})
    try:
        account.start(context, events.put)
        mark(account, 100)
        permissions.open()
        yield broker, account, sdk, events, permissions
    finally:
        account.request_stop()
        account.close(2)


def mark(account, price):
    now = datetime.now(timezone.utc)
    event = Bar(now, "BTCUSDT", "mark_price", {"price": price})
    account.on_market(TimeBatch(event.dt, (BatchItem("mark_price", 0, 0, 1, event),)))


def pump(account, events, until, timeout=4):
    notifications = []
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        account.poll()
        if until():
            return notifications
        try:
            event = events.get(timeout=0.01)
        except Empty:
            continue
        if event.kind.startswith("on_"):
            notifications.append(event)
        else:
            account.apply(event)
        if account.ready:
            account.context.permissions.open()
    raise AssertionError(f"account did not converge: {dict(account.health())}")


def test_partial_fill_cancel_and_account_projection_do_not_double_book(tmp_path):
    with session(tmp_path) as (broker, account, sdk, events, _):
        order = broker.order_target_size("BTCUSDT", 1)
        assert order.status == "pending" and broker.get_position_size("BTCUSDT") == 0
        assert broker.order_target_size("BTCUSDT", 1) is order
        pump(account, events, lambda: bool(sdk.sent) and order.execution_state == "accepted")
        duplicate = sdk.fill(order.client_order_id, "0.4", fee="0.04")
        sdk.callback("user", duplicate)
        pump(account, events, lambda: account.ready and order.status == "partially_filled")
        assert broker.get_position_size("BTCUSDT") == 0.4
        assert broker.get_cash(include_locked=True) == pytest.approx(999.96)
        assert len(broker.get_fills()) == 1 and broker.get_total_pnl().fees == pytest.approx(0.04)
        broker.cancel_order(order.id)
        pump(account, events, lambda: order.status == "canceled" and account.ready)
        assert order.filled_qty == 0.4 and broker.get_position_size("BTCUSDT") == 0.4
        closed = broker.close_position("BTCUSDT")
        pump(account, events, lambda: closed.execution_state == "accepted")
        assert sdk.sent[-1][1]["reduce_only"] is True
        sdk.fill(closed.client_order_id, "0.4", price="120", fee="0.048")
        pump(account, events, lambda: account.ready and broker.get_position_size("BTCUSDT") == 0)
        assert broker.get_total_pnl().realized_pnl == 8
        assert broker.get_total_pnl().fees == pytest.approx(0.088)


def test_queued_stop_records_not_sent_without_calling_sdk(tmp_path):
    with session(tmp_path) as (broker, account, sdk, events, _):
        order = broker.submit_market_order("BTCUSDT", 1)
        account.request_stop()
        assert order.status == "canceled" and order.reason_code == "session_stopping"
        assert account.store.records("requests")[0][1]["phase"] == "not_sent"
        assert sdk.sent == []


@pytest.mark.parametrize("kind", ["create", "cancel"])
def test_final_send_gate_rejects_after_sdk_limiter_wait_and_preserves_cancel_target(tmp_path, kind):
    with session(tmp_path) as (broker, account, sdk, events, permissions):
        original = broker.submit_market_order("BTCUSDT", 1)
        if kind == "cancel":
            pump(account, events, lambda: original.execution_state == "accepted")
        sdk.before_send, sdk.release = Event(), Event()
        if kind == "cancel":
            broker.cancel_order(original.id)
        pump(account, events, sdk.before_send.is_set)
        sent_before = len(sdk.sent)
        permissions.revoke("pause")
        sdk.release.set()
        pump(account, events, lambda: any(row["phase"] == "not_sent" for _, row in account.store.records("requests")))
        assert len(sdk.sent) == sent_before
        if kind == "create":
            assert original.status == "canceled"
        else:
            assert original.status == "pending" and original.execution_state == "accepted"


def test_unknown_restart_queries_original_client_id_and_never_resubmits(tmp_path):
    remote = None
    with session(tmp_path) as (broker, account, sdk, events, _):
        sdk.unknown = True
        order = broker.submit_market_order("BTCUSDT", 1)
        client_id = order.client_order_id
        pump(account, events, lambda: any(row["phase"] == "unknown" for _, row in account.store.records("requests")))
        assert len(sdk.sent) == 1
        remote = sdk.remote
    recovered = FakeSDK(remote)
    with session(tmp_path, recovered) as (broker, account, sdk, events, _):
        assert client_id in sdk.queries
        assert sdk.sent == []
        assert broker.get_orders()[0].client_order_id == client_id
        assert broker.get_orders()[0].status == "pending"


def test_submission_persistence_failure_revokes_gate_before_any_send(tmp_path, monkeypatch):
    with session(tmp_path) as (broker, account, sdk, events, permissions):
        original = account.store.put

        def fail(kind, key, value):
            if kind == "requests":
                raise sqlite3.OperationalError("database or disk is full")
            return original(kind, key, value)

        monkeypatch.setattr(account.store, "put", fail)
        with pytest.raises(sqlite3.OperationalError):
            broker.submit_market_order("BTCUSDT", 1)
        assert not permissions.enabled and sdk.sent == [] and broker.get_orders() == []
        assert account.store.records("orders") == []
        monkeypatch.setattr(account.store, "put", original)


def test_state_directory_lock_binding_and_atomic_rollback(tmp_path):
    binding = {"account": "a", "environment": "demo"}
    store = StateStore(tmp_path, binding)
    try:
        with pytest.raises(RuntimeError, match="already used"):
            StateStore(tmp_path, binding)
        with pytest.raises(ValueError):
            with store.transaction():
                store.put("requests", "intent", {"qty": Decimal("0.1234567890123456789")})
                raise ValueError("crash before commit")
        assert store.get("requests", "intent") is None
    finally:
        store.close()
    with pytest.raises(RuntimeError, match="binding mismatch"):
        StateStore(tmp_path, {"account": "a", "environment": "mainnet"})


def test_precision_uses_filters_and_normalizes_targets_toward_zero():
    rules = SymbolRules(rule())
    assert rules.normalize_target(Decimal("-1.0009")) == Decimal("-1.000")
    assert rules.validate(Decimal("0.1001"), Decimal("100"), "market") == "quantity_step"
    assert rules.validate(Decimal("1"), Decimal("100.01"), "limit") == "price_tick"
    assert rules.validate(Decimal("0.01"), Decimal("100"), "market") == "min_notional"
    assert rules.validate(Decimal("0.01"), Decimal("100"), "market", reduce_only=True) is None


def test_local_trailing_threshold_and_exit_obligation_are_durable_during_pause(tmp_path):
    with session(tmp_path) as (broker, account, sdk, events, permissions):
        order = broker.submit_market_order("BTCUSDT", 1, trailing_stop_pct=0.05)
        pump(account, events, lambda: order.execution_state == "accepted")
        sdk.fill(order.client_order_id)
        pump(account, events, lambda: account.ready and broker.get_position_size("BTCUSDT") == 1)
        mark(account, 120)
        saved = account.store.get("protection", "BTCUSDT")
        assert Decimal(saved["anchor"]) == 120 and Decimal(saved["threshold"]) == 114
        permissions.revoke("pause")
        mark(account, 113)
        mark(account, 112)
        exits = [o for o in broker.get_orders() if o.source == "close_position"]
        assert len(exits) == 1
        saved = account.store.get("protection", "BTCUSDT")
        assert saved["status"] == "exiting" and saved["exit_order_id"] == exits[0].id
        assert account.store.records("requests")[-1][1]["controlled"] is True


def test_restart_never_resets_confirmed_trailing_threshold(tmp_path):
    with session(tmp_path) as (broker, account, sdk, events, permissions):
        order = broker.submit_market_order("BTCUSDT", 1, trailing_stop_pct=0.05)
        pump(account, events, lambda: order.execution_state == "accepted")
        sdk.fill(order.client_order_id)
        pump(account, events, lambda: account.ready and broker.get_position_size("BTCUSDT") == 1)
        mark(account, 120)
        remote = sdk.remote
    restarted = FakeSDK(remote)
    with pytest.raises(RuntimeError, match="protection_recovery_pending"):
        with session(tmp_path, restarted):
            pass
    store = StateStore(tmp_path, {"account_id": "fixture", "environment": "demo", "symbols": ("BTCUSDT",), "exit_mode": "local"})
    try:
        state = store.get("protection", "BTCUSDT")
        assert Decimal(state["threshold"]) == 114 and Decimal(state["anchor"]) == 120
        assert restarted.sent == []
    finally:
        store.close()


@pytest.mark.parametrize("fee_asset", ["USDT", "BNB"])
def test_live_run_processes_private_facts_without_another_bar_and_freezes_accounting(tmp_path, fee_asset):
    sdk = FakeSDK()

    class Source:
        """只发一次行情，后续所有运行进展必须由账户 worker 和私有流驱动。"""

        def start(self, emit):
            now, mono = time.time(), time.monotonic()
            close = int(now // 60 * 60000) - 1
            payload = {"E": int(now * 1000), "k": {"i": "1m", "x": True, "t": close - 59999, "T": close,
                       "o": "100", "h": "100", "l": "100", "c": "100", "v": "1", "q": "100", "n": 1, "V": "1", "Q": "100"}}
            for kind, data in (("mark_price", {"E": int(now * 1000), "p": "100"}), ("kline", payload)):
                emit(SessionEvent("fixture", "market", MarketInput(kind, "BTCUSDT", data, 1, now, now, mono, {}), received_at=now))

        def observe(self, event):
            pass

        def check(self):
            pass

        def stop(self):
            pass

        def close(self):
            pass

    class Hold(Strategy):
        def on_init(self):
            self.bars = self.ready_count = self.fills = 0
            self.injected = self.finished_sync = False

        def on_ready(self):
            self.ready_count += 1
            self.broker.submit_market_order("BTCUSDT", 1)

        def on_bars(self, dt, bars):
            self.bars += 1

        def on_order(self, order):
            if order.execution_state == "accepted" and not self.injected:
                self.injected = True
                sdk.fill(order.client_order_id, asset=fee_asset)
                sdk.remote["wallet"] += 2
                sdk.remote["incomes"].append({"tranId": 17, "symbol": "BTCUSDT", "asset": "USDT", "incomeType": "FUNDING_FEE", "income": "2", "time": int(time.time() * 1000)})

        def on_fill(self, fill):
            self.fills += 1

        def on_account(self, account):
            if account.ready and account.positions.get("BTCUSDT") == 1:
                self.finished_sync = True

    broker = Broker(api_key="k", api_secret="s", environment="demo", symbols=["BTCUSDT"], account_id="runtime",
                    state_dir=tmp_path, sdk_factory=lambda **cfg: sdk)
    runner = live.Exchange(symbols=["BTCUSDT"], interval="1m", environment="demo", _source_factory=Source)
    strategy = Hold("one-bar", broker)
    runner.add_strategy(strategy)
    started = time.monotonic()

    def control():
        if time.monotonic() - started > 4:
            raise AssertionError(f"private facts did not produce ready account: {dict(broker.get_health())}")
        return "exit" if strategy.finished_sync else "continue"

    result = runner.run(control=control, poll_interval=0.005, shutdown_timeout=1, history_limit=1, result_dir=tmp_path / "results")
    assert strategy.ready_count == strategy.bars == strategy.fills == 1
    assert result.get_position_sizes() == {"BTCUSDT": 1}
    assert result.get_orders()[0].status == "filled"
    assert result.get_initial_cash() == 1000
    assert result.get_cashflows()[0]["incomeType"] == "FUNDING_FEE"
    assert result.meta["state_dir"] == str(tmp_path.resolve())
    if fee_asset == "USDT":
        assert result.meta["pnl_complete"] is True
        assert result.get_total_pnl().funding_pnl == 2
        assert result.get_total_pnl().net_pnl == pytest.approx(1.9)
    else:
        assert result.meta["pnl_complete"] is False
        with pytest.raises(IncompleteAccountingError):
            result.get_total_pnl()
        broker._accounting_issues.clear()
        with pytest.raises(IncompleteAccountingError):
            result.get_total_pnl()  # 后续补账不会改变已冻结的不完整状态。


def test_missing_fee_is_not_fabricated_as_zero_and_rest_can_complete_trade(tmp_path):
    with session(tmp_path) as (broker, account, sdk, events, permissions):
        order = broker.submit_market_order("BTCUSDT", 1)
        pump(account, events, lambda: order.execution_state == "accepted")
        captured = []
        callback = sdk.callback
        sdk.callback = lambda kind, event: captured.append(event)
        sdk.fill(order.client_order_id)
        sdk.callback = callback
        raw = deepcopy(captured[0])
        raw["o"].pop("n")
        callback("user", raw)
        while True:
            event = events.get(timeout=1)
            if event.kind == "private":
                account.apply(event)
                break
        assert broker.get_fills() == []
        with pytest.raises(IncompleteAccountingError):
            broker.get_total_pnl()
        assert not permissions.enabled
        pump(account, events, lambda: account.ready and len(broker.get_fills()) == 1)
        assert broker.get_total_pnl().fees == pytest.approx(0.1)


def test_private_confirmed_fill_is_not_regressed_by_a_later_unknown_rpc_result(tmp_path):
    with session(tmp_path) as (broker, account, sdk, events, _):
        submit = sdk.submit_market_order

        def fill_before_lost_reply(**payload):
            submit(**payload)
            sdk.fill(payload["client_order_id"])
            raise RequestOutcomeUnknownError("reply lost after private fill")

        sdk.submit_market_order = fill_before_lost_reply
        order = broker.submit_market_order("BTCUSDT", 1)
        seen = []
        deadline = time.monotonic() + 3
        unknown_applied = False
        while time.monotonic() < deadline and not unknown_applied:
            event = events.get(timeout=1)
            if event.kind == "on_order":
                seen.append(event.payload.status)
            elif not event.kind.startswith("on_"):
                account.apply(event)
                unknown_applied = event.kind == "request_result" and event.payload[1] == "unknown"
        assert unknown_applied and order.status == "filled"
        pump(account, events, lambda: account.ready)
        assert order.filled_qty == 1 and len(broker.get_fills()) == 1
        assert broker.get_total_pnl().fees == pytest.approx(0.1)


def test_disconnected_private_source_cannot_be_reopened_by_a_rest_snapshot(tmp_path):
    with session(tmp_path) as (broker, account, sdk, events, permissions):
        old_snapshot = account._fetch_snapshot(account._query_plan())
        sdk.connection({"state": "disconnected", "gap": True})
        assert not permissions.enabled
        account._apply_snapshot(old_snapshot)
        assert not account.ready  # 尚未应用的断线事实已经通过代次使旧 REST 快照失效。
        while True:
            event = events.get(timeout=1)
            if event.kind == "private_connection":
                account.apply(event)
                break
        account._apply_snapshot(account._fetch_snapshot(account._query_plan()))
        assert not account.ready and broker.get_health()["reason"] == "private_disconnected"


def test_recovery_log_redacts_private_stream_credentials(tmp_path):
    store = StateStore(tmp_path, {"account": "fixture"})
    try:
        store.append("private", {"e": "listenKeyExpired", "listenKey": "sensitive-token"})
        store.put("sample", "nested", {"nested": {"api_secret": "sensitive-secret"}})
        assert store.get("sample", "nested")["nested"]["api_secret"] == "***"
        body = store.connection.execute("SELECT body FROM events WHERE kind='private'").fetchone()[0]
        assert "sensitive-token" not in body
    finally:
        store.close()


def test_broker_instance_can_only_be_claimed_by_one_concurrent_run(tmp_path):
    sdk = FakeSDK()
    broker = Broker(api_key="k", api_secret="s", environment="demo", symbols=["BTCUSDT"],
                    account_id="fixture", state_dir=tmp_path, sdk_factory=lambda **cfg: sdk)
    sessions = [broker.create_session(), broker.create_session()]
    barrier = Barrier(2)

    def start(candidate):
        context = RunContext("claim-run", "wall", lambda: datetime.now(timezone.utc), TradingPermissions(), {})
        barrier.wait(timeout=3)
        try:
            candidate.start(context, lambda event: None)
        except RuntimeError as exc:
            assert "already been used" in str(exc)
            return False
        try:
            assert broker._session is candidate and candidate.ready
            return True
        finally:
            candidate.request_stop()
            candidate.close(2)

    with ThreadPoolExecutor(max_workers=2) as pool:
        assert sorted(pool.map(start, sessions)) == [False, True]


@pytest.mark.parametrize("price", [0, -1, float("nan"), float("inf"), True])
def test_invalid_mark_price_revokes_permission_before_projection_changes(tmp_path, price):
    with session(tmp_path) as (broker, account, _, _, permissions):
        assert broker._prices["BTCUSDT"] == Decimal("100")
        with pytest.raises((TypeError, ValueError)):
            mark(account, price)
        assert not permissions.enabled and broker._prices["BTCUSDT"] == Decimal("100")


def test_periodic_rest_sync_recovers_silent_funding_without_another_market_event(tmp_path):
    with session(tmp_path, sync_interval=10, max_sync_age=20) as (broker, account, sdk, events, _):
        monotonic = [account._last_sync_mono]
        account._monotonic = lambda: monotonic[0]
        sdk.remote["wallet"] += Decimal("2")
        sdk.remote["incomes"].append({"incomeType": "FUNDING_FEE", "tranId": 1, "symbol": "BTCUSDT",
                                      "asset": "USDT", "income": "2", "time": int(time.time() * 1000)})
        monotonic[0] += 10
        account.poll()
        notifications = pump(account, events, lambda: broker.get_total_pnl().funding_pnl == 2 and account.ready)
        assert any(e.kind == "on_account" for e in notifications)
        assert broker.get_cash() == 1002


def test_account_sync_age_closes_final_send_gate_even_with_connected_private_stream(tmp_path):
    with session(tmp_path, sync_interval=10, max_sync_age=20) as (broker, account, sdk, events, permissions):
        monotonic = [account._last_sync_mono]
        account._monotonic = lambda: monotonic[0]
        order = broker.submit_market_order("BTCUSDT", 1)
        monotonic[0] += 21
        account.poll()
        assert not account.ready and not permissions.enabled
        assert not broker.get_health()["account_synced"]
        pump(account, events, lambda: order.is_done)
        assert order.execution_state == "not_sent" and not sdk.sent


def test_snapshot_pages_are_spooled_cashflow_cache_is_bounded_and_overlap_is_unique(tmp_path):
    with session(tmp_path) as (broker, account, sdk, _, _):
        account.context = replace(account.context, history_limit=10)
        initial = int(time.time() * 1000)
        sdk.remote["incomes"] = [{"incomeType": "FUNDING_FEE", "tranId": i + 1, "symbol": "BTCUSDT", "asset": "USDT",
                                  "income": "1", "time": initial + i} for i in range(2501)]
        sdk.remote["wallet"] += Decimal(2501)
        snapshot = account._fetch_snapshot(account._query_plan())
        facts = snapshot["facts"]
        assert not isinstance(facts, (list, tuple)) and not any(f.closed for f in facts.files.values())
        account._apply_snapshot(snapshot)
        assert all(f.closed for f in facts.files.values()) and not account._snapshots
        assert account.ready and len(broker.get_cashflows()) == 10
        assert broker.get_total_pnl().funding_pnl == 2501
        account._apply_snapshot(account._fetch_snapshot(account._query_plan()))
        assert broker.get_total_pnl().funding_pnl == 2501


def test_snapshot_failure_releases_spooled_pages(tmp_path):
    with session(tmp_path) as (_, account, sdk, _, _):
        def fail(**options):
            raise OSError("fixture unavailable")

        sdk.get_income_history = fail
        with pytest.raises(OSError):
            account._fetch_snapshot(account._query_plan())
        assert not account._snapshots


def test_reconcile_uses_transactional_fill_totals_without_scanning_full_history(tmp_path):
    with session(tmp_path) as (broker, account, sdk, events, _):
        order = broker.submit_market_order("BTCUSDT", 1)
        pump(account, events, lambda: order.execution_state == "accepted")
        sdk.fill(order.client_order_id)
        pump(account, events, lambda: account.ready)
        original = account.store.iter_records

        def bounded(kind):
            assert kind != "fills", "regular reconciliation must not scan the full fill journal"
            return original(kind)

        account.store.iter_records = bounded
        account._apply_snapshot(account._fetch_snapshot(account._query_plan()))
        assert account.ready and broker.get_position_size("BTCUSDT") == 1
        assert Decimal(account.store.get("fill_totals", "order:" + order.id)) == 1


def test_live_normalized_target_is_reused_after_partial_fill(tmp_path):
    with session(tmp_path) as (broker, account, sdk, events, _):
        order = broker.order_target_size("BTCUSDT", "1.2345")
        assert order.qty == 1.234 and broker.order_target_size("BTCUSDT", "1.2349") is order
        pump(account, events, lambda: order.execution_state == "accepted")
        sdk.fill(order.client_order_id, qty="0.4")
        pump(account, events, lambda: account.ready)
        assert broker.order_target_size("BTCUSDT", "1.2349") is order
        assert len([1 for kind, _ in sdk.sent if kind == "create"]) == 1
