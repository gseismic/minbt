"""使用公开契约独立实现 Exchange，不继承内置运行器、不调用私有运行函数。"""

from dataclasses import dataclass, fields
from datetime import datetime, timedelta, timezone
from types import MappingProxyType

import pytest

from minbt import Strategy, sim
from minbt.data import Bar
from minbt.events import SessionEvent
from minbt.permissions import TradingPermissions
from minbt.protocols import ExchangeProtocol, EventBrokerProtocol, OrderSnapshot, ResultProtocol, RunContext
from minbt.protocols.broker import BROKER_PROTOCOL_METHODS
from minbt.data import TimeBatch, BatchItem


@dataclass(frozen=True)
class PluginResult:
    """独立结果只持有数据，证明不要求使用内置账户冻结器。"""

    meta: object
    cash: float
    curve: tuple
    positions: tuple
    orders: tuple
    pnl: object

    def get_initial_cash(self, *, strategy_id=None):
        return self.cash

    def get_equity_curve(self, *, strategy_id=None):
        return list(self.curve)

    def get_position_curve(self, symbol, *, strategy_id=None):
        return [(dt, p.get(symbol, 0)) for (dt, _), p in zip(self.curve, self.positions)]

    def get_orders(self, *, strategy_id=None):
        return list(self.orders)

    def get_total_pnl(self, *, strategy_id=None):
        return self.pnl

    def get_position_sizes(self, *, strategy_id=None, portfolio=None):
        return dict(self.positions[-1])


class ProjectBroker:
    """项目自己的事件 Broker 门面，显式组合公开 sim 能力而不依赖 Binance。"""

    def __init__(self, budget):
        self.account = sim.Broker(budget)
        self.initial_cash = budget
        for name in BROKER_PROTOCOL_METHODS:
            setattr(self, name, getattr(self.account, name))

    def create_session(self):
        return self.account.create_session()

    def get_orders(self):
        return self.account.get_orders()

    def get_total_pnl(self):
        return self.account.get_total_pnl()


class ProjectExchange:
    """业务包独立运行器，公开 RunContext 和会话足够完成绑定、行情、控制与结果。"""

    clock = "virtual"

    def __init__(self, observations):
        self.observations = observations
        self.strategy = None
        self.current = None
        self.used = False

    def add_strategy(self, strategy):
        if self.used or self.strategy is not None:
            raise RuntimeError("one strategy per run")
        strategy.set_exchange(self)
        self.strategy = strategy

    def get_current_dt(self):
        return self.current

    def describe(self):
        return {"clock": self.clock, "project_source": "observations"}

    def run(self, *, end=None, control=None, history_limit="auto", result_dir=None):
        if self.used:
            raise RuntimeError("run is single use")
        self.used = True
        strategy = self.strategy
        account = strategy.broker
        permissions = TradingPermissions()
        notifications = []
        session = account.create_session()
        context = RunContext("independent-run", self.clock, self.get_current_dt, permissions, MappingProxyType(self.describe()))

        def emit(event):
            assert isinstance(event, SessionEvent)
            notifications.append(event)

        def drain():
            while notifications:
                event = notifications.pop(0)
                getattr(strategy, event.kind)(event.payload)

        curves, positions = [], []
        try:
            session.start(context, emit)
            with permissions.readonly("on_init"):
                strategy.on_init()
            first = True
            for batch in self.observations:
                if end is not None and batch.dt >= end:
                    break
                with permissions.readonly("control"):
                    action = "continue" if control is None else control()
                if action == "exit":
                    permissions.revoke("stopping")
                    break
                if action == "pause":
                    permissions.revoke("pause")
                self.current = batch.dt
                session.on_market(batch)
                if action == "continue" and session.ready:
                    permissions.open()
                    if first:
                        first = False
                        strategy.on_ready()
                    drain()
                    strategy.on_bars(batch.dt, {item.event.symbol: item.event.data for item in batch.items})
                    drain()
                else:
                    with permissions.readonly("pause"):
                        drain()
                curves.append((batch.dt, account.get_total_equity()))
                positions.append(dict(account.get_position_sizes()))
            permissions.revoke("stopping")
            session.request_stop()
            with permissions.readonly("on_finish"):
                drain()
                strategy.on_finish()
            orders = tuple(OrderSnapshot(**{f.name: getattr(o, f.name) for f in fields(OrderSnapshot)}) for o in account.get_orders())
            return PluginResult(MappingProxyType({"status": "completed"}), account.initial_cash, tuple(curves), tuple(positions), orders, account.get_total_pnl())
        finally:
            session.close(1)


@pytest.mark.parametrize("custom_broker", [False, True])
def test_independent_exchange_composes_with_public_event_broker(custom_broker):
    class Hold(Strategy):
        def on_init(self):
            self.events = []
            with pytest.raises(RuntimeError, match="read-only"):
                self.broker.submit_market_order("A", 1)

        def on_ready(self):
            self.broker.order_target_size("A", 1)

        def on_order(self, order):
            self.events.append(order.status)

        def on_fill(self, fill):
            self.events.append((fill.qty, fill.price))

    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    batches = []
    for i, price in enumerate((100, 110, 120)):
        dt = start + timedelta(minutes=i)
        batches.append(TimeBatch(dt, (BatchItem("project", 0, 0, i, Bar(dt, "A", "kline", {"close": price})),)))
    account = ProjectBroker(1000) if custom_broker else sim.Broker(1000)
    runner = ProjectExchange(batches)
    strategy = Hold("plugin", account)
    runner.add_strategy(strategy)
    assert isinstance(runner, ExchangeProtocol) and isinstance(account, EventBrokerProtocol)
    result = runner.run()
    assert isinstance(result, ResultProtocol)
    assert strategy.exchange is runner
    assert strategy.events == ["pending", "filled", (1, 110)]
    assert result.get_position_sizes() == {"A": 1}
    assert result.get_total_pnl().net_pnl == 10
    assert result.get_orders()[0].avg_price == 110
    with pytest.raises(RuntimeError, match="already"):
        account.create_session().start(RunContext("reuse", "virtual", runner.get_current_dt, TradingPermissions(), {}), lambda e: None)
