"""行情风险结算必须在任何真实状态提交之前拒绝盈亏溢出。"""

import copy
from dataclasses import asdict
from datetime import datetime, timezone

import pytest

from minbt import Bar, Broker
from minbt.broker.portfolio import Portfolio
from minbt.data.replay import BatchItem, TimeBatch


OLD_DT = datetime(2026, 10, 17, tzinfo=timezone.utc)
NEW_DT = datetime(2026, 10, 18, tzinfo=timezone.utc)


def _portfolio_state(portfolio):
    return copy.deepcopy((
        portfolio.last_prices, portfolio.last_prices_dt,
        portfolio.total_cash, portfolio.free_cash, portfolio.locked_cash, portfolio.bankrupt,
        {symbol: position.__dict__ for symbol, position in portfolio.positions.items()},
        portfolio._booked_pnl, portfolio.get_pnl_records(),
    ))


def _broker_state(broker):
    return copy.deepcopy((
        broker.last_prices, broker.last_price_dates, broker._last_market_dt,
        broker._order_seq, [asdict(order) for order in broker.get_orders()],
        broker._pending_order_ids, broker._pending_exit_params, broker._exit_states,
        broker.get_pnl_records(),
        {name: _portfolio_state(portfolio) for name, portfolio in broker.portfolios.items()},
    ))


def _seed_risk(submit, risk):
    """只用成功成交建立累计亏损，再准备强平或穿仓所需的真实仓位。"""
    submit("A", 1e308, 1.5)
    submit("A", -1e308, 0.5)
    if risk == "liquidation":
        submit("B", 5e307, 1)
        submit("B", -5e307, 2)
        submit("A", -1e308, 1)
        return 1.91
    submit("A", -1, 1)
    return 1e308


def _submit_portfolio(portfolio):
    def submit(symbol, qty, price):
        assert portfolio.submit_order(symbol, qty, price, price_dt=OLD_DT)
    return submit


def _submit_broker(broker, portfolio="main"):
    def submit(symbol, qty, price):
        order = broker.submit_market_order(symbol, qty, price=price, price_dt=OLD_DT, portfolio=portfolio)
        assert order.status == "filled"
    return submit


def _batch(prices):
    return TimeBatch(NEW_DT, tuple(
        BatchItem("prices", 0, 0, index, Bar(NEW_DT, symbol, "kline", {"close": price}))
        for index, (symbol, price) in enumerate(prices.items())
    ))


def _update_portfolio(portfolio, prices, batch):
    if batch:
        return portfolio.update_market_batch(prices, NEW_DT)
    assert len(prices) == 1
    symbol, price = next(iter(prices.items()))
    return portfolio.on_new_price(symbol, price, NEW_DT)


@pytest.mark.parametrize("mode", ["cross", "isolated"])
@pytest.mark.parametrize("risk", ["liquidation", "bankruptcy"])
@pytest.mark.parametrize("batch", [False, True])
def test_risk_symbol_overflow_preserves_complete_portfolio(mode, risk, batch):
    """价格和估值有限，但同标的累计已实现亏损溢出时不能先更新账户。"""
    portfolio = Portfolio(1.5e308, fee_rate=0, margin_mode=mode)
    price = _seed_risk(_submit_portfolio(portfolio), risk)
    position = portfolio.get_position("A")
    position.lock_size(abs(position.size), OLD_DT)
    before = _portfolio_state(portfolio)
    with pytest.raises(ValueError, match="realized_pnl must be finite"):
        _update_portfolio(portfolio, {"A": price}, batch)
    assert _portfolio_state(portfolio) == before
    assert portfolio.get_position("A") is position


@pytest.mark.parametrize("mode", ["cross", "isolated"])
@pytest.mark.parametrize("risk", ["liquidation", "bankruptcy"])
@pytest.mark.parametrize("entry", ["single", "batch", "order"])
def test_other_portfolio_overflow_precedes_broker_side_effects(mode, risk, entry):
    """后一个分仓溢出时，前一个分仓、Broker 行情、时钟和订单也不能变化。"""
    broker = Broker(1.6e308, margin_mode=mode, execution="legacy_immediate")
    broker.add_portfolio("sub", 1.5e308)
    price = _seed_risk(_submit_broker(broker, "sub"), risk)
    _submit_broker(broker)("A", -1, 1)
    positions = {name: portfolio.get_position("A") for name, portfolio in broker.portfolios.items()}
    before = _broker_state(broker)
    with pytest.raises(ValueError, match="realized_pnl must be finite"):
        if entry == "single":
            broker.on_new_price("A", price, NEW_DT)
        elif entry == "batch":
            broker.process_market_batch(_batch({"A": price}))
        else:
            broker.submit_market_order("A", 1e-308, price=price, price_dt=NEW_DT)
    assert _broker_state(broker) == before
    for name, position in positions.items():
        assert broker.portfolios[name].get_position("A") is position


@pytest.mark.parametrize("mode", ["cross", "isolated"])
@pytest.mark.parametrize("batch", [False, True])
def test_risk_portfolio_total_overflow_is_rejected(mode, batch):
    """各标的累计值分别有限，账户已实现盈亏合计溢出也必须提前拒绝。"""
    portfolio = Portfolio(1.5e308, fee_rate=0, margin_mode=mode)
    submit = _submit_portfolio(portfolio)
    submit("A", 8e307, 1.5)
    submit("A", -8e307, 0.5)
    submit("B", -1, 1)
    before = _portfolio_state(portfolio)
    with pytest.raises(ValueError, match="realized_pnl must be finite"):
        _update_portfolio(portfolio, {"B": 1.1e308}, batch)
    assert _portfolio_state(portfolio) == before


@pytest.mark.parametrize("scope", ["symbol", "portfolio"])
def test_isolated_settlement_adjustment_overflow_is_rejected(scope):
    """历史盈利抵消毛亏损后，单标的或账户累计结算调整仍可能单独溢出。"""
    portfolio = Portfolio(1000, fee_rate=0, margin_mode="isolated")
    submit = _submit_portfolio(portfolio)
    submit("A", -1, 1)
    portfolio.on_new_price("A", 1e308, OLD_DT)
    profit_symbol = "A" if scope == "symbol" else "B"
    loss_symbol = "A" if scope == "symbol" else "C"
    submit(profit_symbol, 1, 1)
    submit(profit_symbol, -1, 1e308)
    submit(loss_symbol, -1, 1)
    before = _portfolio_state(portfolio)
    with pytest.raises(ValueError, match="settlement_adjustment must be finite"):
        portfolio.on_new_price(loss_symbol, 1e308, NEW_DT)
    assert _portfolio_state(portfolio) == before


@pytest.mark.parametrize("batch", [False, True])
def test_remaining_unrealized_pnl_participates_in_risk_validation(batch):
    """已结算字段分别有限，但叠加保留仓位的浮亏后净盈亏求和仍可能溢出。"""
    portfolio = Portfolio(1e308, fee_rate=0, margin_mode="isolated")
    submit = _submit_portfolio(portfolio)
    submit("HISTORY", -1, 1)
    portfolio.on_new_price("HISTORY", 1e307, OLD_DT)
    submit("RISK", -1, 1)
    submit("REMAIN", 1e308, 1)
    portfolio.on_new_price("REMAIN", 0.15, OLD_DT)
    assert portfolio.get_position("REMAIN").margin_level > portfolio.min_margin_level
    before = _portfolio_state(portfolio)
    with pytest.raises(ValueError, match="net pnl must be finite"):
        _update_portfolio(portfolio, {"RISK": 1e308}, batch)
    assert _portfolio_state(portfolio) == before


def test_single_and_batch_preview_follow_actual_isolated_risk_scope():
    """调用者手动估值后，单价只检查该标的，批量仍须预检全部仓位。"""
    broker = Broker(1.5e308, margin_mode="isolated", execution="legacy_immediate")
    price = _seed_risk(_submit_broker(broker), "bankruptcy")
    portfolio = broker.portfolios["main"]
    portfolio.get_position("A").update_price_and_pnl(price, OLD_DT)
    broker.on_new_price("UNRELATED", 1, OLD_DT)
    assert broker.get_position_size("A") == -1
    before = _broker_state(broker)
    with pytest.raises(ValueError, match="realized_pnl must be finite"):
        broker.update_market_batch(_batch({"UNRELATED": 2}))
    assert _broker_state(broker) == before


@pytest.mark.parametrize("mode", ["cross", "isolated"])
def test_immediate_trade_bankruptcy_is_checked_before_trade(mode):
    """成交价与估值价不同时，成交后的即时穿仓记账也要在成交前检查。"""
    portfolio = Portfolio(1.5e308, fee_rate=0, margin_mode=mode)
    submit = _submit_portfolio(portfolio)
    submit("A", 1e308, 1.5)
    submit("A", -1e308, 0.5)
    submit("B", 5e307, 1)
    submit("B", -5e307, 3)
    before = _portfolio_state(portfolio)
    with pytest.raises(ValueError, match="realized_pnl must be finite"):
        portfolio.submit_order("A", 1e308, 1.7, leverage=10, price_dt=NEW_DT, mark_price=0.1)
    assert _portfolio_state(portfolio) == before


def test_new_margin_liquidation_is_checked_before_broker_order():
    """新订单增加总保证金触发全仓强平时，旧标的累计溢出不能留下新订单。"""
    broker = Broker(1.5e308, execution="legacy_immediate")
    submit = _submit_broker(broker)
    submit("A", 1e308, 1.5)
    submit("A", -1e308, 0.5)
    submit("B", 5e307, 1)
    submit("B", -5e307, 2)
    submit("A", -1e307, 1)
    broker.on_new_price("A", 10.1, OLD_DT)
    before = _broker_state(broker)
    with pytest.raises(ValueError, match="realized_pnl must be finite"):
        broker.submit_market_order("C", 9e307, price=1, price_dt=NEW_DT)
    assert _broker_state(broker) == before
    assert broker.get_position("C") is None


@pytest.mark.parametrize("mode", ["cross", "isolated"])
def test_late_position_overflow_does_not_partially_settle_batch(mode):
    """先处理的仓位能够正常穿仓，后处理仓位溢出时整批仍不得部分提交。"""
    portfolio = Portfolio(1.5e308, fee_rate=0, margin_mode=mode)
    submit = _submit_portfolio(portfolio)
    submit("FIRST", -1e-308, 1)
    price = _seed_risk(submit, "bankruptcy")
    before = _portfolio_state(portfolio)
    with pytest.raises(ValueError, match="realized_pnl must be finite"):
        portfolio.update_market_batch({"FIRST": 1e308, "A": price}, NEW_DT)
    assert _portfolio_state(portfolio) == before


def test_direct_bankruptcy_checks_all_records_before_first_write():
    """直接清零全仓时，后续标的汇总溢出不能先写入其他标的记账。"""
    portfolio = Portfolio(1.5e308, fee_rate=0)
    submit = _submit_portfolio(portfolio)
    submit("FIRST", -1e-308, 1)
    _seed_risk(submit, "bankruptcy")
    # 直接更新 Position 模拟调用者先估值、再显式执行账户破产结算。
    portfolio.get_position("FIRST").update_price_and_pnl(1e308, NEW_DT)
    portfolio.get_position("A").update_price_and_pnl(1e308, NEW_DT)
    before = _portfolio_state(portfolio)
    with pytest.raises(ValueError, match="realized_pnl must be finite"):
        portfolio.mark_bankrupt(NEW_DT)
    assert _portfolio_state(portfolio) == before


@pytest.mark.parametrize("mode", ["cross", "isolated"])
@pytest.mark.parametrize("batch", [False, True])
@pytest.mark.parametrize("risk", ["liquidation", "bankruptcy"])
def test_finite_extreme_risk_records_once_and_preserves_preview(mode, batch, risk):
    """接近上限但合法的结算仍能成功，预检不写账，重复行情不重复结算。"""
    broker = Broker(1.5e308, margin_mode=mode, execution="legacy_immediate")
    submit = _submit_broker(broker)
    submit("A", 5e307, 1.5)
    submit("A", -5e307, 0.5)
    submit("A", -1 if risk == "bankruptcy" else -1e308, 1)
    price = 1.1e308 if risk == "bankruptcy" else 1.91
    portfolio = broker.portfolios["main"]
    before = _broker_state(broker)
    portfolio._preview_mark_prices({"A": price}, batch=batch)
    assert _broker_state(broker) == before
    if batch:
        broker.update_market_batch(_batch({"A": price}))
    else:
        broker.on_new_price("A", price, NEW_DT)
    assert broker.get_position_size("A") == 0
    bankrupt = mode == "cross" and risk == "bankruptcy"
    assert portfolio.bankrupt is bankrupt
    assert broker.get_total_pnl().realized_pnl == pytest.approx(-1.6e308 if risk == "bankruptcy" else -1.41e308)
    assert broker.get_total_pnl().net_pnl == pytest.approx(broker.get_total_equity() - broker.initial_cash)
    records = broker.get_pnl_records()
    assert len(records) == (5 if bankrupt else 4)
    assert records[3].reason == risk and records[3].dt == NEW_DT
    assert portfolio.get_pnl_records() == records
    broker.on_new_price("A", price, NEW_DT)
    assert broker.get_pnl_records() == records
