"""真实 crypto_api SDK 经本机 HTTP/私有 WebSocket 接入完整 minbt 运行。"""

import asyncio
from contextlib import contextmanager
import json
from threading import Thread
import time
from urllib.parse import parse_qs

import pytest

from minbt import Strategy
from minbt.events import SessionEvent
from minbt.plugins.binance import live
from minbt.plugins.binance.live._market import MarketInput
from test_live_account import rule
from test_native_protection import NativeSDK


class OneMarket:
    """仅启动时提供行情，随后全部进展通过真实 SDK 私有流交付。"""

    def start(self, emit):
        now, mono = time.time(), time.monotonic()
        close = int(now // 60 * 60000) - 1
        kline = {"E": int(now * 1000), "k": {"i": "1m", "x": True, "t": close - 59999, "T": close,
                 "o": "100", "h": "100", "l": "100", "c": "100", "v": "1", "q": "100", "n": 1, "V": "1", "Q": "100"}}
        for kind, data in (("mark_price", {"E": int(now * 1000), "p": "100"}), ("kline", kline)):
            emit(SessionEvent("local", "market", MarketInput(kind, "BTCUSDT", data, 1, now, now, mono, {})))

    def observe(self, event):
        pass

    def check(self):
        pass

    def stop(self):
        pass

    def close(self):
        pass


@contextmanager
def venue():
    usdm = pytest.importorskip("crypto_api.binance2.usdm")
    web = pytest.importorskip("aiohttp.web")
    serve = pytest.importorskip("websockets.legacy.server").serve
    model = NativeSDK()
    model.guard.set(lambda endpoint, params: True)
    requests, users = [], set()
    loop = asyncio.new_event_loop()
    thread = Thread(target=loop.run_forever, daemon=True)
    thread.start()

    async def broadcast(event):
        for socket in tuple(users):
            await socket.send(json.dumps(event))

    async def user(socket):
        users.add(socket)
        try:
            await socket.wait_closed()
        finally:
            users.discard(socket)

    async def http(request):
        raw = request.query_string if request.method == "GET" else await request.text()
        data = {k: v[0] for k, v in parse_qs(raw).items()}
        method, path = request.method, request.path
        requests.append((method, path, data))
        if path.endswith("/time"):
            result = {"serverTime": int(time.time() * 1000)}
        elif path.endswith("/listenKey"):
            result = {"listenKey": "local-fixture"}
        elif path.endswith("/exchangeInfo"):
            result = {"symbols": [rule()]}
        elif path.endswith("/positionSide/dual"):
            result = model.get_position_mode()
        elif path.endswith("/multiAssetsMargin"):
            result = {"multiAssetsMargin": False}
        elif path.endswith("/symbolConfig"):
            result = model.get_symbol_config()
        elif path.endswith("/account"):
            result = model.get_account()
        elif path.endswith("/positionRisk"):
            result = model.get_positions()
        elif path.endswith("/openOrders"):
            result = model.get_open_orders()
        elif path.endswith("/openAlgoOrders"):
            result = model.get_open_algo_orders()
        elif path.endswith("/userTrades"):
            result = model.get_fills(data["symbol"], from_id=int(data["fromId"]) if "fromId" in data else None,
                                     start_time=int(data["startTime"]) if "startTime" in data else None, limit=int(data["limit"]))
        elif path.endswith("/income"):
            result = model.get_income_history(start_time=int(data["startTime"]), limit=int(data["limit"]))
        elif path.endswith("/order"):
            if method == "GET":
                result = model.get_order(data["symbol"], client_order_id=data.get("origClientOrderId"),
                                         order_id=int(data["orderId"]) if "orderId" in data else None)
            elif method == "DELETE":
                result = model.cancel_order(symbol=data["symbol"], client_order_id=data["origClientOrderId"])
            else:
                result = model._create({"symbol": data["symbol"], "side": data["side"], "qty": data["quantity"],
                                        "client_order_id": data["newClientOrderId"]}, data["type"])
        elif path.endswith("/algoOrder"):
            if method == "GET":
                result = model.get_algo_order(client_algo_id=data["clientAlgoId"])
            elif method == "DELETE":
                result = model.cancel_algo_order(client_algo_id=data["clientAlgoId"])
            else:
                assert data["closePosition"] == "true" and not {"quantity", "reduceOnly"}.intersection(data)
                result = model._algo_create({"symbol": data["symbol"], "side": data["side"], "trigger_price": data["triggerPrice"],
                                             "close_position": True, "working_type": data["workingType"],
                                             "client_algo_id": data["clientAlgoId"]}, data["type"])
        else:
            return web.json_response({"code": -1, "msg": "unsupported fixture route"}, status=400)
        return web.json_response(result)

    async def start():
        model.callback = lambda kind, event: asyncio.create_task(broadcast(event))
        app = web.Application()
        app.router.add_route("*", "/{path:.*}", http)
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "127.0.0.1", 0)
        await site.start()
        websocket = await serve(user, "127.0.0.1", 0)
        urls = usdm.Endpoints(rest=f"http://127.0.0.1:{site._server.sockets[0].getsockname()[1]}",
                              user_stream=f"ws://127.0.0.1:{websocket.sockets[0].getsockname()[1]}/private/ws")
        return runner, websocket, urls

    runner, websocket, urls = asyncio.run_coroutine_threadsafe(start(), loop).result(timeout=3)

    def invoke(method, *args, **kwargs):
        async def call():
            model.guard.set(lambda endpoint, params: True)
            return getattr(model, method)(*args, **kwargs)
        return asyncio.run_coroutine_threadsafe(call(), loop).result(timeout=3)

    try:
        yield usdm, urls, model, requests, invoke
    finally:
        async def close():
            websocket.close()
            await websocket.wait_closed()
            await runner.cleanup()
        asyncio.run_coroutine_threadsafe(close(), loop).result(timeout=3)
        loop.call_soon_threadsafe(loop.stop)
        thread.join(timeout=3)
        loop.close()


def test_real_sdk_http_private_ws_and_native_actual_order_complete_minbt_run(tmp_path):
    with venue() as (usdm, urls, model, requests, invoke):
        class Protected(Strategy):
            def on_init(self):
                self.entered = self.triggered = self.flat = False
                self.fills = []

            def on_ready(self):
                self.broker.submit_market_order("BTCUSDT", 1, stop_loss_price=90, take_profit_price=110)

            def on_order(self, order):
                if order.execution_state == "accepted" and not self.entered:
                    self.entered = True
                    invoke("fill", order.client_order_id)

            def on_fill(self, fill):
                self.fills.append((fill.qty, fill.price))

            def on_account(self, account):
                if account.ready and account.positions.get("BTCUSDT") == 1 and not self.triggered:
                    self.triggered = True
                    invoke("trigger", next(iter(model.remote["algos"])))
                elif self.triggered and account.ready and not account.positions:
                    self.flat = True

        broker = live.Broker(api_key="fixture-key", api_secret="fixture-secret", environment="demo", symbols=["BTCUSDT"],
                             account_id="http-ws", state_dir=tmp_path / "account", exit_mode="native",
                             sdk_factory=lambda **cfg: usdm.Broker(**cfg, endpoints=urls, read_retries=0, timeout=1))
        exchange = live.Exchange(symbols=["BTCUSDT"], interval="1m", environment="demo", _source_factory=OneMarket)
        strategy = Protected("sdk", broker)
        exchange.add_strategy(strategy)
        started = time.monotonic()

        def control():
            assert time.monotonic() - started < 10, dict(broker.get_health())
            return "exit" if strategy.flat else "continue"

        result = exchange.run(control=control, poll_interval=0.005, shutdown_timeout=2, result_dir=tmp_path / "results")
        assert strategy.fills == [(1, 100), (-1, 90)]
        assert result.get_position_sizes() == {} and len(result.get_fills()) == 2
        assert result.get_total_pnl().net_pnl == pytest.approx(-10.2)
        assert result.meta["account_synced"] and result.meta["protection_ready"]
        assert len([1 for method, path, _ in requests if method == "POST" and path.endswith("/order")]) == 1
        assert len([1 for method, path, _ in requests if method == "POST" and path.endswith("/algoOrder")]) == 2
        assert any(method == "DELETE" and path.endswith("/algoOrder") for method, path, _ in requests)
