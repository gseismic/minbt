"""完整结果在磁盘按需查询；内存窗口与旧会话冻结引用互不影响。"""

from datetime import datetime, timedelta, timezone

import pytest

from minbt import Strategy, replay, sim
from minbt._result_store import PersistentResult
from minbt.protocols import ResultProtocol


def experiment(directory=None, count=12, extra=None):
    class Trade(Strategy):
        def on_bars(self, dt, bars):
            self.broker.order_target_size("A", 0 if self.broker.get_position_size("A") else 1)

    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    broker = sim.Broker(1000)
    if extra is not None:
        describe = broker.describe
        broker.describe = lambda: dict(describe(), custom_metadata=extra)
    strategy = Trade("trade", broker)
    runner = replay.Exchange()
    runner.set_bars([{"dt": start + timedelta(minutes=i), "symbol": "A", "close": 100 + i} for i in range(count)])
    runner.add_strategy(strategy)
    result = runner.run(history_limit=2, result_dir=directory)
    return result, strategy, broker


def test_explicit_result_directory_keeps_full_queries_while_memory_is_bounded(tmp_path):
    result, strategy, broker = experiment(tmp_path)
    assert isinstance(result, PersistentResult) and isinstance(result, ResultProtocol)
    assert len(result.get_equity_curve()) == 12
    assert len(result.get_orders()) == 12
    assert len(result.get_fills()) == 11
    assert len(strategy.get_hist_equity()) == 2
    assert len(broker.get_orders()) <= 3 and len(broker.get_fills()) == 2
    assert len(broker.get_pnl_records()) == 2
    assert result.get_total_pnl() == broker.get_total_pnl()
    assert result.meta["history_truncated"]
    assert result.get_position_curve("A")[-1][1] == broker.get_position_size("A")


def test_default_result_only_returns_the_declared_window_without_losing_total_pnl():
    result, strategy, broker = experiment()
    assert len(result.get_equity_curve()) == len(strategy.get_hist_equity()) == 2
    assert len(result.get_orders()) <= 3
    assert result.get_total_pnl().net_pnl == broker.get_total_pnl().net_pnl
    assert result.meta["history_truncated"] and result.meta["retained_from"] == result.get_equity_curve()[0][0]


def test_persistent_result_reopens_without_live_objects_and_is_isolated_from_later_runs(tmp_path):
    first, _, broker = experiment(tmp_path)
    expected_curve, expected_orders = first.get_equity_curve(), first.get_orders()
    broker.orders.clear()
    opened = PersistentResult.open(tmp_path)
    assert opened.get_orders() == expected_orders
    assert opened.get_equity_curve() == expected_curve
    second, _, _ = experiment(tmp_path, count=15)
    assert second.meta["session_id"] != first.meta["session_id"]
    assert first.get_orders() == expected_orders and first.get_equity_curve() == expected_curve
    assert PersistentResult.open(tmp_path, session_id=first.meta["session_id"]).get_orders() == expected_orders
    with pytest.raises(ValueError, match="session_id"):
        PersistentResult.open(tmp_path)


def test_persistent_result_capability_errors_and_nested_metadata_remain_strict(tmp_path):
    result, _, _ = experiment(tmp_path)
    with pytest.raises(TypeError):
        result.meta["status"] = "changed"
    with pytest.raises(ValueError):
        result.get_orders(strategy_id="missing")


def test_plugin_metadata_with_date_like_keys_keeps_its_original_meaning(tmp_path):
    literal = {"$datetime": "provider-owned string", "$mapping": "another provider field"}
    result, _, _ = experiment(tmp_path, extra=literal)
    assert dict(result.meta["custom_metadata"]) == literal
    assert dict(PersistentResult.open(tmp_path).meta["custom_metadata"]) == literal
