# PLAN-070 实施交接（当前有效）

## 最新用户要求（优先于以下历史测试安排）

用户明确要求：“不要过分测试，在我认可代码后再测试”。**停止运行测试、lint、构建及其他自动验证，不继续扩展测试矩阵；先完成代码和文档供审阅，用户明确认可后才运行必要测试。** 当前无本任务运行中的测试进程；编辑器自己的 Ruff server 不属于本任务，未停止。
以下 17:23 的实现和待办记录已经落后：原生固定价保护、模拟部分成交、账户周期同步/时效门禁、分页临时文件与成交累计水位，以及资源清理错误的部分结果现已新增代码。最新工作区没有统一验收，不得声称全部测试通过。目标仍 active，不因测试需等待认可而擅自暂停整个代码任务。

更新：2026-10-23 17:23，Asia/Shanghai。执行者：Codex / GPT-6，精确模型 ID 未提供。

## 用户目标与状态

活跃 goal：**根据最新设计 docs/design/live-trading-20261023-design.md 实施代码**。
目标完整覆盖设计阶段 A–D；E 明确延期。原目标尚未完成，保持 active，不要用当前通过的子集替代完成标准。
本轮已取得实质代码进展，没有 genuine blocker；继续工作，不询问是否继续、不创建缩小后的 goal。
用户 AGENTS 要求中文计划/注释/文档，docs/dev 编号计划、review、测试与对应 OUTCOME。
已读并使用 api-design-zh、default-tech-stack-zh、PLAN-IMPL-REVIEW-COMMIT；不要启动子 agent（开发者禁止主动委派）。

优先读取：AGENTS.md、GOAL.md、设计第六版、docs/dev/PLAN-070-live-trading.md、对应 OUTCOME。
版本：minbt HEAD 76b6d7a70bedaebaeac7f0a090fdd479096568e6，分支 main，元数据仍为 0.1.1；新行为尚未发布。

## 已实施代码

- minbt/replay/exchange.py 为历史实现；minbt/exchange.py 是弃用别名，根 Broker/Exchange 也为同类弃用别名（移除窗口 0.3）。sim.Broker 直接复用核心 Broker。
- minbt/_runtime.py 共用生命周期、串行通知、只读、控制、结果、可选策略检查点；公共 protocols/exchange.py、protocols/live.py、events.py、permissions.py、errors.py。
- sim 默认 execution=next_event，下一条该标的执行报价成交；显式 legacy_immediate 保留旧经济模型，不恢复 on_init 写权限。旧数值测试和研究示例已显式选择 legacy；新 quickstart 使用新默认。
- Broker 目标占用、缓存报价不能成交、执行价格源可分离；Fill、AccountUpdate、新订单字段、funding_pnl 和旧插件兼容快照。
- Binance live/ 下 Exchange、_market、_source、_freshness：K 线对齐/去重、缺口停止、原始接收与事件年龄、SDK/本地积压和失败监测、无行情控制与有限关闭。
- live/broker.py 与 _account.py：独立 Decimal 外部账户、规则与模式校验、串行 worker 的准备握手、queued/dispatch_prepared/not_sent/unknown、最终发送授权、私有流事实/部分成交/账户投影、原 ID 查询恢复。
- _state.py SQLite WAL/FULL、目录锁/绑定、唯一事实、逐行恢复、认证字段脱敏；不写凭证。请求未发送撤单不改变原委托或占用。终态不被迟到 unknown RPC 回退。
- _protection.py 目前只有本地保护：配置/极值/阈值/触发义务与水位耐久保存，停机路径缺失时保留阈值并拒绝恢复。高点 120 / 5% 阈值 114 有验证。
- **native 尚未实现**：ProtectionManager.__init__ 明确抛 UnsupportedCapabilityError；不要仅删除此 guard 放开未验收功能。
- _result_store.py / 根导出 PersistentResult：可选 result_dir 完整日志、按会话截止冻结、按需列表与重新打开。策略/采样/可归档订单和明细有窗口；Pnl 累计账本不截断。
- result.py 专门处理 IncompleteAccountingError，保留其他事实。缺费用先存 pending_trades，REST 补齐后才生成 Fill，不伪造费用零。
- README、随包 skill、示例已开始迁移；docs/migration/0.2-event-execution.md 如实记录当前状态。最终文档与版本尚需完善。

## 验证

本轮基线 594 passed。最后一次涵盖当前生产代码的全量：

```bash
uv run --no-project python -m pytest -q --tb=short -W ignore::DeprecationWarning
# 643 passed in 44.85s
uv run --no-project ruff check minbt tests examples --output-format concise
# All checks passed!
git diff --check
# 通过
```

日志 /tmp/minbt-live-handoff-final.log。当前无运行中的测试进程或 SDK 会话。
新增测试：test_event_execution、test_live_market、test_live_account、test_public_event_plugin、test_persistent_result。
账户测试使用 fake SDK；完整 Exchange.run 测试只发一根 K 线，后续成交/资金费/on_account/退出由私有事实驱动。
没有使用任何真实凭证，没有向 demo/mainnet 发送订单。不能将本机测试称为完整实盘验收。

## 相邻 SDK 改动（必须保留）

/home/lsl/macbook/pai-studio-fin/library/crypto_api，基准 fbc4ab8ca8f70801592020c4c568e6e9182b1794，开始时干净，现有本轮未提交修改。
先遵守该仓库 AGENTS（已读 GOAL 与全部规范）；不提交/推送它，用户未明确授权。
新增公开 api.send_permission(check) 作用域，绑定 transport、单次最终发送，拒绝抛 RequestNotSentError；不是调用 SDK 前的一次布尔检查。
改动 exceptions.py、usdm/_send.py、rest/_base.py、_adapters/sdk.py、tests/binance2/test_send_permission.py，以及计划/结果/指南。
测试 54 passed、280 subtests passed（真实本机 HTTP/WS），Ruff/diff 通过。SDK 版本仍为 0.2.1 WORKTREE 扩展。
该仓库计划 docs/plans/PLAN-20261023-001-model-unknown-send-permission.md 及 OUTCOME 已完成。
本仓库 docs/integration/crypto-api-send-permission.patch 保存代码/测试补丁；在 crypto_api 中反向 git apply --check 已通过。
核心不加载插件或 SDK；插件模块导入也不加载 SDK。组件构造才校验依赖，联网归 run。

## 接下来必须完成（按原设计，不缩减范围）

1. 完善 C 审查/故障用例：真正进程崩溃的 queued / dispatch_prepared / not_sent 边界、未发送证明写失败、撤单未知、分页重叠/同毫秒/历史窗口、SDK 积压与最终门禁竞态、策略检查点恢复。
2. 目前 get_health 有 last_sync 但没有周期 REST 同步/同步年龄门禁；需审查补齐。private_connection 现已递增来源代次并参与启动屏障，旧 REST 快照不能越过未应用的断线事实。
补充审查候选（尚未用复现确认，不作为已完成修复）：live.Broker 的 _started 检查/赋值还缺少实例原子锁，需验证两个 Exchange 并发启动是否污染 broker._session；外部标记价的有限正数校验需独立验证；首次 ready 的 on_account/on_ready 交付顺序需按启动屏障核对。

3. _fetch_snapshot 仍汇总远端多页 fills/incomes 列表，需改成有界页交付；当前每次对账扫描全量 fills/requests，内存已逐行读但 CPU 随历史增长，应使用事务累计水位/汇总优化并验证。
4. 审查 late fill 与生命周期归属、归一化目标复用、被归档订单的晚到事实、cashflow 完整性和正常停止账目完整性；reconcile_error 当前只关闭同步，不一定标记完整盈亏缺口。
5. 补模拟可注入部分成交序列，验证 signed 累计量/均价/手续费/退出与目标占用。现有默认模拟只整笔成交；live 的部分成交已测。
6. 阶段 D 原生固定价保护：独立管理 algoId/clientAlgoId/actualOrderId，不能把 algo 回执送入普通 _order_fact。请求种类必须分支处理、持久化与恢复。
   - STOP_MARKET / TAKE_PROFIT_MARKET，close_position=True，省略 quantity/qty/reduce_only；多仓 SELL、空仓 BUY，实际 HTTP 载荷也要验。
   - on ACK 不能当已有仓位；实际持仓确认后建立保护。同生命周期仅数量变化不换单，修改触发价才更新。
   - 旧单未确认清理前拒绝新生命周期；双侧保护重叠、部分成功、超时、断线都不能反向开仓。不要靠本地及时撤另一侧来保证只减仓。
   - 持久化 life/version/方向/type/closePosition；恢复不合规或已有原生追踪单保持 recovery_pending，不擅自撤换。
   - AccountSession 当前拒绝所有远端 algo；实现时按归属核对，补触发实际订单的关联与 fills 解析。原生追踪仍明确拒绝，不能静默转 local。
   - Local 保护 manager 可复用纯状态逻辑；保护/恢复请求可用独立 controlled 授权，仍必须核对归属、当前仓位/生命周期、配置和时效，不能放宽普通策略门禁。
7. 结果/资源：完善清理失败的 partial_result/诊断、停止排空和 cutoff 故障测试，长运行压力与所有缓存/当前退出句柄的边界。
8. 全面同步 README/skill/例子/版本，真实本机 SDK HTTP/WS minbt 整链路；全部本机故障测试之后才进行 demo 集成（需用户授权与可用测试账户）。
9. 对照设计第 14 节 26 项逐项审计实际证据。当前只有部分步骤勾选，不能依据 643 green tests 标总体 complete。
10. 最终 review/修复/验证，更新最终 OUTCOME；按授权与用户原工作区边界处理提交/推送。原 goal 只有全部完成才 update_goal complete。

## 工作区与用户已有修改

用户开始前已有 HANDOFF、design/README、live-trading 设计、execution-cross-settlement、Broker/Portfolio 的 PLAN-069 修复，
以及未跟踪 BRAIN.md、GOAL.md、PLAN-069 计划/结果和 test_risk_pnl_overflow.py。
本轮没有回滚或提交这些。GOAL/BRAIN 未修改；设计正文未改。HANDOFF 当前新段前置，旧内容保留在下面。
Broker 已叠加本轮改动；Portfolio 没有本轮改动。test_risk_pnl_overflow 原有用例仅新增显式 legacy 参数以保留原经济模型验证。
不要 git add -A 混入用户既有内容。开始时备份 /tmp/minbt-live-baseline/{broker.py,portfolio.py,worktree.patch} 可用于区分 tracked 基线。
所有实施均未 commit / push，没有部署。

---

以下为实施前交接，保留作历史记录；其“尚未实施/从 A 开始”不再代表当前状态。

# minbt 实时交易设计与实施交接

更新时间：2026-10-23 15:11（Asia/Shanghai）。
编写者：Codex（基于 GPT-6；环境未提供精确模型 ID，记为 model-unknown）。
分析范围：WORKTREE；minbt 基准完整提交为 76b6d7a70bedaebaeac7f0a090fdd479096568e6，分支 main。
当前工作目录：/home/lsl/macbook/pai-studio-fin/library/minbt。

## 当前任务与交付边界

用户目标是 mini、低认知负荷、基于 K 线的量化交易框架，支持回测、实盘与插件二次开发。
先读根目录 [GOAL.md](GOAL.md) 和 [AGENTS.md](AGENTS.md)，再读本交接与 [实时交易设计稿](docs/design/live-trading-20261023-design.md)。

用户先要求审查设计，随后修订并要求复核，最后要求“为我补充，然后写交接文档”。
本轮完成设计补充和交接，未启动实时交易代码实施，未创建实施计划，未提交或推送，未连接交易账户。
下一步建议从设计阶段 A 开始；设计通过复核不代表实盘功能已经实现或验收。

本文件替换旧的 CSV / iosql 渐进加载交接。旧交接基于 2026-09 的代码和测试，
其中“下一步创建 PLAN-043”等指引已经过时；历史请看 [PLAN-042 结果](docs/dev/PLAN-042-csv-iosql-streaming-feed-OUTCOME.md)
和 [PLAN-043 结果](docs/dev/PLAN-043-review-fixes-OUTCOME.md)，不要把旧失败记录当成当前基线。

## 已完成的设计与复核

当前主设计为 [live-trading-20261023-design.md](docs/design/live-trading-20261023-design.md)，已更新到第六版，状态仍为待实施。
[设计索引](docs/design/README.md) 已同步版本和原生保护范围。

前两轮静态审查发现并已在设计中处理的事项：

| 事项 | 设计落点 |
| --- | --- |
| 已排队请求越过断线、暂停或退出门禁 | 第 6.5 节：最终发送边界复核、gate_epoch、intent_ttl、耐久请求阶段与未发送证明 |
| 重启丢失本地退出配置与追踪极值 | 第 10.1、11.1、11.4 节：配置/极值/触发义务与处理水位耐久保存，保护恢复参与 ready |
| 替换原生追踪单会丢失原极值、放宽保护 | 第 10.2 节：首版延期 native 追踪；需要追踪时显式选 local |
| 网络迟到或 SDK 内部积压被当成新鲜行情 | 第 7.3、8.3 节：保留原始接收时间，核对排队年龄、事件延迟、总年龄、校时误差与两层积压 |
| IncompleteAccountingError 中断结果冻结 | 第 12.1 节：区分 complete/incomplete/unsupported，保留订单、仓位、恢复信息，完整盈亏查询再报错 |
| 原生保护未明确强制只减仓 | 本轮补充第 10.2 节与第 14 节第 26 项，详见下文 |

第五版已经明确插件归属与自定义 Exchange/Broker 的公共协议；本轮保留该方向。
审查结论是设计可以作为分阶段实施依据；实际运行正确性仍须用第 14 节的验收证明。

## 本轮补充的原生保护契约

1. 首版 native 净持仓退出统一创建 STOP_MARKET / TAKE_PROFIT_MARKET，
   显式传 close_position=True，省略 qty/quantity 与 reduce_only。平多 SELL，平空 BUY。
2. 不依赖 SDK 默认参数或本地及时撤销另一侧订单来保证只减仓。即使止盈先平仓后断线，
   残留止损随后触发，也不能反向开仓；止损先触发的情况对称。
3. 若未来扩展数量型保护，必须 reduce_only=True，不能与 close_position=True 混传；
   首版不新增数量型或限价保护入口。
4. 建立、替换与恢复均核对并持久化订单类型、方向、closePosition/reduceOnly 和持仓生命周期。
   不符合契约时保持 protection_recovery_pending，不能报告 active 或继续增仓。
5. 同一生命周期仅数量变化不触发全平仓保护换单；修改触发价才需要管理替换。
   旧保护未确认清理前不得开启该标的新持仓生命周期，防止旧保护作用于后续同方向新仓。
6. 第 14 节第 26 项要求检查实际发送载荷、方向、参数互斥，并覆盖止盈/止损先后触发、
   断线、撤单超时、新旧保护重叠、部分平仓和恢复时的不合规保护。

来源已与本地 SDK 核对：
[Broker](../crypto_api/crypto_api/binance2/usdm/broker.py) 第 237、262 行的止损/止盈方法支持 close_position，
reduce_only 默认 None；
[参数校验](../crypto_api/crypto_api/binance2/usdm/_validation.py) 第 169–178 行限制全平仓订单类型及参数互斥。
官方规则链接保存在设计第 10.2 节。真实接口规则仍须在具体实施时再次确认。

## 当前代码事实与 SDK 前置依赖

当前发布元数据仍为 minbt 0.1.1、核心 Python >=3.8，见 [pyproject.toml](pyproject.toml)。
以下新增目录与接口尚未实现：minbt/replay、minbt/sim、minbt/_runtime.py、
minbt/plugins/binance/live、ExchangeProtocol、EventBrokerProtocol 与新账户会话协议。

- 当前历史运行入口见 minbt/exchange.py:253；尚无实时等待循环。
- 当前市价单在 minbt/broker/broker.py:951 创建记录后，第 961 行直接调用 _execute_existing_order；
  不能把设计的默认延后撮合误写成已实现行为。
- 当前 Strategy 回调见 minbt/strategy.py:80–99，尚无 on_ready/on_order/on_fill/on_account。
- 旧 BrokerProtocol / ReplayBrokerProtocol 见 minbt/protocols/broker.py:20、45；新协议需要另行扩展，避免强加新必需方法。
- 当前结果冻结见 minbt/result.py:40、64；新增盈亏完整性处理仍待实施。

本地实际依赖是相邻目录的 crypto_api.binance2.usdm，不是已经存在的 finapi.binance2。
已核对 crypto_api 提交 fbc4ab8ca8f70801592020c4c568e6e9182b1794；本轮没有修改该仓库。
设计记录包版本 0.2.1、Binance2 插件 Python >=3.10；实施时需再次核对依赖版本与工作区。

阶段 C 的明确前置条件是 SDK 最终发送边界支持逐请求许可：
[SDK 适配器](../crypto_api/crypto_api/binance2/usdm/_adapters/sdk.py) 第 70 行 before_send 当前仅检查资源关闭；
第 476 行的限流等待发生在业务调用内部。仅在 minbt 调用 SDK 前检查一次不能满足契约。
需通过受支持的 SDK 扩展补齐并验证，不能修改 SDK 私有对象来绕过这一前置条件。

## 不应改变的设计选择

- 用户核心概念只有 Exchange、Broker、Strategy；统一调用 exchange.run，不新增 run_live 或公共 Engine。
- replay.Exchange / sim.Broker 属于核心；Binance 实时类从 minbt.plugins.binance.live 导入。
  不创建默认绑定 Binance 的 minbt.live，不增加全局插件注册表。
- 自定义 Exchange/Broker 通过公共协议接入；核心不反向导入交易场所插件。
- 默认模拟与实盘统一事件确认；模拟订单在后续可执行事件撮合。
  legacy_immediate 仅供历史兼容，不恢复 on_init 写账户等旧生命周期特例。
- 实盘 Broker 独立于模拟账本；远端订单、成交、账户事实不得重复入账。unknown 不等于 rejected。
- 首版 Binance 实盘只支持 USDT 永续、单向、全仓、单资产保证金、单账户、单策略、main 分仓及固定 symbols。
- 本地声明式退出必须可恢复；首版 live 拒绝函数型退出，native 拒绝追踪；sim 保留现有函数型退出。
- 默认 exit 保留远端仓位和委托。暂停与只读阶段不得下策略订单，保护/恢复动作使用明确的独立授权。
- 所有新增接口都是迁移目标，当前已实施行为以源码为准；第 13 节的破坏性行为变化必须明确发布。

## 当前工作区：分清本轮文档与已有数值修复

本轮仅修改：

- HANDOFF.md；
- docs/design/live-trading-20261023-design.md；
- docs/design/README.md。

开始本轮前已存在以下改动，均未由本轮创建或修改：

| git 状态 | 路径 | 说明 |
| --- | --- | --- |
| M | docs/design/execution-20261013-cross-settlement.md | 既有数值结算文档改动 |
| M | minbt/broker/broker.py | PLAN-069 相关数值预检改动 |
| M | minbt/broker/portfolio.py | PLAN-069 相关数值预检改动 |
| ?? | BRAIN.md | 原有未跟踪文件，本轮未审查其内容 |
| ?? | GOAL.md | 项目目标；已读取，未经要求不得修改 |
| ?? | docs/dev/PLAN-069-risk-pnl-overflow.md | 原有计划，文件中记录已完成 |
| ?? | docs/dev/PLAN-069-risk-pnl-overflow-OUTCOME.md | 原有结果报告 |
| ?? | tests/test_risk_pnl_overflow.py | 原有数值回归测试 |

[PLAN-069 结果](docs/dev/PLAN-069-risk-pnl-overflow-OUTCOME.md) 记录针对性测试 219 passed、
全量测试 594 passed 和 Ruff 通过；这是该报告的历史证据，本轮没有重跑或重新认证。
实时实施应保留这些工作区改动，不回滚、不覆盖，也不把它们混入本轮文档提交。

## 推荐实施顺序

1. 先检查 git status、GOAL、AGENTS 和当前设计；在 docs/dev 建立新的编号计划，
   对照现有文件选择未占用编号。当前最高为 PLAN-069，本轮没有占用下一编号。
   范围或步骤发生实质变化时，先更新计划再实施。
2. 阶段 A：公共协议、replay/sim 入口、共用运行组件、非重入事件回调、on_ready/on_account、
   默认延后撮合及旧行为迁移。用独立自定义 Exchange/Broker 验证扩展边界。
3. 阶段 B：Binance 实时行情与同一 sim.Broker 的本地模拟；验证 K 线收齐、缺口、无行情控制、
   行情时效、资源释放与不支持组合的提前拒绝。
4. 阶段 C：先完成 SDK 最终发送许可适配，再实现 demo 账户、精度、异步订单、账户投影、
   SQLite 恢复与本地保护耐久状态。先做本机 HTTP/WS 故障注入，再进行 demo 集成验证。
5. 阶段 D：原生固定价保护、只减仓竞争验收、资金费、完整性结果冻结与运行文档。
   逐项落实设计第 14 节共 26 项关键验收；主网与 demo 不需要不同策略或另一套交易实现。
6. 原生追踪、可恢复函数型退出、分仓、多账户、双向和跨币种模型属于阶段 E，另行设计。
7. 每个实施计划完成后自查代码，修复发现的问题，生成对应 OUTCOME；按用户授权决定 commit/push。

后续实施可沿用项目既有验证方式，按变更范围选择相关测试并记录实际结果：

```bash
uv run --no-project python -m pytest -q --tb=short
git diff --check
```

新增故障测试应覆盖真实发送、持久化与恢复边界；不能只改旧测试预期值或只验证方法同名。
核心、replay、sim、protocols 和 Binance live 模块自身的导入隔离也必须覆盖；
完整接口、生命周期、金额、恢复与资源验收以设计第 14 节为准。

## 本轮验证记录

本轮仅修改文档，不运行策略、不发送订单、不改 SDK，不执行运行时代码测试。
最终文档差异、引用路径与格式检查结果在交付前核对；未将设计验收项标为已经通过。
