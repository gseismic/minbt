"""两个内置 Exchange 共用的配置、分发与运行组件；交易场所逻辑留在插件。"""

from collections import OrderedDict, deque
from contextlib import ExitStack, contextmanager
from datetime import datetime
from queue import Queue, Empty, Full
from threading import Lock, get_ident
from types import MappingProxyType
from uuid import uuid4
from typing import List, Optional
from pathlib import Path
import sys

from .broker import Broker
from .data.model import News, MarketEvent, _freeze_payload
from .data.replay import TimeBatch, BatchItem
from .events import SessionEvent
from .logger import logger as default_logger
from .permissions import TradingPermissions
from .protocols.live import RunContext
from .result import RunResult, _snapshot_account
from .strategy import Strategy


class ExchangeBase:
    """共享装配与串行回调，不负责历史读取或现实时间等待。"""

    _CALLBACKS = {"kline": "on_bars", "orderbook": "on_books", "trade": "on_trades", "news": "on_news"}

    def __init__(self, logger=None):
        self._strategies = OrderedDict()  # 注册只通过配置接口修改。
        self._strategies_view = MappingProxyType(self._strategies)
        self.logger = logger or default_logger
        self._current_dt = None  # 运行时钟，不必等于来源事件时间。
        self._run_state = "ready"  # 每个实例只能运行一次。
        self._lifecycle_lock = Lock()
        self._runtime = None  # 本次运行组件，停止后不再接受输入。

    @property
    def strategies(self):
        return self._strategies_view

    def describe(self):
        return {
            "clock": self.clock,
            "strategies": tuple(self.strategies),
            "brokers": tuple(_describe_broker(b) for b in self._unique_brokers()),
            "market": getattr(self, "market_identity", None),
        }

    def add_strategy(self, strategy: Strategy) -> None:
        with self._lifecycle_lock:
            self._require_ready()
            if not hasattr(strategy, "strategy_id"):
                raise TypeError("strategy must have strategy_id")
            required = ("on_init", "on_bar", "on_bars", "on_books", "on_trades", "on_news", "on_finish")
            for method in required:
                if not callable(getattr(strategy, method, None)):
                    raise TypeError(f"strategy must provide {method}()")
            if strategy.strategy_id in self.strategies:
                raise ValueError(f"strategy id already exists: {strategy.strategy_id!r}")
            strategy.set_exchange(self)
            self._strategies[strategy.strategy_id] = strategy

    def remove_strategy(self, strategy_id: str) -> None:
        with self._lifecycle_lock:
            self._require_ready()
            strategy = self._strategies.pop(strategy_id)
            strategy.set_exchange(None)

    def get_current_dt(self) -> Optional[datetime]:
        return self._current_dt

    def _require_ready(self) -> None:
        if self._run_state != "ready":
            raise RuntimeError(f"Exchange can only be run once (state={self._run_state})")

    def _claim_run(self, brokers) -> None:
        """一次性占用实例；共享 Broker 的占用检查跨 Exchange 也保持原子性。"""

        native_brokers = sorted((broker for broker in brokers if isinstance(broker, Broker)), key=id)
        with ExitStack() as stack:
            for broker in native_brokers:
                stack.enter_context(broker._run_lock)
            for strategy in self.strategies.values():
                if isinstance(strategy, Strategy) and (strategy._run_consumed or strategy.exchange is not self):
                    raise RuntimeError("Strategy already belongs to another run")
            if any(broker._run_consumed for broker in native_brokers):
                raise RuntimeError("Broker has already been used in another run")
            for strategy in self.strategies.values():
                if isinstance(strategy, Strategy):
                    strategy._run_consumed = True
            for broker in native_brokers:
                broker._run_consumed = True
                broker._run_owner = self
                broker._run_thread_id = get_ident()
            self._run_state = "running"

    @contextmanager
    def _read_only_brokers(self, brokers, phase):
        """控制与报告阶段只读账户，避免曲线结束点被回调额外交易改变。"""

        native_brokers = [broker for broker in brokers if isinstance(broker, Broker)]
        for broker in native_brokers:
            broker._run_readonly = phase
        try:
            if self._runtime is None:
                yield
            else:
                with self._runtime.permissions.readonly(phase):
                    yield
        finally:
            for broker in native_brokers:
                broker._run_readonly = None

    def _dispatch_batch(self, batch: TimeBatch) -> None:
        groups = OrderedDict()
        for item in batch.items:
            callback = self._callback_for(item.event)
            if callback is None:
                continue
            key = (callback, item.feed_name, item.feed_priority, item.registration_index)
            groups.setdefault(key, []).append(item)

        for key, items in groups.items():
            callback = key[0]
            if callback == "on_bar":
                for item in items:
                    for strategy in self.strategies.values():
                        strategy._dispatch_exchange_callback(callback, batch.dt, item.event)
                        self._drain_notifications()
                continue
            payload = self._callback_payload(callback, items)
            for strategy in self.strategies.values():
                strategy._dispatch_exchange_callback(callback, batch.dt, payload)
                self._drain_notifications()

    def _callback_for(self, event: MarketEvent) -> Optional[str]:
        if isinstance(event, News):
            return "on_news"
        return self._CALLBACKS.get(event.kind, "on_bar")

    def _callback_payload(self, callback: str, items: List[BatchItem]):
        if callback in {"on_bars", "on_books"}:
            payload = OrderedDict()
            for item in items:
                event = item.event
                if event.symbol in payload:
                    raise ValueError(
                        f"duplicate {callback} symbol {event.symbol!r} in feed {item.feed_name!r}"
                    )
                payload[event.symbol] = event.data
            return MappingProxyType(payload)
        if callback == "on_trades":
            payload = OrderedDict()
            for item in items:
                event = item.event
                payload.setdefault(event.symbol, []).append(event.data)
            return MappingProxyType({symbol: tuple(rows) for symbol, rows in payload.items()})
        if callback == "on_news":
            return tuple(item.event for item in items)
        raise ValueError(f"unsupported strategy callback: {callback!r}")

    def _unique_brokers(self):
        seen = set()
        for strategy in self.strategies.values():
            broker = getattr(strategy, "broker", None)
            if broker is None or id(broker) in seen:
                continue
            seen.add(id(broker))
            yield broker

    def _drain_notifications(self):
        if self._runtime is not None:
            self._runtime.drain()


def _describe_broker(broker):
    describe = getattr(broker, "describe", None)
    return describe() if callable(describe) else {"execution_kind": "simulated", "legacy_protocol": True}


def validate_combination(exchange, brokers):
    """以能力和市场身份验证组合，不识别插件名或特定环境值。"""
    market = getattr(exchange, "market_identity", None)
    for broker in brokers:
        info = _describe_broker(broker)
        if exchange.clock == "virtual" and info.get("execution_kind") == "external":
            raise ValueError("virtual Exchange cannot use an external Broker")
        if exchange.clock == "wall":
            if not callable(getattr(broker, "create_session", None)):
                raise TypeError("wall Exchange requires EventBrokerProtocol")
            if info.get("execution_model") == "legacy_immediate":
                raise ValueError("legacy_immediate is only available with virtual time")
        identity = info.get("market")
        if info.get("execution_kind") == "external":
            if not market or not identity:
                raise ValueError("external execution requires explicit market identity")
            for key in ("venue", "market", "environment"):
                if market.get(key) != identity.get(key):
                    raise ValueError(f"market/account {key} mismatch")
            if not set(identity.get("symbols", ())).issubset(market.get("symbols", ())):
                raise ValueError("Broker symbols must be included in market symbols")
            if len(exchange.strategies) != 1:
                raise ValueError("external Broker requires exactly one strategy")


class Runtime:
    """一次运行的账户推进和通知队列，两个时钟共用以保持因果顺序。"""

    def __init__(self, exchange, brokers, *, history_limit="auto", result_dir=None, queue_size=10000):
        if history_limit == "auto":
            history_limit = 10000 if exchange.clock == "wall" else None
        if history_limit is not None and (isinstance(history_limit, bool) or not isinstance(history_limit, int) or history_limit < 1):
            raise ValueError("history_limit must be 'auto', None, or a positive integer")
        self.exchange = exchange  # 不向插件暴露其他账户的可变对象。
        self.brokers = brokers
        self.limit = history_limit
        self.result_dir = None if result_dir is None else str(Path(result_dir).expanduser().resolve())
        self.permissions = TradingPermissions()
        self.session_id = uuid4().hex
        self.inbox = Queue(maxsize=queue_size)  # 原始输入有界，满时立即关闸。
        self.notification_limit = queue_size  # 单次账户投影也不能产生无界的通知积压。
        self.notifications = deque()  # 只由运行线程追加、消费。
        self.sessions = {}  # 按账户对象身份分派输入。
        self.histories = {}
        self.dispatch_seq = 0
        self.truncated = False
        self.ready_called = False
        self.stopping = False
        self._draining = False  # 通知回调产生的新通知串行排在后面。
        self.failure = None  # 溢出不能只在生产线程报错。
        self.writer = None  # 仅显式 result_dir 才记录全量结果。
        exchange._runtime = self

    def emit(self, broker, event):
        if not isinstance(event, SessionEvent):
            raise TypeError("emit requires SessionEvent")
        if event.kind in ("on_order", "on_fill", "on_account") and get_ident() == self.permissions._owner:
            if len(self.notifications) >= self.notification_limit:
                self.permissions.revoke("notification_overflow")
                self.failure = RuntimeError("runtime notification overflow")
                raise self.failure
            self.notifications.append((broker, event))
            return
        try:
            self.inbox.put_nowait((broker, event))
        except Full:
            self.permissions.revoke("inbox_overflow")
            self.failure = RuntimeError("runtime inbox overflow")
            raise self.failure

    def start(self):
        if self.result_dir is not None:
            from ._result_store import ResultWriter
            self.writer = ResultWriter(self.result_dir, self.session_id)
        for broker in self.brokers:
            cash = getattr(broker, "initial_cash", None)
            self.histories[id(broker)] = {
                "initial_cash": None if cash is None else float(cash),
                "equity": deque(maxlen=self.limit), "positions": deque(maxlen=self.limit),
            }
            factory = getattr(broker, "create_session", None)
            if callable(factory):
                session = factory()
                self.sessions[id(broker)] = session
                context = RunContext(
                    self.session_id, self.exchange.clock, self.exchange.get_current_dt,
                    self.permissions, _freeze_payload(self.exchange.describe()), self.limit, self.result_dir,
                )
                session.start(context, lambda event, b=broker: self.emit(b, event))
                if self.histories[id(broker)]["initial_cash"] is None:
                    self.histories[id(broker)]["initial_cash"] = getattr(broker, "initial_cash", None)
            elif self.exchange.clock != "virtual":
                raise TypeError("real time requires an event Broker session")
        with self.exchange._read_only_brokers(self.brokers, "on_init"):
            for strategy in self.exchange.strategies.values():
                strategy._history_limit = self.limit
                strategy.on_init()
            for strategy in self.exchange.strategies.values():
                session = self.sessions.get(id(strategy.broker))
                load = getattr(session, "load_strategy_state", None)
                if callable(load):
                    state = load(strategy.strategy_id)
                    if state is not None:
                        strategy.load_state(state)
        self.drain()

    def set_control(self, action):
        if action not in ("continue", "pause", "exit"):
            raise ValueError("control must return 'continue', 'pause', or 'exit'")
        if action != "continue":
            if self.permissions.enabled:
                self.permissions.revoke("session_stopping" if action == "exit" else "pause")
        return action

    def maybe_ready(self, action, market_ready=True):
        ready = market_ready and not self.stopping and all(s.ready for s in self.sessions.values())
        if action == "continue" and ready:
            self.permissions.open()
            if not self.ready_called:
                self.ready_called = True
                for strategy in self.exchange.strategies.values():
                    callback = getattr(strategy, "on_ready", None)
                    if callback is not None:
                        callback()
                    self.drain()
            for session in self.sessions.values():
                notify = getattr(session, "notify_account", None)
                if notify is not None:
                    notify()
            self.drain()
        elif self.permissions.enabled:
            self.permissions.revoke("not_ready")
        return ready and action == "continue" and self.permissions.enabled

    def market(self, batch, *, decision_dt=None, action="continue", deliver=True, market_ready=True, sample=True):
        self.exchange._current_dt = batch.dt if decision_dt is None else decision_dt
        self.dispatch_seq += 1
        if self.writer is not None:
            self.writer.append("market", "market", self.dispatch_seq,
                               {"batch": batch, "decision_time": self.exchange.get_current_dt(), "dispatch_seq": self.dispatch_seq})
        for broker in self.brokers:
            session = self.sessions.get(id(broker))
            if session is None:
                broker.process_market_batch(batch)
            else:
                session.on_market(batch)
        self.drain()
        if self.maybe_ready(action, market_ready) and deliver:
            self.exchange._dispatch_batch(batch)
        self.drain()
        self.checkpoint()
        if sample:
            self.sample()

    def drain(self, limit=10000):
        if self._draining:
            return
        self._draining = True
        try:
            for _ in range(limit):
                if self.failure is not None:
                    raise self.failure
                if self.notifications:
                    broker, event = self.notifications.popleft()
                    if self.writer is not None:
                        entity = getattr(event.payload, "id", self.dispatch_seq)
                        self.writer.append(id(broker), event.kind, entity, event.payload)
                    for strategy in self.exchange.strategies.values():
                        if strategy.broker is broker:
                            callback = getattr(strategy, event.kind, None)
                            if callback is not None:
                                if self.permissions.enabled and not self.stopping:
                                    callback(event.payload)
                                else:
                                    with self.exchange._read_only_brokers(self.brokers, "account notification"):
                                        callback(event.payload)
                    continue
                if self.exchange.clock == "wall":
                    return  # 实时原始输入由等待循环逐项接受，不能越过先前市场事件。
                try:
                    broker, event = self.inbox.get_nowait()
                except Empty:
                    return
                if event.kind in ("on_order", "on_fill", "on_account"):
                    self.notifications.append((broker, event))
                elif broker is not None:
                    self.sessions[id(broker)].apply(event)
                else:
                    raise RuntimeError(f"unhandled source event: {event.kind}")
        finally:
            self._draining = False
        raise RuntimeError("event dispatch limit exceeded")

    def apply_input(self, broker, event):
        self.dispatch_seq += 1
        if self.writer is not None:
            self.writer.append(id(broker), "account_input", self.dispatch_seq,
                               {"kind": event.kind, "received_at": event.received_at, "dispatch_seq": self.dispatch_seq})
        if event.kind in ("on_order", "on_fill", "on_account"):
            self.notifications.append((broker, event))
        else:
            self.sessions[id(broker)].apply(event)
        self.drain()
        self.checkpoint()

    def checkpoint(self):
        """可选会话负责 JSON 状态存储；恢复和保存钩子都不授予交易许可。"""
        with self.exchange._read_only_brokers(self.brokers, "save_state"):
            for strategy in self.exchange.strategies.values():
                session = self.sessions.get(id(strategy.broker))
                save = getattr(session, "save_strategy_state", None)
                if callable(save):
                    save(strategy.strategy_id, strategy.save_state(), self.dispatch_seq)

    def sample(self):
        for strategy in self.exchange.strategies.values():
            strategy._record_broker_history()
        for broker in self.brokers:
            history = self.histories[id(broker)]
            if self.limit and len(history["equity"]) >= self.limit:
                self.truncated = True
            history["equity"].append((self.exchange.get_current_dt(), broker.get_total_equity()))
            history["positions"].append(dict(broker.get_position_sizes()))
            if self.writer is not None:
                self.writer.append(id(broker), "sample", self.dispatch_seq,
                                   {"dt": self.exchange.get_current_dt(), "equity": history["equity"][-1][1],
                                    "positions": history["positions"][-1]})
                self.writer.capture(broker)
            prune = getattr(broker, "_prune_history", None)
            if callable(prune) and self.limit is not None:
                self.truncated |= prune(self.limit)

    def freeze(self, meta):
        snapshots = {id(b): _snapshot_account(b, **self.histories[id(b)]) for b in self.brokers}
        accounting = [s.accounting_status for s in snapshots.values()]
        meta = dict(meta, clock=self.exchange.clock, session_id=self.session_id,
                    decision_time=self.exchange.get_current_dt(), dispatch_seq=self.dispatch_seq,
                    history_limit=self.limit, history_truncated=self.truncated,
                    retained_from=next((s.equity[0][0] for s in snapshots.values() if s.equity), None),
                    result_dir=self.result_dir,
                    pnl_complete=False if "incomplete" in accounting else (None if "unsupported" in accounting else True),
                    accounting_issues=tuple(issue for s in snapshots.values() for issue in s.accounting_issues))
        descriptions = [_describe_broker(b) for b in self.brokers]
        if len(descriptions) == 1:
            meta.update(descriptions[0])
            extra = getattr(self.brokers[0], "get_result_metadata", None)
            if callable(extra):
                meta.update(extra())
        result = RunResult(
            _freeze_payload(meta),
            MappingProxyType({name: snapshots.get(id(s.broker)) for name, s in self.exchange.strategies.items()}),
        )
        if self.writer is not None and not self.writer.closed:
            return self.writer.freeze(result, self.brokers, self.exchange.strategies)
        return result

    def stop(self):
        if self.stopping:
            return
        self.stopping = True
        self.permissions.revoke("session_stopping")
        for session in self.sessions.values():
            session.request_stop()
        self.drain()

    def close(self, timeout=10.0):
        active_error = sys.exc_info()[1]
        errors = []
        try:
            self.stop()
        except BaseException as exc:
            errors.append(exc)
        for session in reversed(tuple(self.sessions.values())):
            try:
                session.close(timeout)
            except BaseException as exc:
                errors.append(exc)
        if self.writer is not None:
            try:
                self.writer.close()
            except BaseException as exc:
                errors.append(exc)
        if errors:
            failure = errors[0] if active_error is None else active_error
            failure.cleanup_errors = tuple(getattr(failure, "cleanup_errors", ())) + tuple(errors)
            if active_error is None:
                raise failure
