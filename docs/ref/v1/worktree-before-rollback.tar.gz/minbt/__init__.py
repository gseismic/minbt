from .strategy import Strategy
from .result import RunResult
from ._result_store import PersistentResult
from .events import Fill, AccountUpdate
from .protocols.result import OrderSnapshot
from .broker import Market, Order, Pnl, PnlRecord, markets
from .broker import ExitConfig, ExitRule, ExitContext, stop_loss_pct, take_profit_pct, stop_loss_price, take_profit_price
from .logger import logger
from .data import Bar, News
from .run import run

__all__ = [
    'Exchange',
    'Strategy',
    'RunResult',
    'PersistentResult',
    'Fill',
    'AccountUpdate',
    'OrderSnapshot',
    'Broker',
    'Order',
    'Pnl',
    'PnlRecord',
    'Market',
    'markets',
    'ExitConfig',
    'ExitRule',
    'ExitContext',
    'stop_loss_pct',
    'take_profit_pct',
    'stop_loss_price',
    'take_profit_price',
    'logger',
    'Bar',
    'News',
    'run',
]


def __getattr__(name):
    if name in ("Broker", "Exchange"):
        import warnings
        warnings.warn(f"minbt.{name} is deprecated; use minbt.{'sim' if name == 'Broker' else 'replay'}.{name} (removal: 0.3)", DeprecationWarning, stacklevel=2)
        if name == "Broker":
            from .sim import Broker
            return Broker
        from .replay import Exchange
        return Exchange
    raise AttributeError(name)
