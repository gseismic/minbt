"""可选完整结果日志；按会话与截止序号冻结，后续运行不能改写旧结果。"""

from collections.abc import Mapping
from dataclasses import dataclass, fields, is_dataclass
from datetime import datetime
import json
from pathlib import Path
import sqlite3
from types import MappingProxyType

from .broker.pnl import Pnl
from .events import Fill
from .protocols.result import OrderSnapshot
from .result import RunResult, _AccountSnapshot, _freeze_copy, snapshot_order


def _json_data(value):
    if isinstance(value, datetime):
        return {"$datetime": value.isoformat()}
    if is_dataclass(value):
        return {f.name: _json_data(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, Mapping):
        data = {str(k): _json_data(v) for k, v in value.items()}
        return {"$mapping": list(data.items())} if "$datetime" in data or "$mapping" in data else data
    if isinstance(value, (tuple, list)):
        return [_json_data(v) for v in value]
    return value


def _encode(value):
    return json.dumps(_json_data(value), ensure_ascii=False, allow_nan=False)


def _decode(value):
    def restore(row):
        if set(row) == {"$datetime"}:
            return datetime.fromisoformat(row["$datetime"])
        if set(row) == {"$mapping"}:
            return dict(row["$mapping"])
        return row
    return json.loads(value, object_hook=restore)


class ResultWriter:
    """运行线程顺序追加标准事实，列表查询留到调用方主动读取时再物化。"""

    def __init__(self, directory, session_id):
        root = Path(directory).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        self.path = str(root / "results.sqlite3")
        self.session_id = session_id
        self.connection = sqlite3.connect(self.path, isolation_level=None)
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute("PRAGMA synchronous=FULL")
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS records (
                seq INTEGER PRIMARY KEY AUTOINCREMENT, session TEXT NOT NULL,
                account TEXT NOT NULL, kind TEXT NOT NULL, entity TEXT NOT NULL, body TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS result_records ON records(session, account, kind, seq);
            CREATE INDEX IF NOT EXISTS result_entities ON records(session, account, kind, entity, seq);
            CREATE TABLE IF NOT EXISTS manifests (session TEXT PRIMARY KEY, cutoff INTEGER NOT NULL, body TEXT NOT NULL);
        """)
        self.last_orders = {}  # 兼容旧无事件 Broker，只比较保留窗口中的活记录。
        self.closed = False

    def append(self, account, kind, entity, body):
        self.connection.execute("INSERT INTO records(session,account,kind,entity,body) VALUES(?,?,?,?,?)",
                                (self.session_id, str(account), kind, str(entity), _encode(body)))

    def capture(self, broker):
        account = str(id(broker))
        query = getattr(broker, "get_orders", None)
        if callable(query):
            try:
                orders = query()
            except NotImplementedError:
                orders = ()
            current = {}
            for order in orders:
                record = snapshot_order(order)
                body = _encode(record)
                key = (account, order.id)
                if self.last_orders.get(key) != body:
                    self.append(account, "on_order", order.id, record)
                current[key] = body
            self.last_orders = {k: v for k, v in self.last_orders.items() if k[0] != account}
            self.last_orders.update(current)
        for name, kind in (("get_fills", "on_fill"), ("get_cashflows", "cashflow")):
            query = getattr(broker, name, None)
            if not callable(query):
                continue
            try:
                records = query()
            except NotImplementedError:
                continue
            for record in records:
                entity = record.id if kind == "on_fill" else ":".join(str(record.get(k, "")) for k in ("incomeType", "tranId", "symbol", "asset"))
                exists = self.connection.execute("SELECT 1 FROM records WHERE session=? AND account=? AND kind=? AND entity=? LIMIT 1",
                                                 (self.session_id, account, kind, str(entity))).fetchone()
                if exists is None:
                    self.append(account, kind, entity, record)

    def freeze(self, result, brokers, strategies):
        for broker in brokers:
            self.capture(broker)
        row = self.connection.execute("SELECT COALESCE(MAX(seq),0) FROM records WHERE session=?", (self.session_id,)).fetchone()
        cutoff = row[0]
        aliases = {name: None if strategy.broker is None else str(id(strategy.broker)) for name, strategy in strategies.items()}
        accounts = {}
        for name, snapshot in result._accounts.items():
            if snapshot is not None:
                accounts[aliases[name]] = {"initial_cash": snapshot.initial_cash, "final_positions": snapshot.final_positions,
                                           "all_portfolios": snapshot.all_portfolios, "has_orders": snapshot.orders is not None,
                                           "pnl": snapshot.pnl, "accounting_status": snapshot.accounting_status,
                                           "accounting_issues": snapshot.accounting_issues}
        manifest = {"schema": 1, "meta": result.meta, "aliases": aliases, "accounts": accounts}
        self.connection.execute("INSERT OR REPLACE INTO manifests(session,cutoff,body) VALUES(?,?,?)", (self.session_id, cutoff, _encode(manifest)))
        return PersistentResult.open(self.path, session_id=self.session_id)

    def close(self):
        if not self.closed:
            self.closed = True
            self.connection.close()


@dataclass(frozen=True)
class PersistentResult:
    """独立持久化结果，查询只读本会话冻结截止之前的数据，不持有网络或活账户。"""

    meta: object
    _snapshot: RunResult
    _path: str
    _session: str
    _cutoff: int
    _aliases: object

    @classmethod
    def open(cls, path, *, session_id=None):
        path = Path(path).resolve()
        if path.is_dir():
            path = path / "results.sqlite3"
        with sqlite3.connect(path.as_uri() + "?mode=ro", uri=True) as connection:
            if session_id is None:
                rows = connection.execute("SELECT session FROM manifests").fetchall()
                if len(rows) != 1:
                    raise ValueError("session_id is required when result_dir contains multiple runs")
                session_id = rows[0][0]
            row = connection.execute("SELECT cutoff,body FROM manifests WHERE session=?", (session_id,)).fetchone()
            if row is None:
                raise ValueError("unknown frozen result session")
        cutoff, encoded = row
        manifest = _decode(encoded)
        if manifest["schema"] != 1:
            raise ValueError("unsupported result schema")
        snapshots = {}
        for key, account in manifest["accounts"].items():
            snapshots[key] = _AccountSnapshot(account["initial_cash"], (), (), _freeze_copy(account["final_positions"]),
                                               account["all_portfolios"], () if account["has_orders"] else None,
                                               None if account["pnl"] is None else Pnl(**account["pnl"]),
                                               account["accounting_status"], _freeze_copy(account["accounting_issues"]))
        aliases = _freeze_copy(manifest["aliases"])
        meta = _freeze_copy(dict(manifest["meta"], result_cutoff=cutoff))
        snapshot = RunResult(meta, MappingProxyType({name: snapshots.get(key) for name, key in aliases.items()}))
        return cls(meta, snapshot, str(path), session_id, cutoff, aliases)

    def _key(self, strategy_id):
        self._snapshot._account(strategy_id)  # 复用账户归属与缺失能力的错误语义。
        return self._aliases[next(iter(self._aliases)) if strategy_id is None else strategy_id]

    def _records(self, kind, strategy_id, *, latest=False):
        key = self._key(strategy_id)
        with sqlite3.connect(Path(self._path).as_uri() + "?mode=ro", uri=True) as connection:
            if latest:
                rows = connection.execute("""SELECT r.body FROM records r JOIN (
                    SELECT MAX(seq) AS last_seq, MIN(seq) AS first_seq FROM records
                    WHERE session=? AND account=? AND kind=? AND seq<=? GROUP BY entity
                ) versions ON r.seq=versions.last_seq ORDER BY versions.first_seq""", (self._session, key, kind, self._cutoff))
            else:
                rows = connection.execute("SELECT body FROM records WHERE session=? AND account=? AND kind=? AND seq<=? ORDER BY seq",
                                           (self._session, key, kind, self._cutoff))
            return [_decode(row[0]) for row in rows]

    def get_initial_cash(self, *, strategy_id=None):
        return self._snapshot.get_initial_cash(strategy_id=strategy_id)

    def get_equity_curve(self, *, strategy_id=None):
        return [(r["dt"], r["equity"]) for r in self._records("sample", strategy_id)]

    def get_position_curve(self, symbol, *, strategy_id=None):
        from .data.model import normalize_symbol
        symbol = normalize_symbol(symbol)
        return [(r["dt"], r["positions"].get(symbol, 0.0)) for r in self._records("sample", strategy_id)]

    def get_orders(self, *, strategy_id=None):
        self._snapshot.get_orders(strategy_id=strategy_id)
        return [OrderSnapshot(**{k: _freeze_copy(v) for k, v in r.items()}) for r in self._records("on_order", strategy_id, latest=True)]

    def get_total_pnl(self, *, strategy_id=None):
        return self._snapshot.get_total_pnl(strategy_id=strategy_id)

    def get_position_sizes(self, *, strategy_id=None, portfolio=None):
        return self._snapshot.get_position_sizes(strategy_id=strategy_id, portfolio=portfolio)

    def get_fills(self, *, strategy_id=None):
        return [Fill(**r) for r in self._records("on_fill", strategy_id, latest=True)]

    def get_cashflows(self, *, strategy_id=None):
        return [_freeze_copy(r) for r in self._records("cashflow", strategy_id, latest=True)]
