"""可程序判断的交易与账目错误，供核心及独立插件共用。"""


class UnsupportedCapabilityError(NotImplementedError):
    """实现明确不支持所请求能力，避免把金融模型缺失当作交易失败。"""


class IncompleteAccountingError(RuntimeError):
    """完整盈亏缺少可核实事实；原因只保存数据，不持有活账户。"""

    def __init__(self, issues):
        self.issues = tuple(issues)
        super().__init__(f"accounting incomplete: {self.issues}")


class TradingPermissionError(RuntimeError):
    """交易许可已撤销或请求过期；调用方不得据此推断远端订单终态。"""

