"""账户会话、串行网络 worker 与耐久请求阶段；只有运行线程修改订单和账本。"""

from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
from queue import Empty, Queue
import sqlite3
from threading import Event, Lock, Thread, get_ident
import time
from types import MappingProxyType
from uuid import uuid4

from ....broker.order import Order
from ....errors import TradingPermissionError, UnsupportedCapabilityError
from ....events import Fill, SessionEvent
from ._facts import SnapshotFacts
from ._protection import ProtectionManager
from ._native import NativeProtectionManager
from ._rules import SymbolRules, decimal, finite_float, text
from ._state import StateStore


def _bool(value):
    if value is True or value == "true":
        return True
    if value is False or value == "false":
        return False
    raise ValueError("account mode field must be a boolean")


@dataclass
class Request:
    """耐久请求身份与进程内握手分开，queued 不代表发送授权。"""

    id: str
    order_id: str
    kind: str
    method: str
    payload: dict
    session_id: str
    epoch: int
    expires_at: float
    controlled: bool = False
    phase: str = "queued"
    previous_execution_state: str = None  # 撤单未发送时恢复原委托的执行阶段。
    prepared: Event = field(default_factory=Event, repr=False)  # 运行线程确认 dispatch_prepared 已耐久提交。

    def record(self):
        return {"id": self.id, "order_id": self.order_id, "kind": self.kind, "method": self.method,
                "payload": self.payload, "session_id": self.session_id, "epoch": self.epoch,
                "expires_at": self.expires_at, "controlled": self.controlled, "phase": self.phase,
                "previous_execution_state": self.previous_execution_state}


class AccountSession:
    """把 SDK 事实投影为唯一账户状态，并用请求准备握手保证 worker 不写账本。"""

    def __init__(self, broker):
        self.broker = broker
        self.context = self.emit = self.store = self.sdk = None
        self.owner_thread = None
        self.account_synced = False
        self.stopping = False
        self.private_connected = False  # 由已确认启动或运行线程应用的连接事实决定。
        self.controlled_depth = 0  # 只有内部已触发的退出义务使用受控许可。
        self.rules = {}
        self.requests = {}
        self.recent_filled_orders = set()
        self.dirty = Event()  # 输入线程只能关闸，不能修改账户投影或重新开启许可。
        self.generation = 0
        self.applied_generation = 0
        self.generation_lock = Lock()
        self.queue = Queue(maxsize=1000)
        self.worker_stop = Event()
        self.worker = self.watcher = None
        self.needs_reconcile = False
        self.reconcile_queued = False
        self.last_reconcile = 0.0
        self.last_sync = None
        self._monotonic = time.monotonic
        self._last_sync_mono = None  # 只推进成功核对的水位，失败重试不能刷新时效。
        self.failure = None
        self.start_time = 0
        self.fill_cursors = {}
        self.income_cursor = 0
        self.confirmed_positions = {}  # 已核对水位，与尚未核对的绝对账户推送分开。
        self.reservations = {}  # 远端快照尚未确证覆盖的本地保证金占用。
        self.leverages = {}  # 启动核对的合约杠杆，不在下单时修改。
        self.ambiguous_cancels = set()  # 查询到 pending 不能证明未知撤单没有执行。
        self._snapshots = set()  # 尚未消费的分页临时文件；异常或关闭时统一释放。
        self._snapshots_lock = Lock()

    @property
    def ready(self):
        return self.private_connected and self.account_synced and self._sync_fresh() and not self.dirty.is_set() and not self.stopping and self.failure is None and self.broker._protection is not None and self.broker._protection.ready

    def _sync_fresh(self):
        return self._last_sync_mono is not None and self._monotonic() - self._last_sync_mono < self.broker.max_sync_age

    @contextmanager
    def durable(self):
        try:
            with self.store.transaction():
                yield
        except (sqlite3.Error, OSError) as exc:
            self.failure = "persistence_failed"
            self.broker._accounting_issues.add("persistence_failed")
            self.account_synced = False
            self.context.permissions.revoke("persistence_failed")
            raise exc

    def start(self, context, emit):
        with self.broker._claim_lock:
            if self.broker._started:
                raise RuntimeError("Broker has already been used in another run")
            self.broker._started = True
            self.broker._session = self
        self.context, self.emit, self.owner_thread = context, emit, get_ident()
        if context.clock != "wall":
            raise ValueError("external Broker requires a wall-clock Exchange")
        self.store = StateStore(self.broker.state_dir, {"account_id": self.broker.account_id,
                                                       "environment": self.broker.environment, "symbols": self.broker.symbols,
                                                       "exit_mode": self.broker.exit_mode})
        self._restore()
        self.broker._protection = (NativeProtectionManager if self.broker.exit_mode == "native" else ProtectionManager)(self)
        self.sdk = self.broker._sdk_factory(api_key=self.broker._api_key, api_secret=self.broker._api_secret,
                                          environment=self.broker.environment)
        if not callable(getattr(self.sdk.api, "send_permission", None)):
            raise UnsupportedCapabilityError("SDK must provide the verified final send_permission hook")
        self.sdk.on_connection(self._connection)
        self.sdk.subscribe("user", self._private)
        self.sdk.start()
        self.private_connected = True  # SDK start 的公共契约等待初始私有订阅确认。
        info = self.sdk.api.market.get_exchange_info()
        self.rules = {r["symbol"]: SymbolRules(r) for r in info["symbols"] if r["symbol"] in self.broker.symbols}
        if set(self.rules) != set(self.broker.symbols):
            raise UnsupportedCapabilityError("one or more account symbols are not tradable USDT perpetuals")
        snapshot = self._fetch_snapshot(self._query_plan())
        self._apply_snapshot(snapshot, startup=True)
        self.broker._protection.restore()
        if self.broker._protection.issues:
            self.account_synced = False
            raise RuntimeError(f"protection_recovery_pending: {self.broker._protection.issues}")
        if not self.broker._protection.ready:
            self.context.permissions.revoke("not_ready")
        self.worker = Thread(target=self._work, name="minbt-account-worker", daemon=True)
        self.watcher = Thread(target=self._wait, name="minbt-account-wait", daemon=True)
        self.worker.start()
        self.watcher.start()

    def _restore(self):
        baseline = self.store.get("meta", "baseline")
        self.start_time = int(baseline["start_time"]) if baseline else int(self.context.now().timestamp() * 1000)
        checkpoint = self.store.get("meta", "checkpoint", {})
        self.confirmed_positions = {s: decimal(p["size"]) for s, p in checkpoint.get("positions", {}).items()}
        self.fill_cursors = {s: int(v) for s, v in checkpoint.get("fill_cursors", {}).items()}
        self.income_cursor = int(checkpoint.get("income_cursor", self.start_time))
        pinned = {o for _, state in self.store.iter_records("protection") if state["status"] != "cleared" for o in state["handles"]}
        for key, value in self.store.iter_records("orders"):
            row = value["order"]
            for name in ("qty", "filled_qty", "requested_price", "limit_price", "avg_price"):
                if row.get(name) is not None:
                    row[name] = finite_float(decimal(row[name]))
            for name in ("created_dt", "updated_dt"):
                if row.get(name) is not None:
                    row[name] = datetime.fromisoformat(row[name])
            order = Order(**row)
            self.broker.orders[key], self.broker._exact[key] = order, value["exact"]
            target = value["exact"].get("target")
            if target is not None:
                self.broker._targets[key] = decimal(target)
            if self.context.history_limit is not None:
                eligible = [k for k, o in self.broker.orders.items() if o.is_done and k not in pinned]
                for expired in eligible[:-self.context.history_limit]:
                    self.broker.orders.pop(expired)
                    self.broker._exact.pop(expired, None)
                    self.broker._targets.pop(expired, None)
        for key, row in self.store.iter_records("requests"):
            if row["kind"] == "cancel" and row["phase"] in ("dispatch_prepared", "unknown"):
                self.ambiguous_cancels.add(row["order_id"])
            if row["phase"] == "queued":
                row["phase"], row["reason"] = "not_sent", "session_stopping"
                with self.durable():
                    self.store.put("requests", key, row)
                    if row["kind"] in ("protect", "protect_cancel"):
                        algo = self.store.get("algos", row["order_id"])
                        if algo is not None:
                            algo["status" if row["kind"] == "protect" else "cancel_phase"] = "not_sent" if row["kind"] == "protect" else None
                            self.store.put("algos", row["order_id"], algo)
                    order = self.broker._load_order(row["order_id"])
                    if row["kind"] == "create" and order is not None and not order.is_done:
                        order.status, order.execution_state, order.reason_code = "canceled", "not_sent", "session_stopping"
                        self.broker._save_order(order)
            elif row["phase"] == "dispatch_prepared":
                order = self.broker._load_order(row["order_id"]) if row["kind"] in ("create", "cancel") else None
                if order is not None and not order.is_done:
                    order.status, order.execution_state = "unknown", "reconciling"
                    self.broker._sync_pending.add(order.symbol)
                    self.broker._save_order(order)
        with self.durable():
            version = self.store.get("meta", "fill_aggregate_version")
            if version not in (None, 1):
                raise RuntimeError("unsupported fill aggregate version")
            rebuild = version is None
            for key, row in self.store.iter_records("fills"):
                self._remember_fill(key, row)
                if rebuild:
                    self._aggregate_fill(row)
                if self.context.history_limit and len(self.broker._fills) > self.context.history_limit:
                    self.broker._fills.popitem(last=False)
            if rebuild:
                self.store.put("meta", "fill_aggregate_version", 1)
        for key, row in self.store.iter_records("cashflows"):
            self._remember_cashflow(key, row)
            if self.context.history_limit and len(self.broker._cashflows) > self.context.history_limit:
                self.broker._cashflows.popitem(last=False)
        for key, _ in self.store.iter_records("pending_trades"):
            self.broker._accounting_issues.add(f"missing_trade_details:{key}")

    def new_request(self, order, kind, method, payload):
        # 保护请求的目标是独立 clientAlgoId，不是开仓普通订单句柄。
        order_id = order if isinstance(order, str) else order.id
        previous = None if isinstance(order, str) else order.execution_state
        return Request(uuid4().hex, order_id, kind, method, dict(payload), self.context.session_id,
                       self.context.permissions.epoch, time.monotonic() + self.broker.intent_ttl,
                       controlled=self.controlled_depth > 0, previous_execution_state=previous)

    def enqueue(self, request):
        self.requests[request.id] = request
        self.queue.put_nowait(request)

    def cancel(self, order):
        creates = [r for r in self.requests.values() if r.order_id == order.id and r.kind == "create"]
        if creates and creates[-1].phase == "queued":
            self._not_sent(creates[-1], "intent_superseded")
            return
        if order.execution_state == "cancel_pending":
            return
        request = self.new_request(order, "cancel", "cancel_order", {"symbol": order.symbol, "client_order_id": order.client_order_id})
        with self.durable():
            self.store.put("requests", request.id, request.record())
        order.execution_state = "cancel_pending"
        self.broker._save_order(order)
        self.enqueue(request)
        self.broker._notify_order(order)

    def _private(self, event_type, raw):
        with self.generation_lock:
            self.generation += 1
            generation = self.generation
        self.dirty.set()
        self.context.permissions.revoke("account_sync_pending")
        self.emit(SessionEvent(self.broker.account_id, "private", {"generation": generation, "event": deepcopy(raw)}, generation, time.time()))

    def _connection(self, notice):
        with self.generation_lock:
            self.generation += 1
            generation = self.generation
        if notice.get("gap") or notice.get("state") in ("disconnected", "reconnecting", "failed"):
            self.dirty.set()
            self.context.permissions.revoke("private_disconnected")
        self.emit(SessionEvent(self.broker.account_id, "private_connection", dict(notice), generation, time.time()))

    def _wait(self):
        try:
            self.sdk.wait()
        except BaseException as exc:
            self.dirty.set()
            self.context.permissions.revoke("private_source_failed")
            self.emit(SessionEvent(self.broker.account_id, "worker_error", exc))
        else:
            if not self.stopping:
                self.dirty.set()
                self.context.permissions.revoke("private_source_ended")
                self.emit(SessionEvent(self.broker.account_id, "worker_error", RuntimeError("private source ended unexpectedly")))

    def _authorize(self, request, endpoint=None, params=None):
        def validate():
            if self.stopping or request.phase != "dispatch_prepared" or request.session_id != self.context.session_id:
                raise TradingPermissionError("session_stopping")
            if not self.account_synced or not self._sync_fresh() or self.dirty.is_set() or not self.private_connected or self.failure:
                raise TradingPermissionError("account_sync_pending")
            if request.kind in ("protect", "protect_cancel"):
                self.broker._protection.authorize(request, endpoint, params)
            elif request.controlled and self.broker.exit_mode == "native":
                self.broker._protection.authorize_ordinary(request, endpoint, params)
            elif not self.broker._protection.ready:
                raise TradingPermissionError("protection_recovery_pending")
            if request.kind == "create" and params is not None:
                identity = params.get("newClientOrderId", params.get("client_order_id"))
                if identity != request.payload["client_order_id"]:
                    raise TradingPermissionError("request_identity_mismatch")
        authorize = self.context.permissions.authorize_controlled if request.controlled else self.context.permissions.authorize
        authorize(request.epoch, request.expires_at, validate=validate)

    def _work(self):
        while not self.worker_stop.is_set():
            try:
                work = self.queue.get(timeout=0.1)
            except Empty:
                continue
            if work is None:
                return
            if isinstance(work, dict):
                try:
                    snapshot = self._fetch_snapshot(work)
                    if self.worker_stop.is_set():
                        self._release_snapshot(snapshot["facts"])
                        return
                    self.emit(SessionEvent(self.broker.account_id, "snapshot", snapshot))
                except BaseException as exc:
                    self.emit(SessionEvent(self.broker.account_id, "reconcile_error", exc))
                continue
            request = work
            if request.phase != "queued":
                continue
            self.emit(SessionEvent(self.broker.account_id, "prepare_request", request))
            while not request.prepared.wait(0.1):
                if self.worker_stop.is_set():
                    return
            if request.phase != "dispatch_prepared":
                continue
            try:
                self._authorize(request)
                with self.sdk.api.send_permission(lambda endpoint, params: self._authorize(request, endpoint, params)):
                    result = getattr(self.sdk, request.method)(**request.payload)
                outcome = (request.id, "reply", result)
            except BaseException as exc:
                name = type(exc).__name__
                if name == "RequestNotSentError" or name == "TradingPermissionError":
                    outcome = (request.id, "not_sent", str(getattr(exc, "__cause__", None) or exc))
                elif name in ("APIError", "AuthenticationError", "ParameterError", "RateLimitError"):
                    outcome = (request.id, "rejected", {"type": name, "code": getattr(exc, "code", None)})
                else:
                    outcome = (request.id, "unknown", {"type": name, "recovery": getattr(exc, "recovery", {})})
            self.emit(SessionEvent(self.broker.account_id, "request_result", outcome))

    def apply(self, event):
        if event.kind == "prepare_request":
            request = event.payload
            try:
                if self.stopping or request.epoch != self.context.permissions.epoch:
                    self._not_sent(request, "session_stopping" if self.stopping else "gate_revoked")
                elif time.monotonic() >= request.expires_at:
                    self._not_sent(request, "intent_expired")
                else:
                    request.phase = "dispatch_prepared"
                    with self.durable():
                        self.store.put("requests", request.id, request.record())
            finally:
                request.prepared.set()
            return
        if event.kind == "request_result":
            request_id, outcome, payload = event.payload
            request = self.requests[request_id]
            if outcome == "not_sent":
                reason = "intent_expired" if "intent_expired" in str(payload) else "gate_revoked"
                self._not_sent(request, reason)
                return
            if request.kind in ("protect", "protect_cancel"):
                with self.durable():
                    self.store.put("requests", request.id, dict(request.record(), phase=outcome, outcome=payload))
                    request.phase = outcome
                    self.broker._protection.outcome(request, outcome, payload)
                self.broker._notify_account()
                self.poll()
                return
            order = self.broker.orders[request.order_id]
            with self.durable():
                row = request.record()
                row.update(phase=outcome, outcome=payload)
                self.store.put("requests", request.id, row)
                if outcome == "reply":
                    self._order_fact(payload, order=order)
                elif outcome == "unknown":
                    if not order.is_done:
                        order.status, order.execution_state = "unknown", "reconciling"
                    self.broker._sync_pending.add(order.symbol)
                    self.account_synced = False
                    if request.kind == "cancel" and not order.is_done:
                        self.ambiguous_cancels.add(order.id)
                elif request.kind == "create" and not order.is_done and not order.filled_qty:
                    order.status, order.reason_code = "rejected", str(payload.get("code") or payload["type"])
                elif not order.is_done:
                    order.execution_state = request.previous_execution_state
                self.broker._save_order(order)
            request.phase = outcome
            self.broker._notify_order(order)
            self.needs_reconcile = True
        elif event.kind == "private":
            raw = event.payload["event"]
            self.applied_generation = max(self.applied_generation, event.payload["generation"])
            with self.durable():
                if raw.get("e") == "ORDER_TRADE_UPDATE":
                    row = raw["o"]
                    order = self._order_fact(row, compact=True)
                    if order is not None and row.get("x") == "TRADE" and int(row.get("t", -1)) >= 0:
                        self._fill_fact({"id": row["t"], "orderId": row["i"], "symbol": row["s"],
                                         "price": row["L"], "qty": row["l"], "side": row["S"],
                                         "commission": row.get("n"), "commissionAsset": row.get("N"),
                                         "realizedPnl": row.get("rp"), "time": row.get("T", raw.get("T", raw.get("E")))}, order)
                elif raw.get("e") == "ACCOUNT_UPDATE":
                    self._account_push(raw["a"])
                elif raw.get("e") == "listenKeyExpired":
                    self.private_connected = False
                elif raw.get("e") in ("ALGO_UPDATE", "CONDITIONAL_ORDER_TRIGGER_REJECT") and self.broker.exit_mode == "native":
                    # 私有事件字段随事件类型不同，统一以原始条件单 ID 的 REST 事实核对。
                    self.account_synced = False
                elif raw.get("e") in ("ACCOUNT_CONFIG_UPDATE", "MARGIN_CALL", "CONDITIONAL_ORDER_TRIGGER_REJECT", "ALGO_UPDATE"):
                    self.failure = "external_activity_or_protection_event"
                self.store.append("private_fact", raw)
            self.needs_reconcile = True
            self.broker._notify_account()
        elif event.kind == "snapshot":
            self.reconcile_queued = False
            self._apply_snapshot(event.payload)
        elif event.kind == "private_connection":
            self.applied_generation = max(self.applied_generation, event.sequence)
            state = event.payload.get("state")
            self.private_connected = state in ("connected", "reconnected")
            self.account_synced = False
            self.broker._accounting_issues.add("account_reconciliation_pending")
            self.needs_reconcile = True
            self.context.permissions.revoke("account_reconciling")
            self.broker._notify_account()
        elif event.kind in ("private_gap", "reconcile_error"):
            if event.kind == "private_gap":
                self.private_connected = False
            self.account_synced = False
            self.broker._accounting_issues.add("account_reconciliation_pending")
            self.reconcile_queued = False
            self.needs_reconcile = True
            self.context.permissions.revoke("account_reconciling")
            with self.durable():
                self.store.append(event.kind, {"type": type(event.payload).__name__})
            self.broker._notify_account()
        elif event.kind == "worker_error":
            raise event.payload
        else:
            raise ValueError(f"unsupported account event: {event.kind}")
        self.poll()

    def _not_sent(self, request, reason):
        row = dict(request.record(), phase="not_sent", reason=reason)
        if request.kind in ("protect", "protect_cancel"):
            with self.durable():
                self.store.put("requests", request.id, row)
                self.broker._protection.outcome(request, "not_sent", reason)
            request.phase = "not_sent"
            request.prepared.set()
            return
        order = self.broker.orders[request.order_id]
        with self.durable():
            self.store.put("requests", request.id, row)
            if request.kind == "create" and not order.is_done:
                order.status = "expired" if reason == "intent_expired" else "canceled"
                order.execution_state, order.reason_code = "not_sent", reason
                self.broker._save_order(order)
            elif request.kind == "cancel":
                self.ambiguous_cancels.discard(order.id)
                if not order.is_done:
                    order.execution_state = request.previous_execution_state
                self.broker._save_order(order)
        request.phase = "not_sent"
        request.prepared.set()
        if request.kind == "create":
            self.reservations.pop(order.id, None)
        if request.kind in ("create", "cancel"):
            self.broker._notify_order(order)

    def _query_plan(self):
        cursors = dict(self.fill_cursors)
        for _, row in self.store.iter_records("pending_trades"):
            symbol, trade_id = row["symbol"], int(row["id"])
            cursors[symbol] = min(cursors.get(symbol, trade_id), trade_id)
        return {"start_time": self.start_time, "fill_cursors": cursors, "income_cursor": self.income_cursor,
                "protection": self.broker._protection.query_plan() if self.broker.exit_mode == "native" else [],
                "unassociated": [row for _, row in self.store.iter_records("unassociated_orders")],
                "orders": [(o.symbol, o.client_order_id) for o in self.broker.orders.values() if not o.is_done]}

    def _fetch_snapshot(self, plan):
        facts = SnapshotFacts()
        with self._snapshots_lock:
            self._snapshots.add(facts)
        try:
            return self._fetch_snapshot_into(plan, facts)
        except BaseException:
            self._release_snapshot(facts)
            raise

    def _release_snapshot(self, facts):
        facts.close()
        with self._snapshots_lock:
            self._snapshots.discard(facts)

    def _fetch_snapshot_into(self, plan, facts):
        with self.generation_lock:
            generation = self.generation
        mode = self.sdk.get_position_mode()
        multi = self.sdk.api.account.get_multi_assets_mode()
        config = self.sdk.get_symbol_config()
        first = self.sdk.get_account()
        positions = self.sdk.get_positions()
        ordinary, algos = self.sdk.get_open_orders(), self.sdk.get_open_algo_orders()
        algo_facts, algo_missing, actual_orders = [], [], []
        for symbol, client_id, algo_id in plan["protection"]:
            try:
                row = self.sdk.get_algo_order(client_algo_id=client_id)
            except Exception as exc:
                if getattr(exc, "code", None) in (-2013, -2011):
                    algo_missing.append(client_id)
                    continue
                raise
            algo_facts.append(row)
            if row.get("actualOrderId") and str(row["actualOrderId"]) != "0":
                actual_orders.append(self.sdk.get_order(symbol, order_id=int(row["actualOrderId"])))
        unassociated = [self.sdk.get_order(row["symbol"], order_id=int(row["order_id"])) for row in plan["unassociated"]]
        known = []
        unresolved = []
        for symbol, client_id in plan["orders"]:
            try:
                known.append(self.sdk.get_order(symbol, client_order_id=client_id))
            except Exception as exc:
                if getattr(exc, "code", None) == -2013:
                    unresolved.append(client_id)
                else:
                    raise
        fill_cursors = dict(plan["fill_cursors"])
        for symbol in self.broker.symbols:
            cursor = fill_cursors.get(symbol)
            for _ in range(10000):
                options = {"limit": 500, "from_id": cursor} if cursor is not None else {"limit": 500, "start_time": plan["start_time"]}
                page = self.sdk.get_fills(symbol, **options)
                facts.append("fills", page)
                if not page:
                    break
                next_cursor = max(int(row["id"]) for row in page) + 1
                if cursor is not None and next_cursor <= cursor:
                    raise RuntimeError("fill pagination did not advance")
                cursor = next_cursor
                fill_cursors[symbol] = cursor
                if len(page) < 500:
                    break
            else:
                raise RuntimeError("fill pagination limit exceeded")
        income_cursor = int(plan["income_cursor"] or plan["start_time"])
        for _ in range(10000):
            page = self.sdk.get_income_history(start_time=income_cursor, limit=1000)
            facts.append("incomes", page)
            if not page:
                break
            next_time = max(int(row["time"]) for row in page)
            if len(page) < 1000:
                income_cursor = next_time
                break
            if next_time <= income_cursor:
                raise RuntimeError("income pagination cannot prove all same-millisecond records were recovered")
            income_cursor = next_time
        else:
            raise RuntimeError("income pagination limit exceeded")
        second = self.sdk.get_account()
        with self.generation_lock:
            stable_generation = self.generation
        return dict(account=second, first=first, positions=positions, mode=mode, multi=multi, config=config,
                    ordinary=ordinary, algos=algos, algo_facts=algo_facts, algo_missing=algo_missing, actual_orders=actual_orders,
                    unassociated=unassociated,
                    known=known, unresolved=unresolved, facts=facts,
                    fill_cursors=fill_cursors, income_cursor=income_cursor,
                    generation=generation, stable_generation=stable_generation)

    def _apply_snapshot(self, snapshot, startup=False):
        try:
            self._project_snapshot(snapshot, startup=startup)
        except BaseException:
            self.account_synced = False
            self.broker._accounting_issues.add("reconciliation_interrupted")
            self.context.permissions.revoke("account_reconciling")
            raise
        finally:
            self._release_snapshot(snapshot["facts"])

    def _project_snapshot(self, snapshot, startup=False):
        if _bool(snapshot["mode"]["dualSidePosition"]) or _bool(snapshot["multi"]["multiAssetsMargin"]):
            raise UnsupportedCapabilityError("live Broker requires one-way, single-asset margin")
        configs = {r["symbol"]: r for r in snapshot["config"]}
        for symbol in self.broker.symbols:
            config = configs[symbol]
            self.leverages[symbol] = decimal(config["leverage"])
            if config["marginType"].upper() not in ("CROSSED", "CROSS"):
                raise UnsupportedCapabilityError("live Broker requires cross margin")
            if self.broker.expected_leverage is not None and decimal(config["leverage"]) != self.broker.expected_leverage:
                raise UnsupportedCapabilityError("account leverage does not match requested leverage")
        account = snapshot["account"]
        if not _bool(account["canTrade"]):
            raise UnsupportedCapabilityError("account is not allowed to trade")
        assets = {row["asset"]: row for row in account["assets"]}
        asset = assets["USDT"]
        wallet, available = decimal(asset["walletBalance"]), decimal(asset["availableBalance"])
        for name, value in assets.items():
            if name != "USDT" and decimal(value["walletBalance"]):
                self.broker._accounting_issues.add(f"unsupported_asset:{name}")
        positions = {}
        for row in snapshot["positions"]:
            size = decimal(row["positionAmt"])
            if row["symbol"] not in self.broker.symbols:
                if size:
                    raise UnsupportedCapabilityError("external position outside fixed symbols")
                continue
            if row["positionSide"] != "BOTH":
                raise UnsupportedCapabilityError("hedge positions are not supported")
            positions[row["symbol"]] = {"size": size, "entry_price": decimal(row["entryPrice"]),
                                         "unrealized_pnl": decimal(row.get("unRealizedProfit", row.get("unrealizedProfit", "0")))}
        if self.broker.exit_mode == "native":
            with self.durable():
                self.broker._protection.ingest(snapshot["algo_facts"] + snapshot["algos"], snapshot["algo_missing"])
                for row in snapshot["actual_orders"]:
                    self.broker._protection.bind_actual(row)
                    self._order_fact(row)
        if any(self.broker._find_order(row["clientOrderId"], row["orderId"], row["symbol"]) is None for row in snapshot["ordinary"]) or (snapshot["algos"] and self.broker.exit_mode != "native"):
            raise UnsupportedCapabilityError("unknown external ordinary/algo orders require explicit ownership recovery")
        baseline = self.store.get("meta", "baseline")
        if baseline is None and (any(p["size"] for p in positions.values()) or snapshot["ordinary"] or snapshot["algos"]):
            raise UnsupportedCapabilityError("a new state_dir requires a flat account with no open orders")
        old_positions = dict(self.confirmed_positions)
        with self.durable():
            for row in snapshot["unassociated"]:
                order = self._order_fact(row)
                if order is not None:
                    self.store.delete("unassociated_orders", f"{row['symbol']}:{row['orderId']}")
            for row in snapshot["known"]:
                self._order_fact(row)
            for row in snapshot["facts"].records("fills"):
                self._fill_fact(row)
            for row in snapshot["facts"].records("incomes"):
                self._cashflow_fact(row)
            self.broker._positions = positions
            self.broker._wallet, self.broker._available = wallet, available
            if baseline is None:
                self.store.put("meta", "baseline", {"start_time": self.start_time, "initial_wallet": text(wallet),
                                                      "realized": text(self.broker._realized), "fees": text(self.broker._fees),
                                                      "funding": text(self.broker._funding), "external_flows": text(self.broker._external_flows)})
            unresolved = [c for c in snapshot["unresolved"] if not any(o.client_order_id == c and o.execution_state == "not_sent" for o in self.broker.orders.values())]
            stable = (self.private_connected and snapshot["first"] == account and snapshot["generation"] == snapshot["stable_generation"] == self.generation
                      and self.applied_generation >= self.generation and not unresolved and not self.ambiguous_cancels)
            if stable:
                totals = {s: decimal(self.store.get("fill_totals", "symbol:" + s, "0")) for s in self.broker.symbols}
                coverage = all(decimal(exact["filled_qty"]) == decimal(self.store.get("fill_totals", "order:" + order_id, "0"))
                               for order_id, exact in self.broker._exact.items())
                if any(totals[s] != positions.get(s, {}).get("size", decimal("0")) for s in self.broker.symbols):
                    stable = False
                    self.failure = "external_activity_or_missing_fills"
                if not coverage:
                    stable = False
                    self.broker._accounting_issues.add("missing_order_fill_details")
                else:
                    self.broker._accounting_issues.discard("missing_order_fill_details")
                if baseline is not None:
                    expected_wallet = (decimal(baseline["initial_wallet"]) + self.broker._realized - decimal(baseline.get("realized", "0"))
                                       - self.broker._fees + decimal(baseline.get("fees", "0")) + self.broker._funding - decimal(baseline.get("funding", "0"))
                                       + self.broker._external_flows - decimal(baseline.get("external_flows", "0")))
                    if abs(expected_wallet - wallet) > decimal("0.00000001"):
                        stable = False
                        self.broker._accounting_issues.add("wallet_ledger_mismatch")
                    else:
                        self.broker._accounting_issues.discard("wallet_ledger_mismatch")
            if stable:
                self.dirty.clear()
                self.broker._sync_pending.clear()
                self.confirmed_positions = {s: p["size"] for s, p in positions.items()}
                open_clients = {row["clientOrderId"] for row in snapshot["ordinary"]}
                for order in self.broker.orders.values():
                    if order.is_done or order.client_order_id in open_clients:
                        self.reservations.pop(order.id, None)
                for request_id, request in self.store.iter_records("requests"):
                    if request["kind"] not in ("create", "cancel"):
                        continue
                    if request["phase"] not in ("unknown", "dispatch_prepared"):
                        continue
                    order = self.broker.orders.get(request["order_id"])
                    confirmed = order is not None and (order.is_done if request["kind"] == "cancel" else order.exchange_order_id is not None and order.status != "unknown")
                    if confirmed:
                        request["phase"] = "confirmed"
                        self.store.put("requests", request_id, request)
                        if request_id in self.requests:
                            self.requests[request_id].phase = "confirmed"
            self.account_synced = stable
            if stable:
                self.broker._accounting_issues.discard("reconciliation_interrupted")
                self.broker._accounting_issues.discard("account_reconciliation_pending")
                self.broker._accounting_issues.discard("account_sync_age_exceeded")
            self.fill_cursors, self.income_cursor = snapshot["fill_cursors"], snapshot["income_cursor"]
            self.store.put("meta", "checkpoint", {"positions": positions, "wallet": wallet,
                                                   "fill_cursors": self.fill_cursors, "income_cursor": self.income_cursor,
                                                   "account_synced": stable, "session_id": self.context.session_id})
        if not startup and stable:
            self.broker._protection.synchronize(old_positions)
            self.recent_filled_orders.clear()
        self.needs_reconcile = not self.account_synced
        if stable:
            self.last_sync = self.context.now()
            self._last_sync_mono = self._monotonic()
        if self.broker._initial_equity is None:
            self.broker.initial_cash = finite_float(wallet)
            self.broker._initial_equity = self.broker.get_total_equity()
            self.broker._initial_unrealized = self.broker._unrealized()
            if not self.broker._accounting_issues:
                self.broker._initial_pnl = {"realized_pnl": finite_float(self.broker._realized),
                                            "unrealized_pnl": finite_float(self.broker._initial_unrealized),
                                            "fees": finite_float(self.broker._fees), "funding_pnl": finite_float(self.broker._funding)}
        self.broker._notify_account()

    def _order_fact(self, row, order=None, compact=False):
        client = row.get("c" if compact else "clientOrderId")
        remote_id = row.get("i" if compact else "orderId")
        if order is None:
            order = self.broker._find_order(client, remote_id, row.get("s" if compact else "symbol"))
        if order is None:
            if compact and self.broker.exit_mode == "native":
                # 实际普通单可能先于 ALGO_UPDATE 到达。留在原始日志，核对后再由成交历史补账。
                self.store.put("unassociated_orders", f"{row['s']}:{remote_id}",
                               {"symbol": row["s"], "order_id": str(remote_id), "client_id": client})
                self.account_synced = False
                self.needs_reconcile = True
                return None
            self.failure = "external_activity"
            self.context.permissions.revoke("external_activity")
            return None
        status = row.get("X" if compact else "status", "NEW")
        mapped = {"NEW": "pending", "PARTIALLY_FILLED": "partially_filled", "FILLED": "filled", "CANCELED": "canceled",
                  "EXPIRED": "expired", "EXPIRED_IN_MATCH": "expired", "REJECTED": "rejected"}.get(status)
        if mapped is None:
            mapped = "unknown"
        if order.id in self.ambiguous_cancels:
            if mapped in ("filled", "canceled", "expired", "rejected"):
                self.ambiguous_cancels.discard(order.id)
            else:
                mapped = "unknown"
        exact = self.broker._exact[order.id]
        cumulative = decimal(row.get("z" if compact else "executedQty", "0"))
        previous = decimal(exact["filled_qty"])
        if cumulative >= abs(previous):
            signed = cumulative if decimal(exact["qty"]) > 0 else -cumulative
            exact["filled_qty"] = text(signed)
            order.filled_qty = finite_float(signed)
            average = decimal(row.get("ap" if compact else "avgPrice", "0"))
            if average:
                exact["avg_price"], order.avg_price = text(average), finite_float(average)
            if not order.is_done or mapped == "filled":
                order.status = mapped
        order.exchange_order_id = str(remote_id) if remote_id is not None else order.exchange_order_id
        order.execution_state = "accepted" if order.status == "pending" else order.status
        order.updated_dt = self.context.now()
        if cumulative > abs(previous):
            self.broker._sync_pending.add(order.symbol)
            self.account_synced = False
            self.context.permissions.revoke("account_sync_pending")
        self.broker._save_order(order)
        self.broker._notify_order(order)
        return order

    def _fill_fact(self, row, order=None):
        symbol = row["symbol"]
        if order is None:
            order = self.broker._find_order(remote_id=row["orderId"], symbol=symbol)
        if order is None:
            self.failure = "external_activity"
            self.context.permissions.revoke("external_activity")
            return
        key = ":".join((self.broker.environment, self.broker.account_id, symbol, str(row["id"])))
        record = dict(row, local_order_id=order.id)
        if any(row.get(k) is None for k in ("qty", "price", "commission", "realizedPnl", "time")) or (decimal(row["commission"]) != 0 and not row.get("commissionAsset")):
            self.store.put("pending_trades", key, record)
            self.broker._accounting_issues.add(f"missing_trade_details:{key}")
            self.account_synced = False
            return
        self.store.delete("pending_trades", key)
        self.broker._accounting_issues.discard(f"missing_trade_details:{key}")
        if decimal(row["qty"]) <= 0 or decimal(row["price"]) <= 0:
            raise ValueError("confirmed trade price and absolute quantity must be positive")
        if self.store.insert_unique("fills", key, record):
            self._aggregate_fill(record)
            self._remember_fill(key, record)
            self.recent_filled_orders.add(order.id)
            self.emit(SessionEvent(self.broker.account_id, "on_fill", self.broker._fills[key]))

    def _aggregate_fill(self, row):
        signed = decimal(row["qty"]) * (-1 if row["side"] == "SELL" else 1)
        for key in ("symbol:" + row["symbol"], "order:" + row["local_order_id"]):
            self.store.put("fill_totals", key, text(decimal(self.store.get("fill_totals", key, "0")) + signed))

    def _remember_fill(self, key, row):
        qty = decimal(row["qty"]) * (-1 if row["side"] == "SELL" else 1)
        fee, asset = decimal(row.get("commission", "0")), row.get("commissionAsset")
        self.broker._realized += decimal(row.get("realizedPnl", "0"))
        if asset == "USDT":
            self.broker._fees += fee
        elif fee:
            self.broker._accounting_issues.add(f"unconverted_fee:{asset}")
        self.broker._fills[key] = Fill(key, row["local_order_id"], row["symbol"], "main", finite_float(qty), finite_float(decimal(row["price"])),
                                      finite_float(fee), asset or "UNKNOWN", datetime.fromtimestamp(int(row["time"]) / 1000, timezone.utc))
        if self.context.history_limit:
            while len(self.broker._fills) > self.context.history_limit:
                self.broker._fills.popitem(last=False)

    def _cashflow_fact(self, row):
        kind = row["incomeType"]
        if kind in ("REALIZED_PNL", "COMMISSION"):
            return  # 普通成交的毛盈亏和费用只从唯一成交记账。
        key = ":".join(str(row.get(k, "")) for k in ("incomeType", "tranId", "symbol", "asset"))
        if not row.get("tranId"):
            raise ValueError("cashflow requires a stable transaction id")
        if self.store.insert_unique("cashflows", key, row):
            self._remember_cashflow(key, row)

    def _remember_cashflow(self, key, row):
        kind, amount = row["incomeType"], decimal(row["income"])
        if row["asset"] != "USDT" and amount:
            self.broker._accounting_issues.add(f"unconverted_cashflow:{row['asset']}")
        elif kind == "FUNDING_FEE":
            self.broker._funding += amount
        elif kind in ("TRANSFER", "INTERNAL_TRANSFER"):
            self.broker._external_flows += amount
        elif amount:
            self.broker._accounting_issues.add(f"unsupported_cashflow:{kind}")
        self.broker._cashflows[key] = MappingProxyType(dict(row))
        if self.context.history_limit:
            while len(self.broker._cashflows) > self.context.history_limit:
                self.broker._cashflows.popitem(last=False)

    def _account_push(self, account):
        for row in account.get("B", ()):
            if row["a"] == "USDT":
                self.broker._wallet = decimal(row["wb"])
        for row in account.get("P", ()):
            if row["s"] not in self.broker.symbols or row.get("ps") != "BOTH":
                self.failure = "external_activity"
                continue
            self.broker._positions[row["s"]] = {"size": decimal(row["pa"]), "entry_price": decimal(row["ep"]),
                                                 "unrealized_pnl": decimal(row["up"])}
        self.account_synced = False

    def on_market(self, batch):
        prices = {}
        try:
            for item in batch.bars(kind="mark_price"):
                price = decimal(item.event.data["price"])
                if price <= 0:
                    raise ValueError("mark price must be positive")
                prices[item.event.symbol] = price
        except (ValueError, TypeError):
            self.context.permissions.revoke("invalid_mark_price")
            raise
        self.broker._prices.update(prices)
        if self.broker._protection is not None:
            self.broker._protection.on_market(prices, {"dt": batch.dt, "sequences": [i.sequence for i in batch.items]})
        self.poll()

    def notify_account(self):
        self.broker._notify_account()

    def poll(self):
        if self._last_sync_mono is not None and self._monotonic() - self._last_sync_mono >= self.broker.sync_interval:
            self.needs_reconcile = True
        if self.account_synced and not self._sync_fresh():
            self.account_synced = False
            self.broker._accounting_issues.add("account_sync_age_exceeded")
            self.context.permissions.revoke("account_sync_pending")
            self.broker._notify_account()
        if self.broker.exit_mode == "native" and self.broker._protection is not None:
            self.broker._protection.drive()
        if self.needs_reconcile and not self.reconcile_queued and self.worker is not None and time.monotonic() - self.last_reconcile >= 0.2:
            self.reconcile_queued = True
            self.last_reconcile = time.monotonic()
            self.queue.put_nowait(self._query_plan())

    def load_strategy_state(self, strategy_id):
        row = self.store.get("strategy", strategy_id)
        if row is None:
            return None
        if row.get("schema") != 1:
            raise RuntimeError("unsupported strategy checkpoint schema")
        return json.loads(row["json"])

    def save_strategy_state(self, strategy_id, state, dispatch_seq):
        encoded = json.dumps(state, ensure_ascii=False, allow_nan=False)
        with self.durable():
            self.store.put("strategy", strategy_id, {"schema": 1, "json": encoded,
                                                     "dispatch_seq": dispatch_seq, "session_id": self.context.session_id})

    def health(self):
        return MappingProxyType({"status": "stopped" if self.stopping else ("ready" if self.ready else "reconciling"),
                                 "ready": self.ready, "account_synced": self.account_synced and self._sync_fresh() and not self.dirty.is_set() and not any(r.phase in ("dispatch_prepared", "unknown") for r in self.requests.values()),
                                 "last_sync": self.last_sync, "pending_requests": sum(r.phase in ("queued", "dispatch_prepared", "unknown") for r in self.requests.values()),
                                 "reason": self.failure or ("private_disconnected" if not self.private_connected else None),
                                 "protection_ready": self.broker._protection is not None and self.broker._protection.ready,
                                 "protection_issues": self.broker._protection.diagnostics if self.broker._protection else ("not_started",)})

    @property
    def has_pending(self):
        return self.reconcile_queued or any(r.phase in ("queued", "dispatch_prepared", "unknown") for r in self.requests.values())

    def request_stop(self):
        if self.stopping:
            return
        self.stopping = True
        self.context.permissions.revoke("session_stopping")
        if self.store is not None:
            for request in self.requests.values():
                if request.phase == "queued":
                    self._not_sent(request, "session_stopping")
            with self.durable():
                self.store.append("session_stopping", {"session_id": self.context.session_id})
            if self.worker is not None:
                self.needs_reconcile = True
                self.poll()

    def close(self, timeout):
        self.worker_stop.set()
        for request in self.requests.values():
            request.prepared.set()
        if self.worker is not None:
            self.worker.join(timeout=timeout)
        try:
            if self.sdk is not None:
                from .exchange import _close_bounded
                _close_bounded(self.sdk.close, timeout)
            if self.watcher is not None:
                self.watcher.join(timeout=timeout)
                if self.watcher.is_alive():
                    raise RuntimeError("account watcher did not close")
            if self.worker is not None and self.worker.is_alive():
                raise RuntimeError("account worker is still in flight; recover from state_dir")
        finally:
            if self.worker is None or not self.worker.is_alive():
                with self._snapshots_lock:
                    for facts in self._snapshots:
                        facts.close()
                    self._snapshots.clear()
            if self.store is not None:
                self.store.close()
