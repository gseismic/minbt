"""SDK 行情资源归属、接收时间保留和后台失败/积压监测。"""

from copy import deepcopy
from threading import Event, Thread
import time

from ....events import SessionEvent
from ._freshness import Freshness, StaleMarketError
from ._market import MarketInput


class SDKSource:
    """只负责输入，不更新账户、不执行策略；start/stop/close 由运行会话持有。"""

    def __init__(self, factory, environment, symbols, subscriptions, *, permissions, queue_size,
                 utc=time.time, monotonic=time.monotonic, max_age=5.0):
        self.factory = factory
        self.environment = environment
        self.symbols = symbols
        self.subscriptions = subscriptions
        self.permissions = permissions
        self.queue_size = queue_size
        self.utc, self.monotonic = utc, monotonic
        self.freshness = Freshness(symbols, utc=utc, monotonic=monotonic, max_age=max_age)
        self.sdk = None  # run 前不创建网络资源。
        self.emit = None
        self.stopping = Event()
        self.watcher = self.monitor = None
        self.delivery_started = None  # SDK 队列已出队但回调未返回时仍计入年龄。
        self.inflight_since = None  # SDK 已派发但尚未进入回调的未知等待。
        self.monitor_at = None  # 发送前检查监测服务本身未失联。
        self.failure = None  # 尚在普通队列中的故障也不能被运行线程误开闸。
        self.gap_latched = False  # 首版缺口直接结束，不通过一条新消息解除。

    def start(self, emit):
        self.emit = emit
        self.sdk = self.factory(on_data=self._on_data, environment=self.environment, queue_size=self.queue_size)
        self.sdk.on_connection(self._on_connection)
        self._calibrate()
        for symbols, kind, options in self.subscriptions:
            self.sdk.subscribe(symbols, kind, **options)
        self.sdk.start()
        self.watcher = Thread(target=self._wait, name="minbt-market-wait", daemon=True)
        self.monitor = Thread(target=self._monitor, name="minbt-market-monitor", daemon=True)
        self.watcher.start()
        self.monitor.start()

    def _calibrate(self):
        started_utc, started_mono = self.utc(), self.monotonic()
        server_time = self.sdk.api.market.get_server_time()["serverTime"]
        finished_utc, finished_mono = self.utc(), self.monotonic()
        self.freshness.calibrate(server_time, started_utc, finished_utc, started_mono, finished_mono)

    def _on_data(self, events):
        if not events:
            return
        self.delivery_started = min(float(e.received_at) / 1000 for e in events)
        try:
            for event in events:
                arrival_utc, arrival_mono = self.utc(), self.monotonic()
                raw = MarketInput(str(getattr(event.data_type, "value", event.data_type)), event.symbol,
                                  deepcopy(event.data), event.sequence, event.received_at / 1000,
                                  arrival_utc, arrival_mono, dict(event.options))
                if arrival_utc - raw.received_at > self.freshness.max_age:
                    self.permissions.revoke("sdk_delivery_stale")
                try:
                    self.freshness.validate_input(raw)
                except StaleMarketError as exc:
                    self.failure = exc
                    self.permissions.revoke("market_event_stale")
                self.emit(SessionEvent("binance-market", "market", raw, event.sequence, raw.received_at))
        finally:
            self.delivery_started = None

    def _on_connection(self, notice):
        if notice.get("gap") or notice.get("state") in ("disconnected", "reconnecting", "failed"):
            self.gap_latched = True
            self.permissions.revoke("market_disconnected")
        self.emit(SessionEvent("binance-market", "connection", dict(notice), received_at=self.utc()))

    def _wait(self):
        try:
            self.sdk.wait()
        except BaseException as exc:
            self.failure = exc
            self.permissions.revoke("market_source_failed")
            self.emit(SessionEvent("binance-market", "source_error", exc))
        else:
            if not self.stopping.is_set():
                self.emit(SessionEvent("binance-market", "source_end", None))

    def _monitor(self):
        calibrated_at = self.monotonic()
        while not self.stopping.wait(0.1):
            self.monitor_at = self.monotonic()
            try:
                if self.monotonic() - calibrated_at > 30:
                    self._calibrate()
                    calibrated_at = self.monotonic()
                self.check_backlog()
            except BaseException as exc:
                self.failure = exc
                self.permissions.revoke("market_monitor_failed")
                self.emit(SessionEvent("binance-market", "source_error", exc))
                return

    def check_backlog(self):
        stats = self.sdk.stats
        if stats.oldest_pending_age is not None and stats.oldest_pending_age > self.freshness.max_age:
            raise StaleMarketError("SDK queue is stale")
        if self.delivery_started is not None and self.utc() - self.delivery_started > self.freshness.max_age:
            raise StaleMarketError("SDK in-flight callback is stale")
        if stats.inflight_count and self.delivery_started is None:
            self.permissions.revoke("unverified_sdk_inflight")
            if self.inflight_since is None:
                self.inflight_since = self.monotonic()
            if self.monotonic() - self.inflight_since > self.freshness.max_age:
                raise StaleMarketError("SDK dispatched batch has stalled")
        else:
            self.inflight_since = None

    def check(self):
        if self.failure is not None:
            raise self.failure
        if self.gap_latched:
            from ._market import DataGapError
            raise DataGapError("market continuity lost")
        if self.monitor_at is None or self.monotonic() - self.monitor_at > 1:
            raise StaleMarketError("market monitor is unavailable")
        self.check_backlog()
        self.freshness.check()
        if self.inflight_since is not None:
            raise StaleMarketError("SDK in-flight batch freshness is unknown")

    def observe(self, event):
        self.freshness.observe(event)

    def stop(self):
        self.stopping.set()
        if self.sdk is not None:
            self.sdk.stop()

    def close(self):
        self.stop()
        if self.sdk is not None:
            self.sdk.close()
        for thread in (self.watcher, self.monitor):
            if thread is not None:
                thread.join(timeout=1)
                if thread.is_alive():
                    raise RuntimeError("market source thread did not close")
