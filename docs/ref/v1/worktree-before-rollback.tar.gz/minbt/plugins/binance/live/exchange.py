"""Binance 现实时间 Exchange；事件推进复用核心 Runtime，不预读阻塞历史迭代器。"""

from datetime import datetime, timezone
from dataclasses import replace
from queue import Empty
from threading import Event, Thread
import sys
import time

from ...._runtime import ExchangeBase, Runtime, validate_combination
from ...._validation import positive_number
from ....data.model import normalize_datetime, normalize_symbol
from ....result import _freeze_payload
from ._dependency import load_sdk
from ._freshness import StaleMarketError
from ._market import DataGapError, MarketMapper
from ._source import SDKSource


_TYPES = {"kline", "book_ticker", "order_book", "agg_trade", "mark_price"}
_INTERVALS = {"1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w", "1M"}


def validate_symbols(symbols):
    if isinstance(symbols, (str, bytes)):
        raise TypeError("symbols must be an explicit list")
    values = tuple(normalize_symbol(s) for s in symbols)
    if not values or len(values) != len(set(values)) or "*" in values:
        raise ValueError("symbols must be non-empty, unique, and fixed")
    return values


def validate_environment(environment):
    if environment not in ("demo", "mainnet"):
        raise ValueError("environment must be 'demo' or 'mainnet'")
    return environment


def _close_bounded(close, timeout):
    """SDK 同步 close 可能等待网络线程；有界等待并如实记录资源未关闭。"""
    done, errors = Event(), []

    def invoke():
        try:
            close()
        except BaseException as exc:
            errors.append(exc)
        finally:
            done.set()

    thread = Thread(target=invoke, name="minbt-market-close", daemon=True)
    thread.start()
    if not done.wait(timeout):
        raise RuntimeError("market shutdown timed out; SDK resources may still be closing")
    if errors:
        raise errors[0]


class Exchange(ExchangeBase):
    """从 Binance2 消费实时行情，行情与私有事件始终在 run 线程串行交付。"""

    clock = "wall"

    def __init__(self, *, symbols, interval, environment, closed_only=True, align_timeout=5.0,
                 queue_size=10000, logger=None, sdk_factory=None, _source_factory=None,
                 _utc=time.time, _monotonic=time.monotonic):
        super().__init__(logger=logger)
        self.symbols = validate_symbols(symbols)
        self.environment = validate_environment(environment)
        if interval not in _INTERVALS:
            raise ValueError("unsupported Binance kline interval")
        if closed_only is not True:
            raise ValueError("first live version requires closed_only=True")
        if isinstance(queue_size, bool) or not isinstance(queue_size, int) or queue_size < 1:
            raise ValueError("queue_size must be a positive integer")
        self.interval = interval
        self.align_timeout = positive_number(align_timeout, "align_timeout")
        self.queue_size = queue_size
        self._utc, self._monotonic = _utc, _monotonic
        self._sdk_factory = sdk_factory
        if sdk_factory is None and _source_factory is None:
            self._sdk_factory = load_sdk().Exchange
        self._source_factory = _source_factory  # 测试用源工厂，不接管已运行的 SDK 对象。
        self._subscriptions = [(self.symbols, "kline", {"interval": interval}),
                               (self.symbols, "mark_price", {"speed": "1s"})]
        self._explicit_mark = set()  # 内部标记价用于健康检查，只交付显式订阅的标的。
        self._max_price_age = 5.0  # 运行时取所有账户配置中最严格的时效要求。
        self._source = None  # 资源只在 run 中创建。
        self._has_decision_market = False
        self.market_identity = {"venue": "binance", "market": "usdm", "environment": environment,
                                "symbols": self.symbols}

    def subscribe(self, symbols, data_type, **options):
        with self._lifecycle_lock:
            self._require_ready()
            symbols = validate_symbols(symbols)
            data_type = str(getattr(data_type, "value", data_type))
            if not set(symbols).issubset(self.symbols):
                raise ValueError("subscriptions must use constructor symbols")
            if data_type not in _TYPES:
                raise ValueError(f"unsupported live data type: {data_type}")
            allowed = {"interval"} if data_type == "kline" else ({"speed", "depth_limit"} if data_type == "order_book" else ({"speed"} if data_type == "mark_price" else set()))
            if set(options) - allowed:
                raise TypeError(f"unsupported options for {data_type}")
            if data_type == "kline":
                if options.get("interval", self.interval) != self.interval:
                    raise ValueError("only one kline interval is supported")
                return
            if data_type == "mark_price":
                self._explicit_mark.update(symbols)
                return
            subscription = (symbols, data_type, dict(options))
            if subscription not in self._subscriptions:
                self._subscriptions.append(subscription)

    def describe(self):
        return dict(super().describe(), market_environment=self.environment,
                    subscriptions=tuple((s, k, dict(o)) for s, k, o in self._subscriptions))

    def _now(self):
        return datetime.fromtimestamp(self._utc(), timezone.utc)

    def _check_market(self):
        self._source.check()
        runtime = self._runtime
        with runtime.inbox.mutex:
            if runtime.inbox.queue:
                _, event = runtime.inbox.queue[0]
                if event.received_at is not None and self._utc() - event.received_at > self._max_price_age:
                    raise StaleMarketError("minbt inbox is stale")
        if not self._has_decision_market:
            raise StaleMarketError("initial decision market is missing")

    def _market_ready(self):
        try:
            self._check_market()
            return True
        except StaleMarketError:
            self._runtime.permissions.revoke("market_not_ready")
            return False

    def run(self, *, end=None, control=None, poll_interval=0.2, shutdown_timeout=10.0,
            history_limit="auto", result_dir=None):
        poll_interval = positive_number(poll_interval, "poll_interval")
        shutdown_timeout = positive_number(shutdown_timeout, "shutdown_timeout")
        end = normalize_datetime(end) if end is not None else None
        if control is not None and not callable(control):
            raise TypeError("control must be callable or None")
        with self._lifecycle_lock:
            self._require_ready()
            if not self.strategies:
                raise ValueError("Exchange has no strategies")
            brokers = list(self._unique_brokers())
            validate_combination(self, brokers)
            self._max_price_age = min([5.0] + [getattr(b, "max_price_age", 5.0) for b in brokers])
            runtime = Runtime(self, brokers, history_limit=history_limit, result_dir=result_dir, queue_size=self.queue_size)
            self._claim_run(brokers)
        mapper = MarketMapper(self.symbols, self.interval, self.align_timeout, monotonic=self._monotonic)
        mapper.arm_schedule(self._utc())
        runtime.permissions.add_check(self._check_market)
        step = 0
        first_dt = last_dt = None
        control_state = "continue"
        control_events, data_gaps = [], []
        reason = "end_reached"
        result = None
        try:
            self._source = self._source_factory() if self._source_factory is not None else SDKSource(
                self._sdk_factory, self.environment, self.symbols, self._subscriptions,
                permissions=runtime.permissions, queue_size=self.queue_size, utc=self._utc,
                monotonic=self._monotonic, max_age=self._max_price_age,
            )
            self._current_dt = self._now()
            runtime.start()
            self._source.start(lambda event: runtime.emit(None, event))
            while True:
                self._current_dt = self._now()
                with self._read_only_brokers(brokers, "control"):
                    action = "continue" if control is None else control()
                runtime.set_control(action)
                if action != control_state:
                    control_events.append((self._current_dt, step, action))
                    control_state = action
                if action == "exit":
                    reason = "control_exit"
                    break
                if end is not None and self._current_dt >= end:
                    break
                if runtime.failure is not None:
                    raise runtime.failure
                mapper.check_timeout()
                mapper.check_schedule(self._utc())
                for session in runtime.sessions.values():
                    poll = getattr(session, "poll", None)
                    if poll is not None:
                        poll()
                ready = self._market_ready()
                runtime.maybe_ready(action, ready)
                try:
                    broker, event = runtime.inbox.get(timeout=poll_interval)
                except Empty:
                    continue
                if broker is not None:
                    runtime.apply_input(broker, event)
                    runtime.maybe_ready(action, self._market_ready())
                    continue
                if event.kind == "source_error":
                    raise event.payload
                if event.kind == "source_end":
                    reason = "source_exhausted"
                    break
                if event.kind == "connection":
                    notice = event.payload
                    if notice.get("gap") or notice.get("state") in ("disconnected", "failed", "reconnecting"):
                        data_gaps.append(dict(notice))
                        raise DataGapError("market continuity lost; warmup/recovery is required")
                    continue
                if event.kind != "market":
                    raise ValueError(f"unsupported source event: {event.kind}")
                raw = event.payload
                self._source.observe(raw)
                for batch in mapper.map(raw):
                    is_decision = any(item.event.kind == "kline" for item in batch.items)
                    self._has_decision_market |= is_decision
                    deliver = raw.data_type != "mark_price" or raw.symbol in self._explicit_mark
                    runtime.market(batch, decision_dt=self._now(), action=action, deliver=deliver,
                                   market_ready=self._market_ready(), sample=is_decision)
                    step += 1
                    first_dt = batch.dt if first_dt is None else first_dt
                    last_dt = batch.dt
            runtime.stop()
            self._source.stop()
            deadline = time.monotonic() + shutdown_timeout
            while time.monotonic() < deadline and (not runtime.inbox.empty() or any(getattr(s, "has_pending", False) for s in runtime.sessions.values())):
                try:
                    broker, event = runtime.inbox.get(timeout=min(poll_interval, max(0.001, deadline - time.monotonic())))
                except Empty:
                    continue
                if broker is not None:
                    runtime.apply_input(broker, event)
            status = "exited" if reason == "control_exit" else "completed"
            self._current_dt = self._now()
            runtime.sample()
            result = runtime.freeze({"status": status, "reason": reason, "control_state": control_state,
                                     "control_events": tuple(control_events), "end": end,
                                     "first_dt": first_dt, "last_dt": last_dt, "step_count": step,
                                     "strategy_ids": tuple(self.strategies), "data_gaps": tuple(data_gaps),
                                     "market_environment": self.environment})
            with self._read_only_brokers(brokers, "on_finish"):
                for strategy in self.strategies.values():
                    strategy.on_finish()
            self._run_state = status
            return result
        except BaseException as exc:
            runtime.permissions.revoke("run_failed")
            self._run_state = "failed"
            try:
                exc.partial_result = runtime.freeze({"status": "failed", "reason": type(exc).__name__,
                                                     "data_gaps": tuple(data_gaps), "step_count": step})
            except BaseException:
                pass  # 保留原始失败，不能被冻结故障替换。
            raise
        finally:
            active_error = sys.exc_info()[1]
            errors = []
            closers = [runtime.close]
            if self._source is not None:
                closers.append(lambda: _close_bounded(self._source.close, shutdown_timeout))
            for close in closers:
                try:
                    close()
                except BaseException as exc:
                    errors.append(exc)
            if errors:
                failure = errors[0] if active_error is None else active_error
                failure.cleanup_errors = tuple(getattr(failure, "cleanup_errors", ())) + tuple(errors)
                if active_error is None:
                    self._run_state = "failed"
                    if result is not None:
                        failure.partial_result = replace(result, meta=_freeze_payload(dict(
                            result.meta, status="failed", reason="cleanup_failed",
                            cleanup_errors=tuple(type(error).__name__ + ": " + str(error) for error in errors),
                        )))
                    raise failure
