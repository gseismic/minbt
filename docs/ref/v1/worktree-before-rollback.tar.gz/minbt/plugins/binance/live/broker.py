"""Binance 外部账户门面；账户事实来自交易所，不继承模拟账本。"""

from collections import OrderedDict
from dataclasses import asdict
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from threading import Lock, get_ident
from types import MappingProxyType
from uuid import uuid4

from ....broker.execution import inflight_order, same_target
from ....broker.order import Order
from ....broker.pnl import Pnl
from ....errors import IncompleteAccountingError, UnsupportedCapabilityError
from ....events import AccountUpdate, SessionEvent
from ....result import snapshot_order
from ._dependency import load_sdk
from ._rules import decimal, finite_float, text
from .exchange import validate_environment, validate_symbols


ZERO = Decimal("0")


class Broker:
    """单向 USDT 永续账户的交易接口，提交意图与确认成交相分离。"""

    execution_kind = "external"

    def __init__(self, *, api_key, api_secret, environment, symbols, account_id, state_dir,
                 exit_mode="local", max_price_age=5.0, intent_ttl=5.0, leverage=None,
                 sync_interval=30.0, max_sync_age=60.0, sdk_factory=None):
        self.environment = validate_environment(environment)
        self.symbols = validate_symbols(symbols)
        if not isinstance(account_id, str) or not account_id.strip():
            raise ValueError("account_id must be a non-empty alias")
        if not isinstance(api_key, str) or not api_key or not isinstance(api_secret, str) or not api_secret:
            raise ValueError("api_key and api_secret are required")
        if exit_mode not in ("local", "native"):
            raise ValueError("exit_mode must be 'local' or 'native'")
        self.max_price_age = finite_float(decimal(max_price_age))
        self.intent_ttl = finite_float(decimal(intent_ttl))
        self.sync_interval = finite_float(decimal(sync_interval))
        self.max_sync_age = finite_float(decimal(max_sync_age))
        if min(self.max_price_age, self.intent_ttl, self.sync_interval, self.max_sync_age) <= 0:
            raise ValueError("price age, intent ttl and sync intervals must be positive")
        if self.max_sync_age < self.sync_interval:
            raise ValueError("max_sync_age must be at least sync_interval")
        self.account_id = account_id
        self.state_dir = str(Path(state_dir).expanduser().resolve())
        self.exit_mode = exit_mode
        self.expected_leverage = None if leverage is None else decimal(leverage)
        if self.expected_leverage is not None and (self.expected_leverage < 1 or self.expected_leverage % 1):
            raise ValueError("leverage must be a positive integer")
        self._api_key, self._api_secret = api_key, api_secret  # 仅用于创建 SDK，不进入描述或日志。
        if sdk_factory is None:
            sdk = load_sdk()
            if not callable(getattr(sdk.RestAPI, "send_permission", None)):
                raise ImportError("crypto_api requires the verified send_permission extension; see docs/dev/PLAN-070-live-trading.md")
            sdk_factory = sdk.Broker
        self._sdk_factory = sdk_factory
        self._session = None  # 一次 run 专属会话，所有写入口由其许可约束。
        self._started = False
        self._claim_lock = Lock()  # 会话认领失败不能覆盖另一个运行器的绑定。
        self.orders = OrderedDict()
        self._exact = {}  # 保留 Decimal 数量、累计量和固定目标，不用展示 float 回写账本。
        self._targets = {}  # 与 sim 共用的固定数量目标占用。
        self._positions = {}  # 远端绝对持仓投影；成交通知不会再次加仓。
        self._prices = {}  # 仅由已验证的标记价事实更新。
        self._wallet = self._available = ZERO
        self._realized = self._fees = self._funding = ZERO
        self._external_flows = ZERO
        self._fills = OrderedDict()
        self._cashflows = OrderedDict()
        self._accounting_issues = set()
        self._account_version = 0
        self._sync_pending = set()  # 已有成交但未核对账户覆盖关系的标的。
        self._protection = None
        self._initial_equity = None
        self._initial_unrealized = ZERO
        self._initial_pnl = None  # 本次会话的累计盈亏起点，用于和期末累计数相减。
        self._last_account_state = None  # 价格重估不重复生成账户决策通知。

    def describe(self):
        return {"execution_kind": "external", "execution_model": "exchange",
                "environment": self.environment, "uses_real_funds": self.environment == "mainnet",
                "account_id": self.account_id, "state_dir": self.state_dir,
                "valuation_source": "mark_price.price",
                "market": {"venue": "binance", "market": "usdm", "environment": self.environment, "symbols": self.symbols}}

    def create_session(self):
        if self._started:
            raise RuntimeError("Broker has already been used in another run")
        from ._account import AccountSession
        return AccountSession(self)

    def _portfolio(self, portfolio):
        if portfolio not in (None, "main"):
            raise UnsupportedCapabilityError("live Broker only supports portfolio='main'")
        return "main"

    def _assert_writable(self):
        if self._session is None:
            raise RuntimeError("live Broker must be started by Exchange.run")
        if get_ident() != self._session.owner_thread:
            raise RuntimeError("Broker can only be changed by its run thread")
        if self._session.controlled_depth:
            return
        self._session.context.permissions.assert_writable()

    @staticmethod
    def _old_options(price, price_dt, leverage):
        if any(v is not None for v in (price, price_dt, leverage)):
            raise ValueError("live execution does not accept price/price_dt/per-order leverage")

    def _new_order(self, symbol, qty, source, *, order_type="market", limit_price=None,
                   status="pending", reason_code=None, reason=None):
        order_id = "order-" + uuid4().hex
        order = Order(order_id, symbol, "main", order_type, source,
                      "buy" if qty > 0 else ("sell" if qty < 0 else "none"), finite_float(qty), status,
                      limit_price=None if limit_price is None else finite_float(limit_price),
                      reason=reason, reason_code=reason_code, client_order_id="mb" + uuid4().hex,
                      created_dt=self._session.context.now(), execution_state="queued" if status == "pending" else None)
        return order

    def _save_order(self, order, exact=None):
        exact = self._exact.get(order.id, {}) if exact is None else exact
        self._session.store.put("orders", order.id, {"order": asdict(order), "exact": exact})
        if order.client_order_id is not None:
            self._session.store.put("client_links", order.client_order_id, order.id)
        if order.exchange_order_id is not None:
            self._session.store.put("exchange_links", f"{order.symbol}:{order.exchange_order_id}", order.id)

    def _load_order(self, order_id):
        cached = self.orders.get(order_id)
        if cached is not None:
            return cached
        if self._session is None or self._session.store is None or self._session.store.connection is None:
            return None
        value = self._session.store.get("orders", order_id)
        if value is None:
            return None
        row = value["order"]
        for name in ("qty", "filled_qty", "requested_price", "limit_price", "avg_price"):
            if row.get(name) is not None:
                row[name] = finite_float(decimal(row[name]))
        for name in ("created_dt", "updated_dt"):
            if row.get(name) is not None:
                row[name] = datetime.fromisoformat(row[name])
        order = Order(**row)
        self.orders[order_id], self._exact[order_id] = order, value["exact"]
        if value["exact"].get("target") is not None:
            self._targets[order_id] = decimal(value["exact"]["target"])
        return order

    def _find_order(self, client_id=None, remote_id=None, symbol=None):
        cached = next((o for o in self.orders.values() if (client_id is not None and o.client_order_id == client_id) or
                       (remote_id is not None and o.exchange_order_id == str(remote_id) and o.symbol == symbol)), None)
        if cached is not None:
            return cached
        local_id = self._session.store.get("client_links", client_id) if client_id is not None else None
        if local_id is None and remote_id is not None and symbol is not None:
            local_id = self._session.store.get("exchange_links", f"{symbol}:{remote_id}")
        return None if local_id is None else self._load_order(local_id)

    def _notify_order(self, order):
        self._session.emit(SessionEvent(self.account_id, "on_order", snapshot_order(order)))

    def _reject(self, symbol, qty, source, code, *, order_type="market", limit_price=None, skipped=False):
        order = self._new_order(symbol, qty, source, order_type=order_type, limit_price=limit_price,
                                status="skipped" if skipped else "rejected", reason_code=code, reason=code)
        exact = {"qty": text(qty), "filled_qty": "0", "avg_price": "0", "target": None,
                 "reduce_only": False, "exits": {}, "position_before": text(self._position_size(symbol))}
        self._save_order(order, exact)
        self.orders[order.id] = order
        self._exact[order.id] = exact
        self._notify_order(order)
        return order

    def _submit(self, symbol, qty, source, *, order_type="market", limit_price=None,
                portfolio=None, target=None, reduce_only=False, exits=None):
        self._assert_writable()
        self._portfolio(portfolio)
        symbol = str(symbol).strip().upper()
        if symbol not in self.symbols:
            raise ValueError("symbol is outside the fixed account symbols")
        exits = self._protection.validate(exits or {})
        if self.exit_mode == "native":
            self._protection._validate_prices(symbol, exits)
        qty = decimal(qty, "qty")
        if qty == 0:
            raise ValueError("qty must be non-zero")
        price = decimal(limit_price) if order_type == "limit" else self._prices.get(symbol)
        if price is None or price <= 0:
            return self._reject(symbol, qty, source, "price_unavailable")
        if symbol in self._sync_pending:
            return self._reject(symbol, qty, source, "account_sync_pending")
        pending = inflight_order(self.orders.values(), symbol, "main")
        if target is not None and same_target(pending, target, self._targets):
            return pending
        if pending is not None:
            return self._reject(symbol, qty, source, "target_in_flight")
        issue = self._session.rules[symbol].validate(qty, price, order_type, reduce_only=reduce_only)
        if issue:
            return self._reject(symbol, qty, source, issue, order_type=order_type, limit_price=limit_price,
                                skipped=target is not None)
        internal_reduction = (self._session.controlled_depth and reduce_only and self.exit_mode == "native"
                              and self._protection.allows_reduction(symbol, qty)
                              and self._session.private_connected and self._session.account_synced
                              and not self._session.dirty.is_set() and not self._session.failure)
        if not self._session.ready and not internal_reduction:
            return self._reject(symbol, qty, source, "account_sync_pending")
        if not internal_reduction and not self._protection.can_change(symbol, qty):
            return self._reject(symbol, qty, source, "protection_recovery_pending")
        current = self._position_size(symbol)
        if reduce_only and (current == 0 or current * qty >= 0 or abs(qty) > abs(current)):
            return self._reject(symbol, qty, source, "reduce_only_conflict")
        increasing = max(Decimal("0"), abs(current + qty) - abs(current))
        reserve = increasing * price / self._session.leverages[symbol]
        if reserve > decimal(self.get_cash()):
            return self._reject(symbol, qty, source, "insufficient_available_balance")
        order = self._new_order(symbol, qty, source, order_type=order_type, limit_price=limit_price)
        exact = {"qty": text(qty), "filled_qty": "0", "avg_price": "0", "target": None if target is None else text(target),
                 "reduce_only": reduce_only, "exits": exits or {}, "position_before": text(self._position_size(symbol))}
        if self._protection.states.get(symbol) is not None:
            exact["life_id"] = self._protection.states[symbol]["life_id"]
        payload = {"symbol": symbol, "side": "BUY" if qty > 0 else "SELL", "qty": text(abs(qty)),
                   "client_order_id": order.client_order_id}
        if reduce_only:
            payload["reduce_only"] = True
        if order_type == "limit":
            payload["limit_price"] = text(price)
        request = self._session.new_request(order, "create", "submit_" + order_type + "_order", payload)
        with self._session.durable():
            self._save_order(order, exact)
            self._session.store.put("requests", request.id, request.record())
        self.orders[order.id], self._exact[order.id] = order, exact
        self._session.reservations[order.id] = reserve
        if target is not None:
            self._targets[order.id] = target
        self._session.enqueue(request)
        self._notify_order(order)
        return order

    def submit_market_order(self, symbol, qty, price=None, *, price_dt=None, leverage=None, portfolio=None,
                            stop_loss_price=None, take_profit_price=None, trailing_stop_pct=None, trailing_stop_amount=None):
        self._old_options(price, price_dt, leverage)
        exits = {"stop_loss_price": stop_loss_price, "take_profit_price": take_profit_price,
                 "trailing_stop_pct": trailing_stop_pct, "trailing_stop_amount": trailing_stop_amount}
        return self._submit(symbol, qty, "submit_market_order", portfolio=portfolio, exits={k: v for k, v in exits.items() if v is not None})

    def submit_limit_order(self, symbol, qty, limit_price, *, price_dt=None, portfolio=None,
                           stop_loss_price=None, take_profit_price=None, trailing_stop_pct=None, trailing_stop_amount=None):
        self._old_options(None, price_dt, None)
        if decimal(limit_price) <= 0:
            raise ValueError("limit_price must be positive")
        exits = {"stop_loss_price": stop_loss_price, "take_profit_price": take_profit_price,
                 "trailing_stop_pct": trailing_stop_pct, "trailing_stop_amount": trailing_stop_amount}
        return self._submit(symbol, qty, "submit_limit_order", order_type="limit", limit_price=limit_price,
                            portfolio=portfolio, exits={k: v for k, v in exits.items() if v is not None})

    def _target(self, symbol, target, source, *, portfolio=None, exits=None):
        self._assert_writable()
        self._portfolio(portfolio)
        symbol = str(symbol).strip().upper()
        if symbol not in self.symbols:
            raise ValueError("symbol is outside the fixed account symbols")
        exits = self._protection.validate(exits or {})
        if self.exit_mode == "native":
            self._protection._validate_prices(symbol, exits)
        target = self._session.rules[symbol].normalize_target(decimal(target))
        if symbol in self._sync_pending:
            return self._reject(symbol, ZERO, source, "account_sync_pending")
        pending = inflight_order(self.orders.values(), symbol, "main")
        if same_target(pending, target, self._targets):
            return pending
        if pending is not None:
            return self._reject(symbol, ZERO, source, "target_in_flight")
        delta = target - self._position_size(symbol)
        if delta == 0:
            return self._reject(symbol, ZERO, source, "position_empty" if source == "close_position" else "target_unchanged", skipped=True)
        return self._submit(symbol, delta, source, portfolio=portfolio, target=target,
                            reduce_only=source == "close_position", exits=exits)

    def order_target_size(self, symbol, target_size, price=None, *, price_dt=None, leverage=None, portfolio=None, **exits):
        self._old_options(price, price_dt, leverage)
        return self._target(symbol, target_size, "target_size", portfolio=portfolio, exits=exits)

    def order_target_value(self, symbol, target_value, price=None, *, price_dt=None, leverage=None, portfolio=None, **exits):
        self._old_options(price, price_dt, leverage)
        symbol = str(symbol).strip().upper()
        reference = self._prices.get(symbol)
        if reference is None:
            raise ValueError("a fresh reference price is required")
        return self._target(symbol, decimal(target_value) / reference, "target_value", portfolio=portfolio, exits=exits)

    def order_target_percent(self, symbol, target_percent, price=None, *, price_dt=None, leverage=None, portfolio=None, **exits):
        self._old_options(price, price_dt, leverage)
        symbol = str(symbol).strip().upper()
        reference = self._prices.get(symbol)
        if reference is None:
            raise ValueError("a fresh reference price is required")
        target = self._equity() * decimal(target_percent) / reference
        return self._target(symbol, target, "target_percent", portfolio=portfolio, exits=exits)

    def close_position(self, symbol, price=None, *, price_dt=None, portfolio=None):
        self._old_options(price, price_dt, None)
        return self._target(symbol, ZERO, "close_position", portfolio=portfolio)

    def cancel_order(self, order_id):
        self._assert_writable()
        order = self.orders.get(order_id)
        if order is None:
            raise ValueError("unknown local order")
        if order.is_done:
            return order
        self._session.cancel(order)
        return order

    def add_portfolio(self, name, cash):
        raise UnsupportedCapabilityError("live accounts do not support virtual portfolios")

    def close_portfolio(self, portfolio):
        raise UnsupportedCapabilityError("live accounts do not support closing virtual portfolios")

    def set_exit(self, order_id, **options):
        self._assert_writable()
        return self._protection.set(order_id, options)

    def clear_exit(self, order_id, **options):
        self._assert_writable()
        return self._protection.clear(order_id, options)

    def get_exit(self, order_id):
        return None if self._protection is None else self._protection.get(order_id)

    def get_exit_status(self, order_id):
        return None if self._protection is None else self._protection.status(order_id)

    def add_exit(self, order_id, *, name=None, condition, state=None):
        raise UnsupportedCapabilityError("live Broker does not support function exits; use durable declarative exits")

    def _position_size(self, symbol):
        return self._positions.get(symbol, {}).get("size", ZERO)

    def _unrealized(self):
        return sum(((self._prices[s] - p["entry_price"]) * p["size"] if s in self._prices else p["unrealized_pnl"] for s, p in self._positions.items()), ZERO)

    def _equity(self):
        return self._wallet + self._unrealized()

    def get_position_size(self, symbol, portfolio=None):
        self._portfolio(portfolio)
        return finite_float(self._position_size(str(symbol).strip().upper()))

    def get_position_sizes(self, portfolio=None):
        self._portfolio(portfolio)
        return {s: finite_float(p["size"]) for s, p in self._positions.items() if p["size"]}

    def get_positions(self, portfolio=None):
        self._portfolio(portfolio)
        return MappingProxyType({s: MappingProxyType({"size": finite_float(p["size"]), "cost_price": finite_float(p["entry_price"]),
                                                     "unrealized_pnl": finite_float(p["unrealized_pnl"]), "symbol": s})
                                 for s, p in self._positions.items() if p["size"]})

    def get_total_equity(self):
        return finite_float(self._equity())

    def get_equity(self, portfolio=None):
        self._portfolio(portfolio)
        return self.get_total_equity()

    def get_cash(self, portfolio=None, include_locked=False):
        self._portfolio(portfolio)
        reserved = sum(self._session.reservations.values(), ZERO) if self._session is not None else ZERO
        return finite_float(self._wallet if include_locked else max(ZERO, self._available - reserved))

    def get_portfolios(self):
        return ["main"]

    def get_order(self, order_id):
        return self._load_order(order_id)

    def get_orders(self, *, portfolio=None, symbol=None):
        self._portfolio(portfolio)
        return [o for o in self.orders.values() if symbol is None or o.symbol == str(symbol).strip().upper()]

    def get_active_order(self, symbol, *, portfolio=None):
        self._portfolio(portfolio)
        return None if self._protection is None else self._protection.active_order(str(symbol).strip().upper())

    def get_total_pnl(self, symbol=None):
        if symbol is not None:
            raise UnsupportedCapabilityError("live Broker currently exposes account-level PnL")
        if self._accounting_issues:
            raise IncompleteAccountingError(sorted(self._accounting_issues))
        return Pnl(finite_float(self._realized), finite_float(self._unrealized()), finite_float(self._fees),
                   funding_pnl=finite_float(self._funding))

    def get_fills(self):
        return list(self._fills.values())

    def get_cashflows(self):
        return list(self._cashflows.values())

    def _prune_history(self, limit):
        pinned = set()
        if self._protection is not None:
            for symbol, state in self._protection.states.items():
                if self._position_size(symbol):
                    pinned.update(state["handles"])
        keep = set(list(self.orders)[-limit:]) | pinned
        removed = [key for key, order in self.orders.items() if key not in keep and order.is_done]
        truncated = bool(removed) or len(self._fills) > limit or len(self._cashflows) > limit
        for key in removed:
            self.orders.pop(key)
            self._exact.pop(key, None)
            self._targets.pop(key, None)
        for records in (self._fills, self._cashflows):
            while len(records) > limit:
                records.popitem(last=False)
        for key in tuple(self._session.requests):
            if self._session.requests[key].phase not in ("queued", "dispatch_prepared", "unknown"):
                self._session.requests.pop(key)
        return truncated

    def get_health(self):
        if self._session is None:
            return MappingProxyType({"status": "reconciling", "ready": False, "reason": "not_started"})
        return self._session.health()

    def get_result_metadata(self):
        health = self.get_health()
        return {"account_synced": health.get("account_synced", False), "protection_ready": health.get("protection_ready", False),
                "protection_issues": health.get("protection_issues", ()), "initial_equity": self._initial_equity,
                "initial_unrealized_pnl": finite_float(self._initial_unrealized),
                "initial_pnl": self._initial_pnl,
                "unresolved_orders": tuple(o.id for o in self.orders.values() if not o.is_done)}

    def _notify_account(self):
        ready = self._session.ready and self._session.context.permissions.enabled
        state = (self._wallet, self._available, tuple(sorted((s, p["size"]) for s, p in self._positions.items())), ready)
        if state == self._last_account_state:
            return
        self._last_account_state = state
        self._account_version += 1
        self._session.emit(SessionEvent(self.account_id, "on_account", AccountUpdate(
            self.account_id, self._account_version, self._session.context.now(), self.get_cash(), self.get_total_equity(),
            MappingProxyType(self.get_position_sizes()), ready,
        )))
