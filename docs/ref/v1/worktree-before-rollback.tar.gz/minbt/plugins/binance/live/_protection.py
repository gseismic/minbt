"""声明式本地保护的耐久状态；追踪极值、触发义务和价格水位同步提交。"""

from contextlib import contextmanager
from copy import deepcopy
from types import MappingProxyType
from uuid import uuid4

from ....broker.exit import ExitConfig
from ....errors import UnsupportedCapabilityError
from ._rules import decimal, finite_float, text


class ProtectionManager:
    """按净持仓生命周期恢复保护，明确的无配置状态与日志缺失分开处理。"""

    def __init__(self, session):
        self.session = session
        self.broker = session.broker
        self.states = {}  # 标的到已提交的配置、极值、触发义务及生命周期。
        self.issues = []  # 恢复完成前参与账户 ready 屏障。

    @property
    def ready(self):
        return not self.issues

    @property
    def diagnostics(self):
        return tuple(self.issues)

    def validate(self, options):
        allowed = {"stop_loss_price", "take_profit_price", "trailing_stop_pct", "trailing_stop_amount"}
        if set(options) - allowed:
            raise UnsupportedCapabilityError("live exits only support durable declarative parameters")
        result = {}
        for key, value in options.items():
            if value is None:
                continue
            value = decimal(value, key)
            if value <= 0 or (key == "trailing_stop_pct" and value >= 1):
                raise ValueError(f"invalid {key}")
            result[key] = text(value)
        if "trailing_stop_pct" in result and "trailing_stop_amount" in result:
            raise ValueError("choose one trailing stop model")
        return result

    def restore(self):
        self.states = dict(self.session.store.records("protection"))
        for symbol, position in self.broker._positions.items():
            if not position["size"]:
                continue
            state = self.states.get(symbol)
            if state is None or state.get("schema") != 1:
                self.issues.append(f"{symbol}:protection_recovery_pending")
            elif state["status"] in ("armed", "triggered", "exiting") and state.get("options"):
                # 首版不以 OHLC 或当前价格伪造停机期间的完整同源路径。
                self.issues.append(f"{symbol}:offline_protection_path_missing")

    def _save(self, symbol, state):
        with self.session.durable():
            self.session.store.put("protection", symbol, state)
            self.session.store.append("protection", {"symbol": symbol, "state": state})
        self.states[symbol] = state

    def synchronize(self, old_positions):
        for symbol in self.broker.symbols:
            size = self.broker._position_size(symbol)
            previous = old_positions.get(symbol, 0)
            state = self.states.get(symbol)
            if size == 0:
                if state is not None and state["status"] != "cleared":
                    self._save(symbol, dict(state, status="cleared", cleared_reason="confirmed_flat"))
                continue
            new_life = previous == 0 or previous * size < 0
            if new_life:
                state = {"schema": 1, "life_id": uuid4().hex, "direction": 1 if size > 0 else -1,
                         "version": 0, "options": {}, "anchor": None, "threshold": None,
                         "status": "none", "handles": [], "trigger_reason": None,
                         "exit_order_id": None, "watermark": None}
            if state is None:
                self.issues.append(f"{symbol}:protection_recovery_pending")
                continue
            changed = new_life
            for order in self.broker.orders.values():
                if order.symbol != symbol or not order.filled_qty or order.id in state["handles"]:
                    continue
                # 只有本次净持仓开始之后确认的订单才能绑定，旧日志中的句柄不继承。
                if order.id not in self.session.recent_filled_orders:
                    continue
                state = deepcopy(state)
                state["handles"].append(order.id)
                options = self.broker._exact.get(order.id, {}).get("exits", {})
                if options:
                    state["options"].update(self.validate(options))
                    state["status"] = "armed"
                    state["version"] += 1
                    if state["anchor"] is None:
                        state["anchor"] = text(self.broker._positions[symbol]["entry_price"])
                changed = True
            if changed:
                self._save(symbol, state)

    def _find(self, order_id):
        order = self.broker.orders.get(order_id)
        if order is None:
            raise ValueError("unknown local order")
        state = self.states.get(order.symbol)
        if state is None or order_id not in state["handles"] or not self.broker._position_size(order.symbol):
            raise ValueError("order no longer belongs to the current position lifecycle")
        return order, state

    def set(self, order_id, options):
        values = self.validate(options)
        if not values:
            raise ValueError("at least one exit condition is required")
        order, old = self._find(order_id)
        state = deepcopy(old)
        state["options"].update(values)
        self.validate(state["options"])
        state["version"] += 1
        if state["status"] not in ("triggered", "exiting"):
            state["status"] = "armed"
        if state["anchor"] is None:
            state["anchor"] = text(self.broker._prices[order.symbol])
        self._save(order.symbol, state)
        return self.get(order_id)

    def clear(self, order_id, flags):
        order, old = self._find(order_id)
        allowed = {"stop_loss_price", "take_profit_price", "trailing_stop", "custom"}
        if set(flags) - allowed or any(not isinstance(v, bool) for v in flags.values()):
            raise ValueError("invalid exit clear flags")
        flags = dict({k: True for k in allowed}, **flags)
        if not any(flags.values()):
            raise ValueError("at least one clear flag is required")
        state = deepcopy(old)
        for key in ("stop_loss_price", "take_profit_price"):
            if flags[key]:
                state["options"].pop(key, None)
        if flags["trailing_stop"]:
            state["options"].pop("trailing_stop_pct", None)
            state["options"].pop("trailing_stop_amount", None)
            state["anchor"] = state["threshold"] = None
        state["version"] += 1
        # 清除配置不取消已经触发的退出义务，也不把在途退出变为未发送。
        if state["status"] not in ("triggered", "exiting"):
            state["status"] = "armed" if state["options"] else "cleared"
        self._save(order.symbol, state)
        return self.get(order_id)

    def get(self, order_id):
        try:
            order, state = self._find(order_id)
        except ValueError:
            return None
        options = {k: finite_float(decimal(v)) for k, v in state["options"].items()}
        return ExitConfig(order_id, order.symbol, "main", active=state["status"] in ("armed", "triggered", "exiting"),
                          trailing_anchor=None if state["anchor"] is None else finite_float(decimal(state["anchor"])), **options)

    def status(self, order_id):
        order, state = self._find(order_id)
        return MappingProxyType({"status": "recovery_pending" if self.issues else state["status"],
                                 "life_id": state["life_id"], "version": state["version"],
                                 "threshold": state["threshold"], "issues": tuple(self.issues)})

    def active_order(self, symbol):
        state = self.states.get(symbol)
        if state is None or state["status"] == "cleared" or not state["handles"]:
            return None
        return self.broker.orders.get(state["handles"][-1])

    def can_change(self, symbol, qty):
        return self.ready

    @contextmanager
    def controlled(self):
        self.session.controlled_depth += 1
        try:
            yield
        finally:
            self.session.controlled_depth -= 1

    def on_market(self, prices, watermark):
        if not self.ready:
            return
        for symbol, price in prices.items():
            old = self.states.get(symbol)
            if old is None or old["status"] not in ("armed", "triggered", "exiting"):
                continue
            size = self.broker._position_size(symbol)
            if not size:
                continue
            state = deepcopy(old)
            options = state["options"]
            direction = 1 if size > 0 else -1
            if state["status"] == "armed":
                stop, take = options.get("stop_loss_price"), options.get("take_profit_price")
                reason = "stop_loss_price" if stop is not None and (price - decimal(stop)) * direction <= 0 else None
                if take is not None and (price - decimal(take)) * direction >= 0:
                    reason = reason or "take_profit_price"
                if options.get("trailing_stop_pct") or options.get("trailing_stop_amount"):
                    anchor = decimal(state["anchor"]) if state["anchor"] is not None else price
                    anchor = max(anchor, price) if size > 0 else min(anchor, price)
                    distance = anchor * decimal(options["trailing_stop_pct"]) if options.get("trailing_stop_pct") else decimal(options["trailing_stop_amount"])
                    threshold = anchor - distance * direction
                    state["anchor"], state["threshold"] = text(anchor), text(threshold)
                    if (price - threshold) * direction <= 0:
                        reason = reason or "trailing_stop"
                if reason:
                    state["status"], state["trigger_reason"] = "triggered", reason
            state["watermark"] = watermark
            with self.session.durable():
                self._save(symbol, state)
                if state["status"] in ("triggered", "exiting") and self.session.account_synced:
                    pending = next((o for o in self.broker.orders.values() if o.symbol == symbol and not o.is_done), None)
                    with self.controlled():
                        if pending is not None and pending.source != "close_position":
                            self.session.cancel(pending)
                        elif pending is None:
                            order = self.broker.close_position(symbol)
                            if not order.is_done:
                                state["status"], state["exit_order_id"] = "exiting", order.id
                                self._save(symbol, state)
