"""交易所托管固定价保护；条件单身份与触发后的普通订单分别核对。"""

from copy import deepcopy
import time
from types import MappingProxyType
from uuid import uuid4

from ....errors import TradingPermissionError, UnsupportedCapabilityError
from ._protection import ProtectionManager
from ._rules import decimal, text


_CONDITIONS = {"stop_loss_price": ("STOP_MARKET", "submit_stop_loss_order"),
               "take_profit_price": ("TAKE_PROFIT_MARKET", "submit_take_profit_order")}
_TERMINAL = {"CANCELED", "EXPIRED", "REJECTED", "FINISHED"}
_LOCAL_TERMINAL = {"not_sent", "failed"}


def _true(value):
    return value is True or value == "true"


class NativeProtectionManager(ProtectionManager):
    """仅发送 close-all 市价条件单，不以本地撤销及时性实现只减仓。"""

    def __init__(self, session):
        super().__init__(session)
        self.states = dict(session.store.iter_records("protection"))
        # 旧生命周期未清理的记录也必须恢复，不能被当前 symbol 状态覆盖。
        self.algos = {k: r for k, r in session.store.iter_records("algos") if not r.get("settled")}
        self._retry_after = 0.0

    def validate(self, options):
        if any(options.get(k) is not None for k in ("trailing_stop_pct", "trailing_stop_amount")):
            raise UnsupportedCapabilityError("native protection only supports fixed stop/take prices")
        return super().validate(options)

    def _validate_prices(self, symbol, values):
        rule = self.session.rules[symbol].filters["PRICE_FILTER"]
        tick = decimal(rule["tickSize"])
        for value in values.values():
            price = decimal(value)
            if tick <= 0 or price % tick or not decimal(rule["minPrice"]) <= price <= decimal(rule["maxPrice"]):
                raise ValueError("native trigger price does not satisfy PRICE_FILTER")

    def _rows(self, symbol, life_id=None):
        return [r for r in self.algos.values() if r["symbol"] == symbol and (life_id is None or r["life_id"] == life_id)]

    @staticmethod
    def _closed(row):
        return row["status"] in _TERMINAL | _LOCAL_TERMINAL

    def _pending(self, row):
        return not self._closed(row) or bool(row.get("actual_order_id") and not row.get("actual_done"))

    def _desired(self, row):
        state = self.states.get(row["symbol"])
        size = self.broker._position_size(row["symbol"])
        return (state is not None and state["life_id"] == row["life_id"] and not state.get("native_triggered")
                and size * state["direction"] > 0 and state["options"].get(row["option"]) == row["trigger_price"])

    def _status(self, symbol):
        state = self.states.get(symbol)
        rows = self._rows(symbol)
        if self.issues or any(r.get("invalid") for r in rows):
            return "recovery_pending"
        if any(r["status"] == "unknown" or r.get("cancel_phase") == "unknown" for r in rows):
            return "recovery_pending"
        if any(r["status"] == "failed" or r.get("cancel_phase") == "rejected" for r in rows):
            return "failed"
        active = [r for r in rows if self._pending(r)]
        if state is None:
            return "recovery_pending" if active else "none"
        if state.get("native_triggered") and not state.get("native_settled"):
            return "exiting"
        if not self.broker._position_size(symbol) or not state["options"]:
            return "clearing" if active else "cleared"
        for option, price in state["options"].items():
            matching = [r for r in active if r["life_id"] == state["life_id"] and r["option"] == option and r["trigger_price"] == price]
            if not any(r.get("verified") and r["status"] == "NEW" and not r.get("cancel_phase") for r in matching):
                if any(self._closed(r) and r["status"] != "not_sent" for r in rows if self._desired(r)):
                    return "failed"
                return "updating" if any(r.get("verified") for r in active) else "requested"
        if any(not self._desired(r) or r.get("cancel_phase") for r in active):
            return "updating"
        return "active"

    @property
    def ready(self):
        return not self.issues and all(self._status(s) in ("none", "cleared", "active") for s in self.broker.symbols)

    @property
    def diagnostics(self):
        return tuple(self.issues) + tuple(f"{s}:protection_{self._status(s)}" for s in self.broker.symbols
                                          if self._status(s) in ("failed", "recovery_pending"))

    def restore(self):
        for symbol in self.broker.symbols:
            state, size = self.states.get(symbol), self.broker._position_size(symbol)
            if size and (state is None or state.get("schema") != 1 or state["direction"] * size <= 0):
                self.issues.append(f"{symbol}:protection_recovery_pending")
            if state is not None:
                try:
                    self.validate(state["options"])
                    self._validate_prices(symbol, state["options"])
                except (ValueError, TypeError, UnsupportedCapabilityError):
                    self.issues.append(f"{symbol}:unsupported_protection_configuration")

    def _save_algo(self, row):
        with self.session.durable():
            self.session.store.put("algos", row["client_id"], row)
        self.algos[row["client_id"]] = row

    def synchronize(self, old_positions):
        # 父类负责把真实成交句柄及附带参数绑定到已核对的净持仓生命周期。
        old_positions = dict(old_positions)
        for symbol, state in self.states.items():
            size = self.broker._position_size(symbol)
            if state.get("native_triggered") and not state.get("native_settled") and size * state["direction"] > 0:
                # 触发与撤入场单之间可以短暂归零；最后成交仍属原退出义务。
                old_positions[symbol] = size
        super().synchronize(old_positions)
        for symbol, state in list(self.states.items()):
            if state.get("native_triggered") and self.broker._position_size(symbol):
                self._save(symbol, dict(state, status="exiting"))
        self.drive()

    def set(self, order_id, options):
        order, _ = self._find(order_id)
        self._validate_prices(order.symbol, self.validate(options))
        result = super().set(order_id, options)
        self._changed()
        return result

    def clear(self, order_id, flags):
        result = super().clear(order_id, flags)
        self._changed()
        return result

    def _changed(self):
        self.session.context.permissions.revoke("not_ready")
        self.drive()
        self.broker._notify_account()

    def status(self, order_id):
        order = self.broker._load_order(order_id)
        state = self.states.get(order.symbol) if order is not None else None
        if state is None or order_id not in state["handles"]:
            raise ValueError("order no longer belongs to the current position lifecycle")
        return MappingProxyType({"status": self._status(order.symbol), "life_id": state["life_id"],
                                 "version": state["version"], "issues": tuple(self.issues),
                                 "algos": tuple(MappingProxyType(dict(r)) for r in self._rows(order.symbol, state["life_id"]))})

    def get(self, order_id):
        config = super().get(order_id)
        if config is not None:
            config.active = self._status(config.symbol) in ("active", "updating", "exiting")
        return config

    def can_change(self, symbol, qty):
        size = self.broker._position_size(symbol)
        # 不允许在一次反手中跨越生命周期；close-all 仍可能伤及后续同向仓位。
        return self.ready and (size * (size + qty) >= 0) and not (size == 0 and any(self._pending(r) for r in self._rows(symbol)))

    def query_plan(self):
        return [(r["symbol"], r["client_id"], r.get("algo_id")) for r in self.algos.values()
                if r["status"] not in _LOCAL_TERMINAL and not r.get("settled")]

    def ingest(self, facts, missing=()):
        for raw in facts:
            client = raw.get("clientAlgoId")
            old = self.algos.get(client)
            if old is None:
                if "unknown_external_algo" not in self.issues:
                    self.issues.append("unknown_external_algo")
                self.session.store.put("external_algos", raw.get("algoId", client), raw)
                continue
            row = deepcopy(old)
            valid = (raw.get("symbol") == row["symbol"] and raw.get("side") == row["side"]
                     and raw.get("orderType") == row["order_type"] and raw.get("positionSide") == "BOTH"
                     and _true(raw.get("closePosition")) and raw.get("reduceOnly") in (False, "false")
                     and raw.get("workingType") == "MARK_PRICE" and raw.get("algoType") == "CONDITIONAL"
                     and decimal(raw.get("triggerPrice", "0")) == decimal(row["trigger_price"]))
            if row.get("algo_id") is not None and str(raw.get("algoId")) != row["algo_id"]:
                valid = False
            row["verified"], row["invalid"] = valid, not valid
            row["algo_id"] = str(raw["algoId"])
            status = raw.get("algoStatus", "unknown")
            # 迟到 NEW 不能回退已查询的终态，仍核验其只减仓字段。
            if row["status"] not in _TERMINAL:
                row["status"] = status
            actual = raw.get("actualOrderId")
            if actual and str(actual) != "0":
                if row.get("actual_order_id") not in (None, str(actual)):
                    row["invalid"] = True
                row["actual_order_id"] = str(actual)
                state = self.states.get(row["symbol"])
                if valid and state is not None and state["life_id"] == row["life_id"]:
                    self._save(row["symbol"], dict(state, native_triggered=True, status="triggered", trigger_reason=row["option"]))
            if row["status"] in _TERMINAL:
                row["cancel_phase"] = None
            self._save_algo(row)
            self._confirm_request(row)
        # 查不到旧 ID 不能证明从未发送，更不能生成新 ID 重发。
        for client in missing:
            row = self.algos[client]
            if row["status"] not in _TERMINAL:
                self._save_algo(dict(row, status="unknown", verified=False))

    def _confirm_request(self, row):
        for name in ("create_request_id", "cancel_request_id"):
            request_id = row.get(name)
            if request_id is None or not row.get("verified"):
                continue
            if name == "cancel_request_id" and row["status"] not in _TERMINAL:
                continue
            record = self.session.store.get("requests", request_id)
            if record is not None and record["phase"] not in ("not_sent", "rejected"):
                self.session.store.put("requests", request_id, dict(record, phase="confirmed"))
                if request_id in self.session.requests:
                    self.session.requests[request_id].phase = "confirmed"

    def bind_actual(self, raw):
        symbol, remote = raw["symbol"], str(raw["orderId"])
        row = next((r for r in self.algos.values() if r["symbol"] == symbol and r.get("actual_order_id") == remote), None)
        if row is None or not row.get("verified") or row.get("invalid"):
            return None
        if raw.get("side") != row["side"] or raw.get("positionSide", "BOTH") != "BOTH" or raw.get("type") != "MARKET":
            self._save_algo(dict(row, invalid=True))
            return None
        order = self.broker._find_order(remote_id=remote, symbol=symbol)
        if order is None:
            qty = decimal(raw["origQty"]) * (-1 if row["side"] == "SELL" else 1)
            if not qty:
                self._save_algo(dict(row, invalid=True))
                return None
            order = self.broker._new_order(symbol, qty, "close_position")
            order.client_order_id, order.exchange_order_id = raw["clientOrderId"], remote
            order.reason_code = "native_" + row["option"]
            exact = {"qty": text(qty), "filled_qty": "0", "avg_price": "0", "target": None,
                     "reduce_only": True, "exits": {}, "position_before": "0", "life_id": row["life_id"],
                     "client_algo_id": row["client_id"]}
            self.broker.orders[order.id], self.broker._exact[order.id] = order, exact
            self.broker._save_order(order)
        self._save_algo(dict(row, actual_local_id=order.id,
                             actual_done=raw["status"] in ("FILLED", "CANCELED", "EXPIRED", "REJECTED")))
        return order

    def outcome(self, request, outcome, payload):
        row = deepcopy(self.algos[request.order_id])
        if request.kind == "protect_cancel":
            row["cancel_phase"] = None if outcome == "not_sent" else outcome
        elif not row.get("verified"):
            row["status"] = {"not_sent": "not_sent", "rejected": "failed"}.get(outcome, "unknown")
        row["last_outcome"] = outcome
        self._save_algo(row)
        if outcome == "reply" and isinstance(payload, dict) and "algoStatus" in payload:
            self.ingest([payload])
        if outcome == "not_sent":
            self._retry_after = time.monotonic() + 1
        self.session.needs_reconcile = True

    def allows_reduction(self, symbol, qty):
        state, size = self.states.get(symbol), self.broker._position_size(symbol)
        return (state is not None and state.get("native_triggered") and size * state["direction"] > 0
                and qty * size < 0 and abs(qty) <= abs(size) and not self.issues)

    def authorize_ordinary(self, request, endpoint, params):
        order = self.broker.orders.get(request.order_id)
        if order is None:
            raise TradingPermissionError("unverified_protection_owner")
        exact = self.broker._exact[order.id]
        state = self.states.get(order.symbol)
        if state is None or not state.get("native_triggered"):
            raise TradingPermissionError("protection_obligation_changed")
        if request.kind == "cancel":
            if exact.get("reduce_only") or (order.id not in state["handles"] and exact.get("life_id") != state["life_id"]):
                raise TradingPermissionError("unverified_entry_owner")
            if params is not None and (endpoint != "trade.cancel_order" or params.get("origClientOrderId") != order.client_order_id
                                       or params.get("symbol") != order.symbol):
                raise TradingPermissionError("protection_entry_cancel_contract_mismatch")
        elif (not exact.get("reduce_only") or order.source != "close_position"
              or not self.allows_reduction(order.symbol, decimal(exact["qty"]))):
            raise TradingPermissionError("protection_reduction_obsolete")
        elif params is not None and (endpoint != "trade.create_order" or not _true(params.get("reduceOnly"))
                                     or params.get("symbol") != order.symbol
                                     or params.get("side") != ("BUY" if order.qty > 0 else "SELL")
                                     or decimal(params.get("quantity", "0")) != abs(decimal(exact["qty"]))):
            raise TradingPermissionError("protection_reduction_contract_mismatch")

    def authorize(self, request, endpoint, params):
        row = self.algos.get(request.order_id)
        if row is None or row.get("invalid"):
            raise TradingPermissionError("unverified_protection_owner")
        cancel = request.kind == "protect_cancel"
        payload = request.payload
        if payload.get("client_algo_id") != row["client_id"]:
            raise TradingPermissionError("request_identity_mismatch")
        if cancel:
            if not row.get("verified") or self._closed(row):
                raise TradingPermissionError("protection_cancel_obsolete")
        else:
            state = self.states.get(row["symbol"])
            if (not self._desired(row) or state["version"] != row["version"] or self.issues
                    or payload != self._payload(row)):
                raise TradingPermissionError("protection_obligation_changed")
        if params is not None:
            expected = "trade.cancel_algo_order" if cancel else "trade.create_algo_order"
            if endpoint != expected or params.get("clientAlgoId") != row["client_id"]:
                raise TradingPermissionError("protection_transport_identity_mismatch")
            if not cancel and (params.get("symbol") != row["symbol"] or params.get("side") != row["side"]
                               or params.get("type") != row["order_type"] or not _true(params.get("closePosition"))
                               or {"quantity", "qty", "reduceOnly", "reduce_only"}.intersection(params)
                               or params.get("workingType") != "MARK_PRICE" or params.get("positionSide", "BOTH") != "BOTH"
                               or decimal(params.get("triggerPrice", "0")) != decimal(row["trigger_price"])):
                raise TradingPermissionError("protection_transport_contract_mismatch")

    @staticmethod
    def _payload(row):
        return {"symbol": row["symbol"], "side": row["side"], "trigger_price": row["trigger_price"],
                "close_position": True, "working_type": "MARK_PRICE", "client_algo_id": row["client_id"]}

    def _request(self, row, cancel=False):
        payload = {"client_algo_id": row["client_id"]} if cancel else self._payload(row)
        method = "cancel_algo_order" if cancel else _CONDITIONS[row["option"]][1]
        with self.controlled():
            request = self.session.new_request(row["client_id"], "protect_cancel" if cancel else "protect", method, payload)
        row = dict(row, **({"cancel_request_id": request.id, "cancel_phase": "queued"} if cancel else
                           {"create_request_id": request.id, "status": "queued"}))
        with self.session.durable():
            self._save_algo(row)
            self.session.store.put("requests", request.id, request.record())
        self.session.enqueue(request)

    def drive(self):
        if (self.session.stopping or not self.session.private_connected or not self.session.account_synced
                or self.session.dirty.is_set() or self.session.failure or self.issues or time.monotonic() < self._retry_after):
            return
        for symbol, state in list(self.states.items()):
            rows = self._rows(symbol)
            if any(r.get("invalid") for r in rows):
                continue
            size = self.broker._position_size(symbol)
            if state.get("native_triggered"):
                # 入场单的撤单与触发不原子。先核对剩余入场，再处理最后成交产生的残仓。
                pending = [o for o in self.broker.orders.values() if o.symbol == symbol and not o.is_done]
                entries = [o for o in pending if not self.broker._exact[o.id].get("reduce_only")]
                with self.controlled():
                    for order in entries:
                        self.session.cancel(order)
                    if size and not pending:
                        order = self.broker.close_position(symbol)
                        if not order.is_done:
                            self._save(symbol, dict(state, status="exiting", exit_order_id=order.id))
            elif size:
                self._validate_prices(symbol, state["options"])
                for option, price in state["options"].items():
                    same = [r for r in rows if r["life_id"] == state["life_id"] and r["option"] == option and r["trigger_price"] == price]
                    # failed / unknown 均不得换一个 ID 自动重发；not_sent 才可重新验证义务。
                    if any(r["status"] != "not_sent" for r in same):
                        continue
                    row = {"schema": 1, "client_id": "mbp" + uuid4().hex, "algo_id": None,
                           "symbol": symbol, "life_id": state["life_id"], "version": state["version"],
                           "direction": state["direction"], "side": "SELL" if size > 0 else "BUY", "option": option,
                           "order_type": _CONDITIONS[option][0], "trigger_price": price,
                           "close_position": True, "reduce_only": False, "status": "queued", "verified": False}
                    self._request(row)
            for row in self._rows(symbol):
                if self._closed(row) or not row.get("verified") or row.get("cancel_phase"):
                    continue
                desired = self._desired(row)
                if desired:
                    continue
                if size and not state.get("native_triggered") and state["options"].get(row["option"]):
                    # 同侧替换先建后撤，不能出现主动撤掉唯一有效保护的窗口。
                    replacement = [r for r in self._rows(symbol, state["life_id"]) if r["option"] == row["option"]
                                   and self._desired(r) and r.get("verified") and r["status"] == "NEW"]
                    if not replacement:
                        continue
                self._request(row, cancel=True)
            pending_orders = any(o.symbol == symbol and not o.is_done for o in self.broker.orders.values())
            cleanup_done = not size and not pending_orders and not any(self._pending(r) for r in self._rows(symbol))
            if cleanup_done and state.get("native_triggered") and not state.get("native_settled"):
                self._save(symbol, dict(self.states[symbol], native_settled=True, status="cleared"))
            for row in self._rows(symbol):
                newer = any(r["client_id"] != row["client_id"] and r["option"] == row["option"]
                            and r["trigger_price"] == row["trigger_price"] and r["status"] != "not_sent"
                            for r in self._rows(symbol, row["life_id"]))
                archive = cleanup_done or not self._desired(row) or row["status"] == "not_sent" and newer
                if archive and self._closed(row) and not self._pending(row):
                    self._save_algo(dict(row, settled=True))
                    self.algos.pop(row["client_id"], None)

    def on_market(self, prices, watermark):
        self.drive()  # 触发由交易所执行；不拿本地标记价仿造原生触发事实。
