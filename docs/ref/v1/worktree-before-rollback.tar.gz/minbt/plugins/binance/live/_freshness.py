"""实时价格可信度：同时检查网络迟到、SDK/本地排队和事件总年龄。"""

from threading import RLock
import math


class StaleMarketError(RuntimeError):
    """无法证明报价新鲜，必须撤销发送许可。"""


class Freshness:
    """用服务器校时样本和单调锚点估计当前时间，不用回调到达时间覆盖原始接收时间。"""

    def __init__(self, symbols, *, utc, monotonic, max_age=5.0, sample_ttl=60.0):
        self.symbols = tuple(symbols)
        self.utc = utc
        self.monotonic = monotonic
        self.max_age = max_age
        self.sample_ttl = sample_ttl
        self.lock = RLock()  # 监测线程只更新校时信息或撤销许可。
        self.sample = None  # UTC、单调时间、服务器偏移和误差上界。
        self.quotes = {}  # 每标的原始事件与接收锚点。

    def calibrate(self, server_time, started_utc, finished_utc, started_mono, finished_mono):
        duration = finished_mono - started_mono
        if duration < 0 or abs((finished_utc - started_utc) - duration) > 0.1 or duration > 1.0:
            raise StaleMarketError("untrusted clock calibration")
        server = float(server_time) / 1000
        if not all(math.isfinite(v) for v in (server, started_utc, finished_utc, started_mono, finished_mono)) or server <= 0:
            raise StaleMarketError("invalid server time")
        midpoint = (started_utc + finished_utc) / 2
        with self.lock:
            self.sample = (finished_utc, finished_mono, server - midpoint, duration / 2 + 0.001)

    def check_clock(self):
        with self.lock:
            if self.sample is None:
                raise StaleMarketError("clock calibration is missing")
            utc, mono, offset, error = self.sample
            elapsed = self.monotonic() - mono
            if elapsed < 0 or elapsed > self.sample_ttl:
                raise StaleMarketError("clock calibration expired")
            if abs(self.utc() - (utc + elapsed)) > 0.1:
                raise StaleMarketError("local clock jumped")
            return utc + elapsed + offset, error, offset

    def observe(self, event):
        quote = self.validate_input(event)
        with self.lock:
            if event.data_type == "mark_price":
                self.quotes[event.symbol] = quote

    def validate_input(self, event):
        """可供接收线程提前关闸，只校验，不发布新的报价或账户状态。"""
        data = event.data
        event_time = data.get("E") if isinstance(data, dict) else getattr(data, "event_time", None)
        if event_time is None:
            raise StaleMarketError("market event time is missing")
        event_time = float(event_time) / 1000
        quote = (event_time, event.received_at, event.callback_utc, event.callback_monotonic)
        with self.lock:
            self._check_quote(quote)
        return quote

    def _check_quote(self, quote):
        server_now, error, offset = self.check_clock()
        event_time, received_at, callback_utc, callback_mono = quote
        if not all(math.isfinite(v) for v in quote):
            raise StaleMarketError("market time must be finite")
        elapsed = self.monotonic() - callback_mono
        if elapsed < 0 or abs(self.utc() - (callback_utc + elapsed)) > 0.1:
            raise StaleMarketError("receive clock anchor is invalid")
        receive_age = callback_utc - received_at + elapsed
        delay = received_at + offset - event_time
        total = server_now - event_time
        if min(receive_age, delay + error, total + error) < -0.1:
            raise StaleMarketError("market event time is in the future")
        if max(receive_age, delay + error, total + error) > self.max_age:
            raise StaleMarketError("market price is stale")

    def check(self):
        with self.lock:
            self.check_clock()
            for symbol in self.symbols:
                if symbol not in self.quotes:
                    raise StaleMarketError(f"fresh mark price is missing: {symbol}")
                self._check_quote(self.quotes[symbol])
