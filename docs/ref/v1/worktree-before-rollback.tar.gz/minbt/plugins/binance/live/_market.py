"""Binance 行情到核心 Bar 的映射与闭合 K 线收齐，不使用 SDK 传输批次冒充截面。"""

from collections import OrderedDict
from dataclasses import dataclass
from datetime import datetime, timezone
import math
from typing import Any, Mapping

from ....data.model import Bar
from ....data.replay import BatchItem, TimeBatch


class DataGapError(RuntimeError):
    """来源不连续或截面缺失；停止交易而不是以旧值补列。"""


@dataclass(frozen=True)
class MarketInput:
    """保留来源时间与接收锚点，避免迟到数据被适配器时间洗新。"""

    data_type: str  # SDK 产品名称。
    symbol: str  # 固定标的。
    data: Any  # 已复制的原始行情。
    sequence: int  # SDK 接受序号。
    received_at: float  # SDK 原始 UTC 接收秒数。
    callback_utc: float  # 回调到达的 UTC 时间。
    callback_monotonic: float  # 回调到达的单调时间。
    options: Mapping  # 原始订阅条件。


def _number(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("market number must be finite")
    return result


class MarketMapper:
    """固定标的 K 线按收盘时刻聚合，其他行情逐项交付以保存接受顺序。"""

    def __init__(self, symbols, interval, align_timeout, *, monotonic, max_groups=100):
        self.symbols = frozenset(symbols)  # 完整截面必须包含的集合。
        self.interval = interval  # 一个运行只允许一个周期。
        self.timeout = align_timeout
        self.monotonic = monotonic
        self.max_groups = max_groups  # 缺失标的不能导致无限缓存。
        self.groups = OrderedDict()  # 收盘时间到已接受的 K 线。
        self.seen = OrderedDict()  # 有界重复校验窗口。
        self.last_close = None  # 已交付水位，迟到旧行情不重新生成信号。
        self.expected_close = None  # 即使整个时间组未收到，也按服务时间表发现缺口。

    def _next_close(self, after):
        count, unit = int(self.interval[:-1]), self.interval[-1]
        if unit == "M":
            current = datetime.fromtimestamp(after, timezone.utc)
            year, month = current.year + (current.month == 12), current.month % 12 + 1
            return datetime(year, month, 1, tzinfo=timezone.utc).timestamp() - 0.001
        seconds = count * {"m": 60, "h": 3600, "d": 86400, "w": 604800}[unit]
        offset = 345600 if unit == "w" else 0
        return ((after - offset + 0.001) // seconds + 1) * seconds + offset - 0.001

    def arm_schedule(self, now):
        self.expected_close = self._next_close(now)

    def check_schedule(self, now):
        if self.expected_close is not None and now > self.expected_close + self.timeout:
            raise DataGapError("scheduled closed kline group is missing")

    def check_timeout(self):
        if any(self.monotonic() - group[0] >= self.timeout for group in self.groups.values()):
            raise DataGapError("closed kline alignment timed out")

    def map(self, event):
        if event.symbol not in self.symbols:
            raise ValueError("market event outside fixed symbols")
        data = event.data
        kind = event.data_type
        if kind == "kline":
            kline = data.get("k", data)
            if not kline.get("x"):
                return []
            if kline.get("i", self.interval) != self.interval:
                raise ValueError("kline interval mismatch")
            open_time, close_time = int(kline["t"]), int(kline["T"])
            key = (event.symbol, self.interval, open_time)
            fields = {"o": "open", "h": "high", "l": "low", "c": "close", "v": "volume",
                      "q": "volume_quote", "V": "volume_base_buy", "Q": "volume_quote_buy"}
            payload = {name: _number(kline[raw]) for raw, name in fields.items()}
            payload.update(num_trades=int(kline["n"]), open_time=open_time, close_time=close_time)
            if close_time <= open_time:
                raise ValueError("kline close_time must follow open_time")
            if key in self.seen:
                if self.seen[key] != payload:
                    raise DataGapError("conflicting duplicate closed kline")
                return []
            self.seen[key] = payload
            if len(self.seen) > 10000:
                self.seen.popitem(last=False)
            if self.last_close is not None and close_time <= self.last_close:
                return []
            if close_time not in self.groups:
                if len(self.groups) >= self.max_groups:
                    raise DataGapError("too many incomplete kline groups")
                self.groups[close_time] = (self.monotonic(), {})
            self.groups[close_time][1][event.symbol] = payload
            batches = []
            for close in sorted(tuple(self.groups)):
                rows = self.groups[close][1]
                if set(rows) != self.symbols:
                    break
                self.groups.pop(close)
                self.last_close = close
                if self.expected_close is not None:
                    self.expected_close = max(self.expected_close, self._next_close(close / 1000))
                visible = datetime.fromtimestamp(close / 1000, timezone.utc)
                batches.append(self._batch(visible, "kline", [(s, rows[s]) for s in sorted(rows)], event.sequence, kind))
            return batches
        raw_time = data.get("E", data.get("T")) if isinstance(data, dict) else getattr(data, "event_time", None)
        if raw_time is None:
            raise ValueError("live market input requires a trustworthy event time")
        visible = datetime.fromtimestamp(int(raw_time) / 1000, timezone.utc)
        if kind == "book_ticker":
            payload = {"bid_price": _number(data["b"]), "bid_qty": _number(data["B"]),
                       "ask_price": _number(data["a"]), "ask_qty": _number(data["A"]), "source": kind}
            return [self._batch(visible, "orderbook", [(event.symbol, payload)], event.sequence, kind)]
        if kind == "order_book":
            bids, asks = getattr(data, "bids", None), getattr(data, "asks", None)
            if bids is None:
                bids, asks = data["bids"], data["asks"]
            payload = {"bids": tuple(tuple(map(_number, r)) for r in bids),
                       "asks": tuple(tuple(map(_number, r)) for r in asks),
                       "last_update_id": getattr(data, "last_update_id", None) if not isinstance(data, dict) else data.get("lastUpdateId"), "source": kind}
            return [self._batch(visible, "orderbook", [(event.symbol, payload)], event.sequence, kind)]
        if kind == "agg_trade":
            payload = {"price": _number(data["p"]), "qty": _number(data["q"]), "trade_id": data["a"],
                       "is_buyer_maker": data["m"], "event_time": int(raw_time)}
            return [self._batch(visible, "trade", [(event.symbol, payload)], event.sequence, kind)]
        if kind == "mark_price":
            payload = {"price": _number(data["p"]), "event_time": int(raw_time), "received_at": event.received_at}
            return [self._batch(visible, "mark_price", [(event.symbol, payload)], event.sequence, kind)]
        raise ValueError(f"unsupported live data type: {kind}")

    @staticmethod
    def _batch(dt, kind, rows, sequence, source):
        return TimeBatch(dt, tuple(BatchItem(source, 0, 0, sequence, Bar(dt, symbol, kind, payload)) for symbol, payload in rows))
