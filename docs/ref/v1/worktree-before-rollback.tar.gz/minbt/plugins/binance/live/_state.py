"""实时账户的最小耐久恢复日志；交易发送之前必须提交成功。"""

from contextlib import contextmanager
from dataclasses import fields, is_dataclass
from datetime import datetime
from decimal import Decimal
import fcntl
import json
import math
import os
from pathlib import Path
import sqlite3


def _data(value):
    if is_dataclass(value):
        return {f.name: _data(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, (Decimal, float)):
        if not math.isfinite(float(value)):
            raise ValueError("state number must be finite")
        return str(value)
    if isinstance(value, datetime):
        return value.isoformat()
    if hasattr(value, "items"):
        sensitive = {"apikey", "apisecret", "secret", "signature", "listenkey", "privatekey", "privatekeypass"}
        return {str(k): "***" if str(k).lower().replace("_", "").replace("-", "") in sensitive else _data(v)
                for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_data(v) for v in value]
    if value is None or isinstance(value, (str, int, bool)):
        return value
    raise TypeError(f"state must be JSON compatible, got {type(value).__name__}")


class StateStore:
    """SQLite WAL/FULL 日志与本机目录锁，绑定账户及环境以避免错误接管。"""

    SCHEMA_VERSION = 1

    def __init__(self, directory, binding):
        self.directory = Path(directory).resolve()
        self.directory.mkdir(parents=True, exist_ok=True)
        self.lock_file = open(self.directory / "account.lock", "a+")
        os.chmod(self.lock_file.name, 0o600)
        self.connection = None
        try:
            fcntl.flock(self.lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.lock_file.close()
            raise RuntimeError("state_dir is already used by another process") from None
        try:
            path = self.directory / "state.sqlite3"
            self.connection = sqlite3.connect(str(path), isolation_level=None)
            os.chmod(path, 0o600)
            self.connection.execute("PRAGMA journal_mode=WAL")
            self.connection.execute("PRAGMA synchronous=FULL")
            if self.connection.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                raise RuntimeError("recovery database is corrupt")
            self.connection.executescript("""
                CREATE TABLE IF NOT EXISTS records (
                    kind TEXT NOT NULL, key TEXT NOT NULL, body TEXT NOT NULL,
                    PRIMARY KEY(kind, key)
                );
                CREATE TABLE IF NOT EXISTS events (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, body TEXT NOT NULL
                );
            """)
            expected = dict(binding, schema_version=self.SCHEMA_VERSION)
            previous = self.get("meta", "binding")
            if previous is not None and previous != _data(expected):
                raise RuntimeError("state_dir account/environment/configuration binding mismatch")
            if previous is None:
                with self.transaction():
                    self.put("meta", "binding", expected)
                    self.append("created", expected)
        except BaseException:
            self.close()
            raise

    @contextmanager
    def transaction(self):
        if self.connection.in_transaction:
            yield
            return
        self.connection.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.connection.execute("COMMIT")
        except BaseException:
            self.connection.execute("ROLLBACK")
            raise

    def get(self, kind, key, default=None):
        row = self.connection.execute("SELECT body FROM records WHERE kind=? AND key=?", (kind, str(key))).fetchone()
        return default if row is None else json.loads(row[0])

    def records(self, kind):
        return list(self.iter_records(kind))

    def iter_records(self, kind):
        """恢复大日志时逐行读取，不把完整历史先物化为列表。"""
        for key, body in self.connection.execute("SELECT key, body FROM records WHERE kind=? ORDER BY rowid", (kind,)):
            yield key, json.loads(body)

    def put(self, kind, key, value):
        self.connection.execute("INSERT INTO records(kind,key,body) VALUES(?,?,?) ON CONFLICT(kind,key) DO UPDATE SET body=excluded.body",
                                (kind, str(key), json.dumps(_data(value), ensure_ascii=False, allow_nan=False)))

    def insert_unique(self, kind, key, value):
        cursor = self.connection.execute("INSERT OR IGNORE INTO records(kind,key,body) VALUES(?,?,?)",
                                         (kind, str(key), json.dumps(_data(value), ensure_ascii=False, allow_nan=False)))
        return cursor.rowcount == 1

    def delete(self, kind, key):
        self.connection.execute("DELETE FROM records WHERE kind=? AND key=?", (kind, str(key)))

    def append(self, kind, value):
        cursor = self.connection.execute("INSERT INTO events(kind,body) VALUES(?,?)", (kind, json.dumps(_data(value), ensure_ascii=False, allow_nan=False)))
        return cursor.lastrowid

    def close(self):
        if self.connection is not None:
            self.connection.close()
            self.connection = None
        if not self.lock_file.closed:
            fcntl.flock(self.lock_file, fcntl.LOCK_UN)
            self.lock_file.close()
