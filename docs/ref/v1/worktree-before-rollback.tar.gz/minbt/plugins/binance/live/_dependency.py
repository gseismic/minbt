"""只在创建实时组件时校验可选 SDK，导入插件本身保持核心依赖隔离。"""

import sys


def load_sdk():
    if sys.version_info < (3, 10):
        raise ImportError("Binance live requires Python >=3.10; the minbt core supports Python >=3.8")
    try:
        from crypto_api.binance2 import usdm
    except ImportError as exc:
        raise ImportError("Binance live requires crypto_api.binance2.usdm; install minbt[binance-live] or the verified local crypto_api package") from exc
    return usdm

