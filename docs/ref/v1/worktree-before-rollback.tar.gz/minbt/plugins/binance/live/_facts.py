"""远端分页的有界交付：内存只保留当前页，账户线程逐行提交事实。"""

import json
from tempfile import TemporaryFile


class SnapshotFacts:
    """一次 REST 核对专属的临时账目，不向工作线程暴露账户 SQLite 连接。"""

    def __init__(self):
        self.files = {}
        try:
            for kind in ("fills", "incomes"):
                self.files[kind] = TemporaryFile(mode="w+t", encoding="utf-8")
        except BaseException:
            self.close()
            raise

    def append(self, kind, rows):
        stream = self.files[kind]
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")

    def records(self, kind):
        stream = self.files[kind]
        stream.flush()
        stream.seek(0)
        for line in stream:
            yield json.loads(line)

    def close(self):
        for stream in self.files.values():
            stream.close()
