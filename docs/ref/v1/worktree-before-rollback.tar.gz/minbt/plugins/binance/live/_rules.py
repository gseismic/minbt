"""Binance 合约过滤器，交易请求边界只使用 Decimal 和十进制字符串。"""

from decimal import Decimal, InvalidOperation, ROUND_DOWN
import math

from ....errors import UnsupportedCapabilityError


def decimal(value, name="number"):
    if isinstance(value, bool):
        raise TypeError(f"{name} must be a finite number")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError(f"{name} must be finite") from exc
    if not result.is_finite():
        raise ValueError(f"{name} must be finite")
    return result


def finite_float(value, name="number"):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name} cannot be displayed as a finite float")
    return result


def text(value):
    return format(decimal(value), "f")


class SymbolRules:
    """实际 tickSize/stepSize 决定合法网格，precision 字段不参与过滤器计算。"""

    def __init__(self, info):
        if info.get("contractType") != "PERPETUAL" or info.get("marginAsset") != "USDT" or info.get("quoteAsset") != "USDT" or info.get("status") != "TRADING":
            raise UnsupportedCapabilityError("live Broker requires a trading USDT perpetual contract")
        self.symbol = info["symbol"]
        self.filters = {f["filterType"]: f for f in info["filters"]}
        if not all(k in self.filters for k in ("LOT_SIZE", "MARKET_LOT_SIZE", "PRICE_FILTER")):
            raise ValueError("contract filters are incomplete")

    def lot(self, order_type):
        return self.filters["MARKET_LOT_SIZE" if order_type == "market" else "LOT_SIZE"]

    def normalize_target(self, target, order_type="market"):
        step = decimal(self.lot(order_type)["stepSize"])
        if step <= 0:
            raise ValueError("stepSize must be positive")
        return (target / step).to_integral_value(rounding=ROUND_DOWN) * step

    def validate(self, qty, price, order_type, *, reduce_only=False):
        lot = self.lot(order_type)
        step = decimal(lot["stepSize"])
        if step <= 0 or abs(qty) % step:
            return "quantity_step"
        if not decimal(lot["minQty"]) <= abs(qty) <= decimal(lot["maxQty"]):
            return "quantity_range"
        if order_type == "limit":
            rule = self.filters["PRICE_FILTER"]
            tick = decimal(rule["tickSize"])
            if tick <= 0 or price % tick:
                return "price_tick"
            if not decimal(rule["minPrice"]) <= price <= decimal(rule["maxPrice"]):
                return "price_range"
        notional = self.filters.get("MIN_NOTIONAL", self.filters.get("NOTIONAL"))
        if notional is not None and not reduce_only:
            minimum = decimal(notional.get("notional", notional.get("minNotional", "0")))
            if abs(qty) * price < minimum:
                return "min_notional"
        return None

