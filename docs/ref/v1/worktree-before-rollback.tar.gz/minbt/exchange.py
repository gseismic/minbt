"""历史导入兼容；请迁移到 minbt.replay.Exchange（计划在 0.3 移除此别名）。"""

import warnings


def __getattr__(name):
    if name == "Exchange":
        warnings.warn("minbt.exchange.Exchange is deprecated; use minbt.replay.Exchange (removal: 0.3)", DeprecationWarning, stacklevel=2)
        from .replay import Exchange
        return Exchange
    raise AttributeError(name)


__all__ = ["Exchange"]  # noqa: F822
