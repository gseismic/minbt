from typing import Optional

from .data.model import Bar, normalize_symbol
from .logger import logger as default_logger
from .protocols.broker import BROKER_PROTOCOL_METHODS, BrokerProtocol
from .protocols.exchange import ExchangeProtocol


class Strategy:
    def __init__(
        self,
        strategy_id: str,
        broker: Optional[BrokerProtocol] = None,
        params: Optional[dict] = None,
        logger=None,
    ):
        self.strategy_id = strategy_id
        self._run_consumed = False  # 已启动的实例不能参加另一场实验。
        self._exchange = None  # 装配归属，用于冻结运行中的账户关联。
        self.set_broker(broker)
        self.params = params if params is not None else {}
        self.logger = logger or default_logger
        self._equity_history = None
        self._position_size_history = None
        self._pyta_available = None
        self._history_limit = None  # 实时会话注入保留窗口，历史默认全量。

    def _check_pyta(self):
        if self._pyta_available is None:
            try:
                from pyta2.utils.vector import NumpyVector, VectorTable

                self._pyta_NumpyVector = NumpyVector
                self._pyta_VectorTable = VectorTable
                self._pyta_available = True
            except ImportError:
                self._pyta_available = False

    @property
    def broker(self):
        return self._broker

    @broker.setter
    def broker(self, broker):
        self.set_broker(broker)

    def set_broker(self, broker):
        if self._run_consumed:
            raise RuntimeError("cannot change Broker after Strategy has started")
        if broker is None:
            self._broker = None
            return
        if not isinstance(broker, BrokerProtocol):
            raise TypeError(
                f"broker must implement BrokerProtocol ({', '.join(BROKER_PROTOCOL_METHODS)}), "
                f"got {type(broker).__name__}"
            )
        self._broker = broker

    def set_params(self, params: dict):
        self.params = params

    def update_params(self, **kwargs):
        self.params.update(kwargs)

    @property
    def exchange(self):
        return self._exchange

    @exchange.setter
    def exchange(self, exchange):
        self.set_exchange(exchange)

    def set_exchange(self, exchange):
        if exchange is not None and not isinstance(exchange, ExchangeProtocol):
            raise TypeError("exchange must implement ExchangeProtocol")
        if self._run_consumed:
            raise RuntimeError("Strategy has already been used in a run")
        if self.exchange is not None and exchange is not None and self.exchange is not exchange:
            raise RuntimeError("Strategy already belongs to another Exchange")
        self._exchange = exchange

    def on_init(self):
        pass

    def on_ready(self):
        """每次运行最多一次；账户、保护和行情就绪后可表达初始意图。"""
        pass

    def on_order(self, order):
        pass

    def on_fill(self, fill):
        pass

    def on_account(self, account):
        pass

    def on_warmup(self, dt, bars):
        """只读预热，避免用正常行情回调重放交易副作用。"""
        pass

    def save_state(self):
        return None

    def load_state(self, state):
        pass

    def on_bars(self, dt, bars):
        pass

    def on_bar(self, dt, bar: Bar):
        """接收没有专用回调的自定义 Bar。"""
        pass

    def on_books(self, dt, books):
        pass

    def on_trades(self, dt, trades):
        pass

    def on_news(self, dt, news):
        pass

    def on_finish(self):
        pass

    def _ensure_broker_history(self):
        if self.broker is None:
            return

        if self._equity_history is None:
            self._check_pyta()
            if self._pyta_available and self._history_limit is None:
                self._equity_history = self._pyta_NumpyVector()
            else:
                self._equity_history = []

        if self._position_size_history is None:
            self._check_pyta()
            if self._pyta_available and self._history_limit is None:
                self._position_size_history = self._pyta_VectorTable()
            else:
                self._position_size_history = []

    def _record_broker_history(self):
        if self.broker is None:
            return

        self._ensure_broker_history()
        equity = self.broker.get_total_equity()
        self._equity_history.append(equity)

        positions = self.broker.get_position_sizes()
        if isinstance(self._position_size_history, list):
            self._position_size_history.append(positions)
        else:
            # VectorTable 用 dtype 填充值表示缺列；持仓历史的业务语义应为 0。
            # 新 symbol 出现时补齐既有行，之后每行也显式写入已知 symbol。
            known_symbols = set(self._position_size_history.columns)
            for symbol in positions:
                if symbol not in known_symbols:
                    self._position_size_history.ensure_column(symbol, dtype=float)
                    self._position_size_history[symbol] = 0.0
            row = {
                symbol: positions.get(symbol, 0.0)
                for symbol in self._position_size_history.columns
            }
            self._position_size_history.append(row)
        if self._history_limit is not None:
            del self._equity_history[:-self._history_limit]
            del self._position_size_history[:-self._history_limit]

    def _dispatch_exchange_callback(self, name: str, dt, data):
        getattr(self, name)(dt, data)

    def get_hist_equity(self):
        if self._equity_history is None:
            return []
        if isinstance(self._equity_history, list):
            return list(self._equity_history)
        return self._equity_history.to_numpy().tolist()

    def get_hist_position_sizes(self, symbol: str):
        symbol = normalize_symbol(symbol)
        if self._position_size_history is None:
            return []
        if isinstance(self._position_size_history, list):
            return [p.get(symbol, 0) for p in self._position_size_history]
        if symbol not in self._position_size_history.columns:
            return [0.0] * len(self._position_size_history)
        values = self._position_size_history.get_column(symbol).tolist()
        missing = self._position_size_history.get_fill_mask(symbol).tolist()
        return [0.0 if is_missing else value for value, is_missing in zip(values, missing)]

    def get_broker_stats(self, portfolio: str = "main"):
        return {
            "equity": self.broker.get_equity(portfolio=portfolio),
            "cash": self.broker.get_cash(portfolio=portfolio),
            "positions": self.broker.get_positions(portfolio=portfolio),
        }
