from collections import Counter, OrderedDict
import copy
import math
from threading import Lock, get_ident
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union

from .exit import ExitConfig, ExitContext, ExitRule, _ExitState
from .market import Market
from .order import Order, OrderSource
from .execution import inflight_order, same_target
from .portfolio import Portfolio
from .pnl import Pnl, PnlRecord, _sum_pnl
from .struct import DateType, Position, _require
from ..data.model import Bar, normalize_datetime, normalize_symbol
from .._validation import _finite_sum, finite_number, positive_number
from ..data.replay import TimeBatch
from ..logger import logger as default_logger


DEFAULT_PORTFOLIO = "main"


class Broker:
    """
    交易经纪商。

    Broker 负责维护现金、持仓、订单、分仓和退出条件。策略只需要在回调中调用 Broker
    表达交易动作，不需要关心 Exchange 如何推进数据。
    """

    def __init__(
        self,
        initial_cash: float,
        fee_rate: float = 0.0,
        *,
        leverage: float = 1.0,
        margin_mode: str = "cross",
        warning_margin_level: float = 0.2,
        min_margin_level: float = 0.1,
        market: Optional[Market] = None,
        mark_price: Union[str, Tuple[str, str], Tuple[str, str, str], Callable, None] = "kline.close",
        mark_price_aggregation: Union[str, Callable] = "error",
        mark_price_missing: str = "keep",
        execution: str = "next_event",
        execution_price=None,
        fill_quantity=None,
        logger=None,
    ):
        if execution not in ("next_event", "legacy_immediate"):
            raise ValueError("execution must be 'next_event' or 'legacy_immediate'")
        self.execution = execution  # 默认用后续行情确认，不以提交返回推断成交。
        if fill_quantity is not None and not callable(fill_quantity):
            raise TypeError("fill_quantity must be callable or None")
        if fill_quantity is not None and execution == "legacy_immediate":
            raise ValueError("fill_quantity requires execution='next_event'")
        self.fill_quantity = fill_quantity  # 冻结订单、价格、时间 → 本次 signed 成交量；默认剩余全量。
        self._fill_sequence = 0  # 多次部分成交使用独立稳定明细 ID。
        self.execution_price = self._validate_mark_price(execution_price)  # None 沿用估值价格选择。
        self._execution_prices = {}  # 与估值源分开的执行参考价。
        self._quote_versions = Counter()  # 每个标的真实执行事件递增，其他标的不会提供成交机会。
        self._submitted_versions = {}  # 提交时已见的事件不能用来成交。
        self._intent_targets = {}  # 固定数量目标，用于同目标复用。
        self._intent_requests = {}  # 原始目标与提交前仓位，部分成交不改变目标归一化基线。
        self._closing_portfolios = set()  # 异步平仓结束后才归还分仓现金。
        self._triggered_exits = {}  # 退出义务一旦触发不因行情回弹丢失。
        self._event_sink = None  # 会话只投递通知，Broker 不执行策略。
        self._account_sink = None  # 成交后账户事实通知。
        self._session_context = None  # 当前运行的通用许可和时钟。
        self._session_started = False  # 第三方 Exchange 也不能重用已经启动的账户。
        self._session_applying = False  # 运行线程内部撮合不受暂停策略的只读限制。
        self._fills = []  # 唯一模拟成交明细。
        initial_cash = positive_number(initial_cash, "initial_cash")
        fee_rate = finite_number(fee_rate, "fee_rate")
        leverage = finite_number(leverage, "leverage")
        warning_margin_level = finite_number(warning_margin_level, "warning_margin_level")
        min_margin_level = finite_number(min_margin_level, "min_margin_level")
        _require(
            0 <= fee_rate < 1.0,
            f"fee_rate must be between 0 (inclusive) and 1.0 (exclusive), fee_rate: {fee_rate}",
        )
        _require(leverage >= 1.0, f"leverage must be greater than or equal to 1.0, leverage: {leverage}")
        _require(
            margin_mode in ("cross", "isolated"),
            f"margin_mode must be either cross or isolated, margin_mode: {margin_mode}",
        )
        _require(
            0 <= min_margin_level < 1.0,
            f"min_margin_level must be between 0 (inclusive) and 1.0 (exclusive), min_margin_level: {min_margin_level}",
        )
        _require(
            0 <= warning_margin_level < 1.0,
            f"warning_margin_level must be between 0 (inclusive) and 1.0 (exclusive), "
            f"warning_margin_level: {warning_margin_level}",
        )
        _require(
            min_margin_level < warning_margin_level,
            f"min_margin_level must be less than warning_margin_level, "
            f"warning_margin_level: {warning_margin_level}, min_margin_level: {min_margin_level}",
        )

        self.fee_rate = fee_rate
        self.leverage = leverage
        self.margin_mode = margin_mode
        self.warning_margin_level = warning_margin_level
        self.min_margin_level = min_margin_level
        self._default_market = copy.copy(market) if market is not None else Market(name="Default")
        self._markets: Dict[str, Market] = {}
        self._symbol_market_names: Dict[str, str] = {}
        self._market_name_to_symbols: Dict[str, List[str]] = {}
        self.logger = logger or default_logger
        self.initial_cash = initial_cash
        self.mark_price = self._validate_mark_price(mark_price)
        self.mark_price_aggregation = self._validate_mark_price_aggregation(mark_price_aggregation)
        if mark_price_missing not in ("keep", "error"):
            raise ValueError("mark_price_missing must be 'keep' or 'error'")
        self.mark_price_missing = mark_price_missing

        self._pnl_records: List[PnlRecord] = []  # 按实际记账顺序保留所有分仓的不可变明细。
        self._closed_pnl: Dict[str, Dict[Optional[str], Pnl]] = {}  # 已关闭分仓的汇总，按名称累计历史。
        self.portfolios: Dict[str, Portfolio] = {
            DEFAULT_PORTFOLIO: self._create_portfolio(initial_cash)
        }

        self.last_prices: Dict[str, float] = {}
        self.last_price_dates: Dict[str, DateType] = {}
        self._last_market_dt = None  # 当前交易时钟，与各标的的报价时间分开保存。

        self.orders: "OrderedDict[str, Order]" = OrderedDict()
        self._order_seq = 0
        self._pending_order_ids: List[str] = []
        self._pending_exit_params: Dict[str, Dict[str, Any]] = {}

        self._exit_states: Dict[str, _ExitState] = {}
        self._active_exit_order_by_position: Dict[Tuple[str, str], str] = {}
        self._position_order_ids: Dict[Tuple[str, str], set] = {}
        self._run_lock = Lock()  # 跨 Exchange 原子占用账户，允许同次共享。
        self._run_consumed = False  # 运行过的账户不再参加独立实验。
        self._run_owner = None  # 仅用于约束运行期间的账户写入线程。
        self._run_thread_id = None  # 所属运行线程；外部控制只修改自身状态。
        self._run_readonly = None  # 控制与结束通知阶段禁止修改账户。

    def _assert_writable(self) -> None:
        """阻止控制、报告或外部线程改变运行账户，保证历史采样边界。"""

        if self._run_readonly is not None and not self._session_applying:
            raise RuntimeError(f"Broker is read-only during {self._run_readonly}")
        if self._session_context is not None and not self._session_applying:
            self._session_context.permissions.assert_writable()
        if self._run_owner is not None and self._run_owner._run_state == "running":
            if get_ident() != self._run_thread_id:
                raise RuntimeError("Broker can only be changed by its run thread")

    def create_session(self):
        from ._session import SimSession
        return SimSession(self)

    def describe(self):
        return {"execution_kind": "simulated", "execution_model": self.execution,
                "environment": None, "uses_real_funds": False,
                "valuation_source": str(self.mark_price)}

    def _validate_execution_options(self, price=None, price_dt=None, leverage=None):
        if self.execution != "legacy_immediate" and any(v is not None for v in (price, price_dt, leverage)):
            raise ValueError("price/price_dt/per-order leverage require execution='legacy_immediate'; use a limit order or Broker leverage")

    def _notify_order(self, order):
        if self._event_sink is not None:
            from ..events import SessionEvent
            from ..result import snapshot_order
            self._event_sink(SessionEvent("sim", "on_order", snapshot_order(order)))

    def _conflict_order(self, symbol, portfolio, source, qty=0):
        return self._create_order(symbol=symbol, portfolio=portfolio, source=source,
                                  order_type="market", qty=qty, status="rejected",
                                  reason="another position intent is still in flight",
                                  reason_code="target_in_flight", created_dt=self._trading_dt())

    def _can_queue(self, symbol, qty, price, portfolio):
        rows = [{"symbol": self.orders[o].symbol, "qty": self.orders[o].remaining_qty,
                 "price": self.orders[o].limit_price or self.get_last_price(self.orders[o].symbol)}
                for o in self._pending_order_ids if self.orders[o].portfolio == portfolio]
        rows.append({"symbol": symbol, "qty": qty, "price": price})
        return self.portfolios[portfolio].can_submit_orders(rows)[0]

    def get_fills(self):
        return list(self._fills)

    def _prune_history(self, limit):
        """只归档终态与旧明细；累计账本、当前持仓句柄和未决订单继续保留。"""
        pinned = set(self._pending_order_ids)
        for ids in self._position_order_ids.values():
            pinned.update(ids)
        keep = set(list(self.orders)[-limit:]) | pinned
        removed = [key for key, order in self.orders.items() if key not in keep and order.is_done]
        truncated = bool(removed) or len(self._fills) > limit or len(self._pnl_records) > limit
        for key in removed:
            self.orders.pop(key)
            self._exit_states.pop(key, None)
            self._intent_targets.pop(key, None)
            self._intent_requests.pop(key, None)
            self._submitted_versions.pop(key, None)
        del self._fills[:-limit]
        del self._pnl_records[:-limit]
        return truncated

    @staticmethod
    def _validate_mark_price(source):
        if source is None or callable(source):
            return source
        if isinstance(source, str):
            value = source.strip()
            kind, separator, field = value.partition(".")
            if not separator or not kind.strip() or not field.strip() or "." in field:
                raise TypeError("mark_price must look like 'kind.field', for example 'kline.close'")
            return kind.strip().lower(), field.strip()
        if not isinstance(source, tuple) or len(source) not in (2, 3):
            raise TypeError(
                "mark_price must be a 'kind.field' string, None, a callable, "
                "(kind, field), or (feed_name, kind, field)"
            )
        if any(not isinstance(value, str) or not value.strip() for value in source):
            raise TypeError("mark_price tuple values must be non-empty strings")
        if len(source) == 2:
            return source[0].strip().lower(), source[1].strip()
        return source[0].strip(), source[1].strip().lower(), source[2].strip()

    @staticmethod
    def _validate_mark_price_aggregation(value):
        if callable(value):
            return value
        if value not in ("error", "first", "last"):
            raise ValueError("mark_price_aggregation must be 'error', 'first', 'last', or callable")
        return value

    def _create_portfolio(self, initial_cash: float, name: str = DEFAULT_PORTFOLIO) -> Portfolio:
        portfolio = Portfolio(
            initial_cash,
            fee_rate=self.fee_rate,
            leverage=self.leverage,
            margin_mode=self.margin_mode,
            warning_margin_level=self.warning_margin_level,
            min_margin_level=self.min_margin_level,
            logger=self.logger,
            name=name,
        )
        portfolio._pnl_record_sink = self._pnl_records.append
        return portfolio

    def _close_portfolio_account(self, name: str) -> None:
        """关闭分仓并归还现金，保留原分仓盈亏，划拨不产生交易收益。"""
        closed = self.portfolios[name]
        archived = self._preview_portfolio_return(name, closed.total_cash, closed._booked_pnl)
        # 归还非负资金可分次偿还 main 欠款，不要求一次就恢复非负余额。
        self.portfolios[DEFAULT_PORTFOLIO]._current_cash.add_cash(closed.total_cash)
        self.portfolios.pop(name)
        self._closed_pnl[name] = archived
        closed._pnl_record_sink = None

    def _preview_portfolio_return(self, name, cash, booked):
        """关闭前检查接收现金和归档金额，失败不能先取消订单或删除分仓。"""
        self.portfolios[DEFAULT_PORTFOLIO]._current_cash._preview_change_cash(cash)
        archived = self._closed_pnl.get(name, {}).copy()
        for symbol, pnl in booked.items():
            try:
                candidate = _sum_pnl((archived.get(symbol, Pnl()), pnl))
            except OverflowError as exc:
                raise ValueError("archived pnl must be finite") from exc
            for field in ("realized_pnl", "fees", "settlement_adjustment"):
                finite_number(getattr(candidate, field), f"archived {field}")
            archived[symbol] = candidate
        return archived

    def _require_pnl_portfolio(self, name: str) -> None:
        if name not in self.portfolios and name not in self._closed_pnl:
            raise ValueError(f"portfolio not found: {name}")

    def _require_portfolio(self, portfolio: str) -> None:
        if portfolio not in self.portfolios:
            raise ValueError(f"portfolio not found: {portfolio}")

    def _resolve_portfolio(self, portfolio: Optional[str]) -> str:
        name = DEFAULT_PORTFOLIO if portfolio is None else portfolio
        self._require_portfolio(name)
        return name

    def _known_symbols(self) -> set:
        symbols = set(self.last_prices)
        symbols.update(self.last_price_dates)
        for order_id in self._pending_order_ids:
            order = self.orders.get(order_id)
            if order is not None:
                symbols.add(order.symbol)
        for portfolio in self.portfolios.values():
            symbols.update(portfolio.positions)
        return symbols

    def _has_market_route_state(self) -> bool:
        if self.orders or self._pending_order_ids or self.last_prices or self.last_price_dates:
            return True
        return any(portfolio.positions for portfolio in self.portfolios.values())

    def _symbols_for_market(self, market_name: str) -> List[str]:
        return list(self._market_name_to_symbols.get(market_name, ()))

    def _default_market_symbols(self) -> List[str]:
        mapped_symbols = set(self._symbol_market_names)
        return sorted(symbol for symbol in self._known_symbols() if symbol not in mapped_symbols)

    def _market_for(self, symbol: str) -> Market:
        symbol = normalize_symbol(symbol)
        market_name = self._symbol_market_names.get(symbol)
        if market_name is None:
            return self._default_market
        return self._markets[market_name]

    def _on_new_dt(self, dt) -> None:
        for market_name, market in self._markets.items():
            symbols = self._symbols_for_market(market_name) if market.t_plus else None
            market.on_new_dt(self, dt, symbols=symbols)
        symbols = self._default_market_symbols() if self._default_market.t_plus else None
        self._default_market.on_new_dt(self, dt, symbols=symbols)

    def _trading_dt(self, dt=None):
        """沿用旧报价时仍按当前时间交易；运行中的显式报价不能改变回放时钟。"""
        if self._session_context is not None and self._session_context.clock == "wall":
            return self._session_context.now()
        candidate = normalize_datetime(dt) if dt is not None else None
        if self._last_market_dt is None:
            return candidate
        if candidate is None or (self._run_owner is not None and self._run_owner._run_state == "running"):
            return self._last_market_dt
        return max(candidate, self._last_market_dt)

    def _advance_dt(self, dt) -> None:
        if dt is not None and (self._last_market_dt is None or dt > self._last_market_dt):
            self._on_new_dt(dt)
            self._last_market_dt = dt

    def _next_order_id(self) -> str:
        self._order_seq += 1
        return f"order-{self._order_seq}"

    def _side(self, qty: float) -> str:
        if qty > 0:
            return "buy"
        if qty < 0:
            return "sell"
        return "none"

    def _create_order(
        self,
        *,
        symbol: str,
        portfolio: str,
        order_type: str,
        source: OrderSource,
        qty: float,
        status: str,
        requested_price: Optional[float] = None,
        limit_price: Optional[float] = None,
        filled_qty: float = 0.0,
        avg_price: Optional[float] = None,
        reason: Optional[str] = None,
        created_dt=None,
        updated_dt=None,
        reason_code=None,
    ) -> Order:
        order = Order(
            id=self._next_order_id(),
            symbol=symbol,
            portfolio=portfolio,
            order_type=order_type,  # type: ignore[arg-type]
            source=source,
            side=self._side(qty),  # type: ignore[arg-type]
            qty=qty,
            status=status,  # type: ignore[arg-type]
            requested_price=requested_price,
            limit_price=limit_price,
            filled_qty=filled_qty,
            avg_price=avg_price,
            reason=reason,
            created_dt=created_dt,
            updated_dt=updated_dt,
            reason_code=reason_code,
        )
        self.orders[order.id] = order
        self._notify_order(order)
        return order

    def _update_order(
        self,
        order: Order,
        *,
        status: str,
        filled_qty: Optional[float] = None,
        avg_price: Optional[float] = None,
        reason: Optional[str] = None,
        updated_dt=None,
    ) -> Order:
        order.status = status  # type: ignore[assignment]
        if filled_qty is not None:
            order.filled_qty = filled_qty
        if avg_price is not None:
            order.avg_price = avg_price
        order.reason = reason
        order.updated_dt = updated_dt
        self._notify_order(order)
        return order

    def _exit_params_provided(
        self,
        *,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
    ) -> bool:
        return any(
            value is not None
            for value in (
                stop_loss_price,
                take_profit_price,
                trailing_stop_pct,
                trailing_stop_amount,
            )
        )

    def _validate_exit_params(
        self,
        *,
        position_size: float,
        reference_price: float,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
    ) -> None:
        self._validate_exit_values(
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
        )
        if position_size == 0:
            return
        if position_size > 0:
            if stop_loss_price is not None and stop_loss_price >= reference_price:
                raise ValueError("stop_loss_price must be lower than reference price for a long position")
            if take_profit_price is not None and take_profit_price <= reference_price:
                raise ValueError("take_profit_price must be higher than reference price for a long position")
        else:
            if stop_loss_price is not None and stop_loss_price <= reference_price:
                raise ValueError("stop_loss_price must be higher than reference price for a short position")
            if take_profit_price is not None and take_profit_price >= reference_price:
                raise ValueError("take_profit_price must be lower than reference price for a short position")

    def _validate_exit_values(
        self,
        *,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
    ) -> None:
        for name, value in (
            ("stop_loss_price", stop_loss_price), ("take_profit_price", take_profit_price),
            ("trailing_stop_pct", trailing_stop_pct), ("trailing_stop_amount", trailing_stop_amount),
        ):
            if value is not None:
                finite_number(value, name)
        if trailing_stop_pct is not None and trailing_stop_amount is not None:
            raise ValueError("trailing_stop_pct and trailing_stop_amount cannot both be set")
        if stop_loss_price is not None and stop_loss_price <= 0:
            raise ValueError(f"stop_loss_price must be positive, got {stop_loss_price}")
        if take_profit_price is not None and take_profit_price <= 0:
            raise ValueError(f"take_profit_price must be positive, got {take_profit_price}")
        if trailing_stop_pct is not None and not (0 < trailing_stop_pct < 1):
            raise ValueError(f"trailing_stop_pct must be between 0 and 1, got {trailing_stop_pct}")
        if trailing_stop_amount is not None and trailing_stop_amount <= 0:
            raise ValueError(f"trailing_stop_amount must be positive, got {trailing_stop_amount}")

    def _validate_attached_exit_params(
        self,
        *,
        position_size: float,
        reference_price: float,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
    ) -> None:
        if not self._exit_params_provided(
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
        ):
            return
        self._validate_exit_params(
            position_size=position_size,
            reference_price=reference_price,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
        )

    def _validate_leverage(self, leverage: Optional[float]) -> None:
        if leverage is not None:
            value = finite_number(leverage, "leverage")
            _require(value >= 1, f"leverage must be greater than or equal to 1, got {value}")

    def _resolve_market_price(self, symbol: str, price: Optional[float], price_dt=None):
        """纯解析报价和交易时间；校验通过后再由准备步骤推进估值与风险。"""
        if price is None:
            if price_dt is not None:
                raise ValueError("price_dt must be None when price is omitted")
            resolved_price, resolved_dt = self.get_last_price(symbol, return_dt=True)
            if resolved_price is None:
                raise ValueError(f"market price not found: {symbol}")
            return positive_number(resolved_price, "price"), self._trading_dt(resolved_dt)
        price = positive_number(price, "price")
        return price, self._trading_dt(price_dt)

    def _prepare_market_price(self, symbol: str, price: Optional[float], price_dt=None):
        """合法请求先推进风险，目标数量随后按最新持仓计算。"""
        resolved_price, trade_dt = self._resolve_market_price(symbol, price, price_dt)
        if price is not None:
            self._validate_mark_prices({symbol: resolved_price})
        self._advance_dt(trade_dt)
        if price is not None:
            quote_dt = normalize_datetime(price_dt) if price_dt is not None else trade_dt
            self._apply_price(symbol, resolved_price, quote_dt)
        return resolved_price, trade_dt

    def _expire_empty_positions(self) -> None:
        """风险结算立即结束持仓生命周期，旧订单不能控制之后的新仓。"""
        for portfolio, symbol in list(self._position_order_ids):
            if self.get_position_size(symbol, portfolio=portfolio) == 0:
                self._position_order_ids.pop((portfolio, symbol), None)
                self._clear_position_exit(portfolio, symbol)

    def _clear_position_exit(self, portfolio: str, symbol: str) -> None:
        for order_id in tuple(self._triggered_exits):
            order = self.orders.get(order_id)
            if order is not None and (order.portfolio, order.symbol) == (portfolio, symbol):
                self._triggered_exits.pop(order_id, None)
        order_id = self._active_exit_order_by_position.pop((portfolio, symbol), None)
        if order_id is not None and order_id in self._exit_states:
            self._exit_states[order_id].active = False

    def _position_has_active_exit(self, portfolio: str, symbol: str, order_id: str) -> bool:
        return self._active_exit_order_by_position.get((portfolio, symbol)) == order_id

    def _get_or_create_exit_state(self, order: Order) -> _ExitState:
        """订单作为当前持仓的访问句柄，切换句柄时继承整份有效配置。"""
        current_id = self._active_exit_order_by_position.get((order.portfolio, order.symbol))
        if current_id == order.id:
            return self._exit_states[order.id]
        previous = self._exit_states.get(current_id)
        if previous is None:
            state = _ExitState(order_id=order.id, symbol=order.symbol, portfolio=order.portfolio)
        else:
            state = copy.copy(previous)
            state.order_id = order.id
            # 规则列表属于配置，规则及其 state 属于本持仓生命周期，保留对象身份。
            state.custom_rules = list(previous.custom_rules)
        self._exit_states[order.id] = state
        return state

    def _activate_exit_state(self, order: Order, state: _ExitState) -> None:
        key = (order.portfolio, order.symbol)
        previous_id = self._active_exit_order_by_position.get(key)
        if previous_id is not None and previous_id != order.id:
            previous = self._exit_states.get(previous_id)
            if previous is not None:
                previous.active = False
        state.refresh_active()
        if state.active:
            self._active_exit_order_by_position[key] = order.id
        else:
            self._active_exit_order_by_position.pop(key, None)

    def _activate_standard_exit(
        self,
        order: Order,
        *,
        reference_price: float,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
    ) -> None:
        """激活退出条件；新成交省略的字段继承该仓位之前的活动配置。"""
        if not self._exit_params_provided(
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
        ):
            return
        state = self._get_or_create_exit_state(order)
        if stop_loss_price is not None:
            state.stop_loss_price = stop_loss_price
        if take_profit_price is not None:
            state.take_profit_price = take_profit_price
        if trailing_stop_pct is not None:
            state.trailing_stop_pct = trailing_stop_pct
            state.trailing_stop_amount = None
            state.trailing_anchor = reference_price
        if trailing_stop_amount is not None:
            state.trailing_stop_amount = trailing_stop_amount
            state.trailing_stop_pct = None
            state.trailing_anchor = reference_price
        self._activate_exit_state(order, state)

    def _require_current_exit_order(self, order: Order) -> None:
        key = (order.portfolio, order.symbol)
        if order.id not in self._position_order_ids.get(key, set()):
            raise ValueError(f"order is no longer associated with the current position: {order.id}")

    def _after_order_filled(
        self,
        order: Order,
        *,
        old_size: float,
        price: float,
        dt,
        exit_params: Optional[Dict[str, Any]] = None,
        filled_qty: Optional[float] = None,
    ) -> None:
        self._market_for(order.symbol).on_order_filled(
            self,
            order.symbol,
            order.qty if filled_qty is None else filled_qty,
            price,
            dt=dt,
            portfolio=order.portfolio,
            old_size=old_size,
        )

        position = self.get_position(order.symbol, portfolio=order.portfolio)
        new_size = 0.0 if position is None else position.size
        key = (order.portfolio, order.symbol)
        if new_size == 0:
            self._position_order_ids.pop(key, None)
            self._clear_position_exit(order.portfolio, order.symbol)
            return
        if old_size == 0 or old_size * new_size < 0:
            self._position_order_ids[key] = {order.id}
            self._clear_position_exit(order.portfolio, order.symbol)
        else:
            self._position_order_ids.setdefault(key, set()).add(order.id)
        if exit_params and self._exit_params_provided(**exit_params):
            self._activate_standard_exit(order, reference_price=price, **exit_params)

    def _execute_existing_order(
        self,
        order: Order,
        *,
        price: float,
        price_dt=None,
        leverage: Optional[float] = None,
        exit_params: Optional[Dict[str, Any]] = None,
        fill_qty: Optional[float] = None,
    ) -> Order:
        qty = order.remaining_qty if fill_qty is None else fill_qty
        validation = self._market_for(order.symbol).validate_order(
            self,
            order.symbol,
            qty,
            price,
            dt=price_dt,
            portfolio=order.portfolio,
        )
        if not validation.ok:
            self.logger.warning(
                f"Order rejected: {order.symbol}, qty={order.qty}, price={price}, reason={validation.message}"
            )
            return self._update_order(order, status="rejected", reason=validation.message, updated_dt=price_dt)

        old_size = self.get_position_size(order.symbol, portfolio=order.portfolio)
        try:
            previous_qty = order.filled_qty
            cumulative = order.qty if qty == order.remaining_qty else _finite_sum((previous_qty, qty), "filled quantity")
            average = price if not previous_qty else _finite_sum((
                abs(previous_qty) / abs(cumulative) * order.avg_price,
                abs(qty) / abs(cumulative) * price,
            ), "order average price")
            result = self.portfolios[order.portfolio].submit_order(
                order.symbol,
                qty,
                price=price,
                leverage=leverage,
                price_dt=price_dt,
                order_id=order.id,
                mark_price=self.get_last_price(order.symbol),
                mark_dt=self.last_price_dates.get(order.symbol),
            )
        except ValueError as exc:
            # 已挂订单的账户状态可能变化；派生值预检失败必须终结订单，不能残留 pending。
            return self._update_order(order, status="rejected", reason=str(exc), updated_dt=price_dt)
        if not result:
            return self._update_order(
                order,
                status="rejected",
                reason="portfolio rejected order",
                updated_dt=price_dt,
            )

        self._update_order(
            order,
            status="filled" if cumulative == order.qty else "partially_filled",
            filled_qty=cumulative,
            avg_price=average,
            updated_dt=price_dt,
        )
        self._expire_empty_positions()
        self._after_order_filled(order, old_size=old_size, price=price, dt=price_dt, exit_params=exit_params, filled_qty=qty)
        from ..events import Fill, SessionEvent
        record = self._pnl_records[-1]
        fee = record.fees if record.order_id == order.id else abs(qty * price) * self.fee_rate
        self._fill_sequence += 1
        fill = Fill(f"sim-{order.id}-{self._fill_sequence}", order.id, order.symbol, order.portfolio, qty, price, fee, "CASH", price_dt)
        self._fills.append(fill)
        if self._event_sink is not None:
            self._event_sink(SessionEvent("sim", "on_fill", fill))
        if self._account_sink is not None:
            self._account_sink()
        return order

    def add_portfolio(self, name: str, cash: float) -> None:
        """从主组合划拨现金创建新组合。"""
        self._assert_writable()
        if not isinstance(name, str):
            raise TypeError("portfolio name must be a string")
        if not name.strip():
            raise ValueError("portfolio name must not be empty")
        if name in self.portfolios:
            raise ValueError(f"portfolio already exists: {name}")
        cash = positive_number(cash, "cash")
        source = self.portfolios[DEFAULT_PORTFOLIO]
        _require(
            cash <= source.free_cash,
            f"cash must be less than or equal to main portfolio free cash, cash: {cash}, free_cash: {source.free_cash}",
        )
        source._current_cash.change_cash(-cash)
        self.portfolios[name] = self._create_portfolio(cash, name=name)

    def add_market(self, name: str, market: Market, symbols: Sequence[str]) -> None:
        """为一组 symbol 添加市场规则路由。"""
        self._assert_writable()
        if not isinstance(name, str) or not name:
            raise ValueError("market name must be a non-empty string")
        if self._has_market_route_state():
            raise ValueError("add_market must be called before broker has orders, prices, or positions")
        if name == self._default_market.name:
            raise ValueError(f"market name conflicts with default market: {name}")
        if name in self._markets:
            raise ValueError(f"market already exists: {name}")
        if not isinstance(market, Market):
            raise TypeError("market must be a Market instance")
        if isinstance(symbols, (str, bytes)) or symbols is None:
            raise TypeError("symbols must be a non-empty list of strings")
        symbols = list(symbols)
        if not symbols:
            raise ValueError("symbols must be non-empty")
        symbols = [normalize_symbol(symbol) for symbol in symbols]
        for symbol in symbols:
            if symbol in self._symbol_market_names:
                raise ValueError(f"symbol already mapped to market: {symbol}")
        duplicate_symbols = {s for s, count in Counter(symbols).items() if count > 1}
        if duplicate_symbols:
            raise ValueError(f"duplicate symbols in market route: {sorted(duplicate_symbols)}")

        # Market 字段须保持不可变；新增 mutable 字段时改用 copy.deepcopy
        copied_market = copy.copy(market)
        copied_market.name = name
        self._markets[name] = copied_market
        self._market_name_to_symbols[name] = list(symbols)
        for symbol in symbols:
            self._symbol_market_names[symbol] = name

    def get_market(self, symbol: str) -> Market:
        """返回 symbol 当前市场规则的快照。"""
        return copy.copy(self._market_for(symbol))

    def process_market_batch(self, batch: TimeBatch):
        """处理一个完整时间批次。

        Exchange 只把原始市场事件交给 Broker。Broker 先按自己的估值配置选价，
        再一次性更新所有组合，最后处理挂单和退出条件。
        """

        execution_prices = self._select_prices(batch, self.execution_price) if self.execution_price is not None else None
        prices = self.update_market_batch(batch)
        execution_prices = prices if execution_prices is None else execution_prices
        for symbol, price in execution_prices.items():
            self._execution_prices[symbol] = price
            self._quote_versions[symbol] += 1
        self.process_pending_orders(dt=self._trading_dt(batch.dt), symbols=execution_prices)
        self.check_exit_rules(dt=self._trading_dt(batch.dt), data=batch)
        return prices

    def update_market_batch(self, batch: TimeBatch) -> Dict[str, float]:
        """从 TimeBatch 选出估值价格，并批量推进所有 Portfolio。"""

        self._assert_writable()
        prices = self._select_mark_prices(batch)
        self._validate_mark_prices(prices, batch=True)
        decision_dt = self._session_context.now() if self._session_context is not None and self._session_context.clock == "wall" else batch.dt
        self._advance_dt(decision_dt)

        for symbol, price in prices.items():
            self.last_prices[symbol] = price
            self.last_price_dates[symbol] = batch.dt
        for portfolio in self.portfolios.values():
            portfolio.update_market_batch(prices, decision_dt)
        self._expire_empty_positions()
        return prices

    def _select_mark_prices(self, batch: TimeBatch) -> Dict[str, float]:
        return self._select_prices(batch, self.mark_price, check_missing=True)

    def _select_prices(self, batch, source, check_missing=False):
        if source is None:
            return {}

        if callable(source):
            symbols = {
                item.event.symbol
                for item in batch.bars()
            }
            symbols.update(self._known_symbols())
            selected = {}
            for symbol in sorted(symbols):
                value = source(batch, symbol)
                if value is None:
                    continue
                selected[symbol] = self._validate_mark_value(symbol, value)
            if check_missing:
                self._check_missing_mark_prices(batch, selected)
            return selected

        candidates = {}
        for item in batch.bars():
            event = item.event
            if not self._matches_mark_source(item, event, source):
                continue
            field = source[-1]
            if not isinstance(event.data, dict) and not hasattr(event.data, "get"):
                continue
            value = event.data.get(field)
            if value is None:
                continue
            candidates.setdefault(event.symbol, []).append(
                (item, self._validate_mark_value(event.symbol, value))
            )

        selected = {}
        for symbol, values in candidates.items():
            selected[symbol] = self._aggregate_mark_values(symbol, values)
        if check_missing:
            self._check_missing_mark_prices(batch, selected)
        return selected

    @staticmethod
    def _matches_mark_source(item, event: Bar, source: Tuple[str, ...]) -> bool:
        if len(source) == 2:
            return event.kind == source[0]
        return item.feed_name == source[0] and event.kind == source[1]

    def _aggregate_mark_values(self, symbol: str, values) -> float:
        prices = [price for _, price in values]
        aggregation = self.mark_price_aggregation
        if callable(aggregation):
            result = aggregation(tuple(prices))
            return self._validate_mark_value(symbol, result)
        if len(prices) > 1 and aggregation == "error":
            raise ValueError(
                f"multiple mark prices for {symbol!r} in one TimeBatch; "
                "set mark_price_aggregation to 'first', 'last', or a callable"
            )
        return prices[0] if aggregation in ("error", "first") else prices[-1]

    @staticmethod
    def _validate_mark_value(symbol: str, value) -> float:
        try:
            result = float(value)
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError(f"mark price for {symbol!r} is not numeric: {value!r}") from exc
        if not math.isfinite(result) or result <= 0:
            raise ValueError(f"mark price for {symbol!r} must be finite and positive: {value!r}")
        return result

    def _check_missing_mark_prices(self, batch: TimeBatch, selected: Dict[str, float]) -> None:
        if self.mark_price_missing == "error":
            missing = sorted(
                symbol
                for symbol in self._symbols_requiring_market_price()
                if symbol not in selected
            )
        else:
            missing = sorted(
                symbol
                for symbol in self._symbols_requiring_market_price()
                if symbol not in selected and symbol not in self.last_prices
            )
        if missing:
            source = self._mark_price_description()
            raise ValueError(
                f"mark price {source} did not provide prices at {batch.dt!r} for symbols {missing!r}; "
                f"add the required field or configure mark_price, for example "
                f"mark_price='orderbook.mid'"
            )

    def _symbols_requiring_market_price(self):
        symbols = set()
        for portfolio in self.portfolios.values():
            symbols.update(
                symbol
                for symbol, position in portfolio.positions.items()
                if not position.is_empty()
            )
        for order_id in self._pending_order_ids:
            order = self.orders.get(order_id)
            if order is not None:
                symbols.add(order.symbol)
        return symbols

    def _mark_price_description(self) -> str:
        source = self.mark_price
        if callable(source):
            return "callable mark_price"
        if source is None:
            return "disabled mark_price"
        if len(source) == 2:
            return repr(f"{source[0]}.{source[1]}")
        return repr(f"{source[0]}:{source[1]}.{source[2]}")

    def on_new_price(self, symbol: str, price: float, dt: Optional[DateType] = None):
        self._assert_writable()
        symbol = normalize_symbol(symbol)
        price = positive_number(price, "price")
        dt = normalize_datetime(dt) if dt is not None else None
        self._validate_mark_prices({symbol: price})
        self._advance_dt(self._trading_dt(dt))
        self._apply_price(symbol, price, dt)
        self._execution_prices[symbol] = price
        self._quote_versions[symbol] += 1

    def _validate_mark_prices(self, prices, *, batch=False):
        """显式报价和批次行情先检查所有分仓，不能只预检下单分仓。"""
        _finite_sum((
            account._preview_mark_prices(prices, batch=batch) for account in self.portfolios.values()
        ), "broker equity")

    def _apply_price(self, symbol: str, price: float, dt) -> None:
        """写入已校验的报价并结算风险，不把报价时间当成交易时钟。"""
        self.last_prices[symbol] = price
        self.last_price_dates[symbol] = dt
        for portfolio in self.portfolios.values():
            portfolio.on_new_price(symbol, price, dt, risk_dt=self._last_market_dt)
        self._expire_empty_positions()

    def get_last_price(self, symbol: str, return_dt: bool = False):
        symbol = normalize_symbol(symbol)
        price = self.last_prices.get(symbol)
        if return_dt:
            return price, self.last_price_dates.get(symbol)
        return price

    def get_market_price(self, symbol: str, return_dt: bool = False):
        return self.get_last_price(symbol, return_dt)

    def submit_market_order(
        self,
        symbol: str,
        qty: float,
        price: Optional[float] = None,
        *,
        leverage: Optional[float] = None,
        price_dt: Optional[DateType] = None,
        portfolio: Optional[str] = None,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
    ) -> Order:
        return self._submit_market_order(
            symbol,
            qty,
            price,
            leverage=leverage,
            price_dt=price_dt,
            normalize_qty=False,
            portfolio=portfolio,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
            source="submit_market_order",
        )

    def _submit_market_order(
        self,
        symbol: str,
        qty: float,
        price: Optional[float] = None,
        *,
        leverage: Optional[float] = None,
        price_dt: Optional[DateType] = None,
        normalize_qty: bool = False,
        portfolio: Optional[str] = None,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
        source: OrderSource = "submit_market_order",
    ) -> Order:
        self._assert_writable()
        self._validate_execution_options(price, price_dt, leverage)
        symbol = normalize_symbol(symbol)
        qty = finite_number(qty, "qty")
        if qty == 0:
            raise ValueError(f"qty must be non-zero, got {qty}")
        portfolio = self._resolve_portfolio(portfolio)
        if self.execution != "legacy_immediate" and inflight_order(self.orders.values(), symbol, portfolio):
            return self._conflict_order(symbol, portfolio, source, qty)
        self._validate_leverage(leverage)
        exec_price, resolved_dt = self._resolve_market_price(symbol, price, price_dt)
        self.portfolios[portfolio]._validate_order_values(
            symbol, qty, exec_price, leverage,
            exec_price if price is not None else self.get_last_price(symbol),
        )
        self._validate_attached_exit_params(
            position_size=self.get_position_size(symbol, portfolio=portfolio) + qty,
            reference_price=exec_price,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
        )
        exec_price, resolved_dt = self._prepare_market_price(symbol, price, price_dt)

        if normalize_qty:
            qty = self._market_for(symbol).normalize_order_qty(self, symbol, qty, price=exec_price, portfolio=portfolio)
            if qty == 0:
                return self._create_order(
                    symbol=symbol,
                    portfolio=portfolio,
                    order_type="market",
                    source=source,
                    qty=0,
                    status="skipped",
                    requested_price=exec_price,
                    reason="target unchanged after quantity normalization",
                    created_dt=resolved_dt,
                    updated_dt=resolved_dt,
                )

        expected_position_size = self.get_position_size(symbol, portfolio=portfolio) + qty
        self._validate_attached_exit_params(
            position_size=expected_position_size,
            reference_price=exec_price,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
        )
        exit_params = {
            "stop_loss_price": stop_loss_price,
            "take_profit_price": take_profit_price,
            "trailing_stop_pct": trailing_stop_pct,
            "trailing_stop_amount": trailing_stop_amount,
        }
        order = self._create_order(
            symbol=symbol,
            portfolio=portfolio,
            order_type="market",
            source=source,
            qty=qty,
            status="pending",
            requested_price=exec_price,
            created_dt=resolved_dt,
        )
        if self.execution != "legacy_immediate":
            if not self._can_queue(symbol, qty, exec_price, portfolio):
                return self._update_order(order, status="rejected", reason="portfolio rejected order during submission precheck", updated_dt=resolved_dt)
            order.execution_state = "queued"
            self._pending_order_ids.append(order.id)
            self._submitted_versions[order.id] = self._quote_versions[symbol]
            self._pending_exit_params[order.id] = exit_params
            return order
        return self._execute_existing_order(
            order,
            price=exec_price,
            price_dt=resolved_dt,
            leverage=leverage,
            exit_params=exit_params,
        )

    def submit_limit_order(
        self,
        symbol: str,
        qty: float,
        limit_price: float,
        *,
        price_dt: Optional[DateType] = None,
        portfolio: Optional[str] = None,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
    ) -> Order:
        self._assert_writable()
        self._validate_execution_options(price_dt=price_dt)
        symbol = normalize_symbol(symbol)
        qty = finite_number(qty, "qty")
        if qty == 0:
            raise ValueError(f"qty must be non-zero, got {qty}")
        limit_price = positive_number(limit_price, "limit_price")
        portfolio = self._resolve_portfolio(portfolio)
        if self.execution != "legacy_immediate" and inflight_order(self.orders.values(), symbol, portfolio):
            return self._conflict_order(symbol, portfolio, "submit_limit_order", qty)
        price_dt = self._trading_dt(price_dt)
        self._validate_exit_values(
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
        )
        self.portfolios[portfolio]._validate_order_values(
            symbol, qty, limit_price, mark_price=self.get_last_price(symbol),
        )
        self._advance_dt(price_dt)
        validation = self._market_for(symbol).validate_order(
            self,
            symbol,
            qty,
            limit_price,
            dt=price_dt,
            portfolio=portfolio,
        )
        order = self._create_order(
            symbol=symbol,
            portfolio=portfolio,
            order_type="limit",
            source="submit_limit_order",
            qty=qty,
            status="pending",
            limit_price=limit_price,
            created_dt=price_dt,
        )
        if not validation.ok:
            return self._update_order(order, status="rejected", reason=validation.message, updated_dt=price_dt)

        can_submit, _ = self.portfolios[portfolio].can_submit_orders(
            [
                {
                    "symbol": symbol,
                    "qty": qty,
                    "price": limit_price,
                    "leverage": None,
                    "price_dt": price_dt,
                    "mark_price": self.get_last_price(symbol),
                    "mark_dt": self.last_price_dates.get(symbol),
                }
            ]
        )
        if self.execution != "legacy_immediate":
            can_submit = can_submit and self._can_queue(symbol, qty, limit_price, portfolio)
        if not can_submit:
            return self._update_order(
                order,
                status="rejected",
                reason="portfolio rejected order during submission precheck",
                updated_dt=price_dt,
            )

        self._pending_order_ids.append(order.id)
        self._submitted_versions[order.id] = self._quote_versions[symbol]
        self._pending_exit_params[order.id] = {
            "stop_loss_price": stop_loss_price,
            "take_profit_price": take_profit_price,
            "trailing_stop_pct": trailing_stop_pct,
            "trailing_stop_amount": trailing_stop_amount,
        }
        return order

    def cancel_order(self, order_id: str) -> Order:
        self._assert_writable()
        if order_id not in self.orders:
            raise ValueError(f"order not found: {order_id}")
        order = self.orders[order_id]
        if order.status not in ("pending", "partially_filled"):
            return order
        self._cancel_pending_order(order, reason="canceled by user")
        if self.execution != "legacy_immediate":
            return order
        return self._create_order(
            symbol=order.symbol,
            portfolio=order.portfolio,
            order_type=order.order_type,
            source="cancel_order",
            qty=0,
            status="canceled",
            reason=f"order canceled: {order_id}",
            updated_dt=order.updated_dt,
            created_dt=order.updated_dt,
        )

    def _cancel_pending_order(self, order: Order, *, reason: str) -> None:
        """取消 pending 原订单，并同步清理所有待成交附属状态。"""
        self._pending_order_ids = [
            pending_id for pending_id in self._pending_order_ids if pending_id != order.id
        ]
        self._pending_exit_params.pop(order.id, None)
        self._submitted_versions.pop(order.id, None)
        self._update_order(order, status="canceled", reason=reason, updated_dt=self._trading_dt())

    def _cancel_pending_orders_for_portfolio(self, portfolio: str) -> None:
        """关闭组合成功后，取消仍指向该组合的全部待成交订单。"""
        for order_id in list(self._pending_order_ids):
            order = self.orders.get(order_id)
            if order is None or order.status not in ("pending", "partially_filled") or order.portfolio != portfolio:
                continue
            self._cancel_pending_order(order, reason=f"portfolio closed: {portfolio}")

    def process_pending_orders(self, dt=None, *, symbols=None) -> None:
        self._assert_writable()
        updated_symbols = None if symbols is None else {normalize_symbol(symbol) for symbol in symbols}
        for order_id in list(self._pending_order_ids):
            order = self.orders.get(order_id)
            if order is None or order.status not in ("pending", "partially_filled"):
                self._pending_order_ids.remove(order_id)
                self._pending_exit_params.pop(order_id, None)
                continue
            if updated_symbols is not None and order.symbol not in updated_symbols:
                continue
            if self.execution != "legacy_immediate" and self._quote_versions[order.symbol] <= self._submitted_versions.get(order.id, -1):
                continue
            current_price = (self.last_prices if self.execution == "legacy_immediate" else self._execution_prices).get(order.symbol)
            if current_price is None:
                continue
            if order.order_type == "market":
                should_fill = True
            elif order.qty > 0:
                should_fill = current_price <= order.limit_price
            else:
                should_fill = current_price >= order.limit_price
            if not should_fill:
                continue
            if self.execution != "legacy_immediate" and order.source in ("close_position", "close_portfolio"):
                size = self.get_position_size(order.symbol, portfolio=order.portfolio)
                if size == 0 or size * order.qty >= 0:
                    self._cancel_pending_order(order, reason="reduce-only position is empty")
                    continue
                if abs(order.remaining_qty) > abs(size):
                    order.qty = order.filled_qty - size
            exit_params = self._pending_exit_params.get(order_id, {})
            fill_dt = self._trading_dt(dt if dt is not None else self.last_price_dates.get(order.symbol))
            fill_price = current_price if order.order_type == "market" else order.limit_price
            fill_qty = order.remaining_qty
            if self.fill_quantity is not None:
                from ..result import snapshot_order
                fill_qty = finite_number(self.fill_quantity(snapshot_order(order), fill_price, fill_dt), "fill_quantity result")
                if fill_qty and (fill_qty * order.remaining_qty <= 0 or (abs(fill_qty) > abs(order.remaining_qty)
                                 and not math.isclose(fill_qty, order.remaining_qty, rel_tol=1e-12, abs_tol=0))):
                    raise ValueError("fill_quantity result must have the remaining direction and not exceed remaining_qty")
                if math.isclose(fill_qty, order.remaining_qty, rel_tol=1e-12, abs_tol=0):
                    fill_qty = order.remaining_qty
            self._submitted_versions[order_id] = self._quote_versions[order.symbol]
            if not fill_qty:
                continue
            expected_position_size = self.get_position_size(
                order.symbol,
                portfolio=order.portfolio,
            ) + fill_qty
            try:
                self._validate_attached_exit_params(
                    position_size=expected_position_size,
                    reference_price=current_price if order.order_type == "market" else order.limit_price,
                    **exit_params,
                )
            except ValueError as exc:
                self._pending_order_ids.remove(order_id)
                self._pending_exit_params.pop(order_id, None)
                self._update_order(
                    order,
                    status="rejected",
                    reason=f"exit conditions invalid at fill: {exc}",
                    updated_dt=dt,
                )
                continue
            self._execute_existing_order(
                order,
                price=fill_price,
                price_dt=fill_dt,
                leverage=None,
                exit_params=exit_params,
                fill_qty=fill_qty,
            )
            self._pending_exit_params.pop(order_id, None)
            if order.is_done:
                self._pending_order_ids.remove(order_id)
                self._submitted_versions.pop(order_id, None)
        for portfolio in tuple(self._closing_portfolios):
            if not any(self.orders[o].portfolio == portfolio for o in self._pending_order_ids):
                self._closing_portfolios.remove(portfolio)
                if portfolio != DEFAULT_PORTFOLIO and not self.get_position_sizes(portfolio=portfolio):
                    self._close_portfolio_account(portfolio)

    def order_target_size(
        self,
        symbol: str,
        target_size: float,
        price: Optional[float] = None,
        *,
        leverage: Optional[float] = None,
        price_dt: Optional[DateType] = None,
        portfolio: Optional[str] = None,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
    ) -> Order:
        return self._order_target_size(
            symbol,
            target_size,
            price,
            leverage=leverage,
            price_dt=price_dt,
            portfolio=portfolio,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
            source="target_size",
        )

    def _order_target_size(
        self,
        symbol: str,
        target_size: float,
        price: Optional[float] = None,
        *,
        leverage: Optional[float] = None,
        price_dt: Optional[DateType] = None,
        portfolio: Optional[str] = None,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
        source: OrderSource = "target_size",
    ) -> Order:
        self._assert_writable()
        self._validate_execution_options(price, price_dt, leverage)
        symbol = normalize_symbol(symbol)
        target_size = finite_number(target_size, "target_size")
        self._validate_leverage(leverage)
        self._validate_exit_values(
            stop_loss_price=stop_loss_price, take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct, trailing_stop_amount=trailing_stop_amount,
        )
        portfolio = self._resolve_portfolio(portfolio)
        if self.execution != "legacy_immediate":
            pending = inflight_order(self.orders.values(), symbol, portfolio)
            if same_target(pending, target_size, self._intent_targets):
                return pending
            if pending is not None:
                original = self._intent_requests.get(pending.id)
                if original is not None:
                    raw_target, origin = original
                    if raw_target == target_size:
                        return pending
                    normalized = self._market_for(symbol).normalize_order_qty(
                        self, symbol, finite_number(target_size - origin, "target delta"),
                        price=self.get_last_price(symbol), portfolio=portfolio,
                    )
                    if same_target(pending, _finite_sum((origin, normalized), "normalized target"), self._intent_targets):
                        return pending
                return self._conflict_order(symbol, portfolio, source)
        current_size = self.get_position_size(symbol, portfolio=portfolio)
        if price is not None or target_size != current_size:
            exec_price, _ = self._resolve_market_price(symbol, price, price_dt)
            qty = finite_number(target_size - current_size, "qty")
            self.portfolios[portfolio]._validate_order_values(symbol, qty, exec_price, leverage)
            self._validate_attached_exit_params(
                position_size=target_size, reference_price=exec_price,
                stop_loss_price=stop_loss_price, take_profit_price=take_profit_price,
                trailing_stop_pct=trailing_stop_pct, trailing_stop_amount=trailing_stop_amount,
            )
            _, resolved_dt = self._prepare_market_price(symbol, price, price_dt)
        else:
            if price_dt is not None:
                raise ValueError("price_dt must be None when price is omitted")
            resolved_dt = self._trading_dt()
        current_size = self.get_position_size(symbol, portfolio=portfolio)
        qty = finite_number(target_size - current_size, "qty")
        if qty == 0:
            return self._create_order(
                symbol=symbol,
                portfolio=portfolio,
                order_type="market",
                source=source,
                qty=0,
                status="skipped",
                reason="position is empty" if source == "close_position" else "target size unchanged",
                created_dt=resolved_dt,
                updated_dt=resolved_dt,
            )
        order = self._submit_market_order(
            symbol,
            qty=qty,
            price=None,
            leverage=leverage,
            price_dt=None,
            normalize_qty=True,
            portfolio=portfolio,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
            source=source,
        )
        self._intent_targets[order.id] = target_size if self.execution == "legacy_immediate" else _finite_sum((current_size, order.qty), "normalized target")
        self._intent_requests[order.id] = (target_size, current_size)
        return order

    def order_target_value(
        self,
        symbol: str,
        target_value: float,
        price: Optional[float] = None,
        *,
        leverage: Optional[float] = None,
        price_dt: Optional[DateType] = None,
        portfolio: Optional[str] = None,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
    ) -> Order:
        return self._order_target_value(
            symbol,
            target_value,
            price,
            leverage=leverage,
            price_dt=price_dt,
            portfolio=portfolio,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
            source="target_value",
        )

    def _order_target_value(
        self,
        symbol: str,
        target_value: float,
        price: Optional[float] = None,
        *,
        leverage: Optional[float] = None,
        price_dt: Optional[DateType] = None,
        portfolio: Optional[str] = None,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
        source: OrderSource = "target_value",
    ) -> Order:
        self._assert_writable()
        self._validate_execution_options(price, price_dt, leverage)
        symbol = normalize_symbol(symbol)
        target_value = finite_number(target_value, "target_value")
        self._validate_leverage(leverage)
        portfolio = self._resolve_portfolio(portfolio)
        exec_price, _ = self._resolve_market_price(symbol, price, price_dt)
        target_size = target_value / exec_price
        finite_number(target_size, "target_size")
        self._validate_attached_exit_params(
            position_size=target_size, reference_price=exec_price,
            stop_loss_price=stop_loss_price, take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct, trailing_stop_amount=trailing_stop_amount,
        )
        return self._order_target_size(
            symbol,
            target_size=target_size,
            price=price,
            leverage=leverage,
            price_dt=price_dt,
            portfolio=portfolio,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
            source=source,
        )

    def order_target_percent(
        self,
        symbol: str,
        target_percent: float,
        price: Optional[float] = None,
        *,
        leverage: Optional[float] = None,
        price_dt: Optional[DateType] = None,
        portfolio: Optional[str] = None,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
    ) -> Order:
        self._assert_writable()
        self._validate_execution_options(price, price_dt, leverage)
        symbol = normalize_symbol(symbol)
        target_percent = finite_number(target_percent, "target_percent")
        self._validate_leverage(leverage)
        portfolio = self._resolve_portfolio(portfolio)
        exec_price, _ = self._resolve_market_price(symbol, price, price_dt)
        # 风险结算不增加交易费用；先预测报价后的权益，避免写入行情后才发现目标溢出。
        equity = self.portfolios[portfolio]._preview_mark_prices({symbol: exec_price}) if price is not None else self.get_equity(portfolio=portfolio)
        target_value = finite_number(equity * target_percent, "target_value")
        target_size = finite_number(target_value / exec_price, "target_size")
        qty = finite_number(target_size - self.get_position_size(symbol, portfolio=portfolio), "qty")
        self.portfolios[portfolio]._validate_order_values(symbol, qty, exec_price, leverage)
        self._validate_attached_exit_params(
            position_size=target_size,
            reference_price=exec_price,
            stop_loss_price=stop_loss_price, take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct, trailing_stop_amount=trailing_stop_amount,
        )
        self._prepare_market_price(symbol, price, price_dt)
        equity = self.get_equity(portfolio=portfolio)
        target_value = finite_number(equity * target_percent, "target_value")
        return self._order_target_value(
            symbol,
            target_value=target_value,
            price=None,
            leverage=leverage,
            price_dt=None,
            portfolio=portfolio,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
            source="target_percent",
        )

    def close_position(
        self,
        symbol: str,
        price: Optional[float] = None,
        *,
        price_dt: Optional[DateType] = None,
        portfolio: Optional[str] = None,
    ) -> Order:
        return self._order_target_size(
            symbol,
            target_size=0,
            price=price,
            price_dt=price_dt,
            portfolio=portfolio,
            source="close_position",
        )

    def close_portfolio(self, portfolio: str) -> List[Order]:
        self._assert_writable()
        portfolio = self._resolve_portfolio(portfolio)
        if self.execution != "legacy_immediate":
            if portfolio in self._closing_portfolios:
                return [self.orders[o] for o in self._pending_order_ids if self.orders[o].portfolio == portfolio]
            self._cancel_pending_orders_for_portfolio(portfolio)
            orders = [self._order_target_size(s, 0, portfolio=portfolio, source="close_portfolio")
                      for s in self.get_position_sizes(portfolio=portfolio)]
            if orders:
                if any(not o.is_done for o in orders):
                    self._closing_portfolios.add(portfolio)
                return orders
        close_plan = []
        for symbol, position in list(self.portfolios[portfolio].positions.items()):
            if position is None or position.is_empty():
                continue
            price, quote_dt = self.get_last_price(symbol, return_dt=True)
            price_dt = self._trading_dt(quote_dt)
            if price is None:
                return [
                    self._create_order(
                        symbol=symbol,
                        portfolio=portfolio,
                        order_type="market",
                        source="close_portfolio",
                        qty=-position.size,
                        status="rejected",
                        reason=f"market price not found: {symbol}",
                    )
                ]
            validation = self._market_for(symbol).validate_order(
                self,
                symbol,
                -position.size,
                price,
                dt=price_dt,
                portfolio=portfolio,
            )
            if not validation.ok:
                return [
                    self._create_order(
                        symbol=symbol,
                        portfolio=portfolio,
                        order_type="market",
                        source="close_portfolio",
                        qty=-position.size,
                        status="rejected",
                        requested_price=price,
                        reason=validation.message,
                        created_dt=price_dt,
                        updated_dt=price_dt,
                    )
                ]
            close_plan.append((symbol, price, price_dt))

        if not close_plan:
            if portfolio != DEFAULT_PORTFOLIO:
                account = self.portfolios[portfolio]
                self._preview_portfolio_return(portfolio, account.total_cash, account._booked_pnl)
            self._cancel_pending_orders_for_portfolio(portfolio)
            if portfolio != DEFAULT_PORTFOLIO:
                self._close_portfolio_account(portfolio)
            return [
                self._create_order(
                    symbol="*",
                    portfolio=portfolio,
                    order_type="market",
                    source="close_portfolio",
                    qty=0,
                    status="skipped",
                    reason="portfolio has no open positions",
                )
            ]

        preview_orders = []
        for symbol, price, price_dt in close_plan:
            position = self.get_position(symbol, portfolio=portfolio)
            preview_orders.append(
                {
                    "symbol": symbol,
                    "qty": -position.size,
                    "price": price,
                    "leverage": None,
                    "price_dt": price_dt,
                    "mark_price": price,
                    "mark_dt": self.last_price_dates.get(symbol),
                }
            )
        account = self.portfolios[portfolio]
        prepared, released_cash = account._preview_close_orders(preview_orders)
        if not account._current_cash.can_change_cash(released_cash):
            failed = preview_orders[0]
            return [
                self._create_order(
                    symbol=failed["symbol"],
                    portfolio=portfolio,
                    order_type="market",
                    source="close_portfolio",
                    qty=failed["qty"],
                    status="rejected",
                    requested_price=failed["price"],
                    reason="portfolio rejected atomic close plan",
                    created_dt=failed["price_dt"],
                    updated_dt=failed["price_dt"],
                )
            ]

        if portfolio != DEFAULT_PORTFOLIO:
            _, closing_cash = account._current_cash._preview_change_cash(released_cash)
            booked = account._booked_pnl.copy()
            for row in prepared:
                symbol = row["symbol"]
                booked[symbol] = _sum_pnl((booked.get(symbol, Pnl()), Pnl(realized_pnl=row["realized_pnl"], fees=row["fee"])))
            self._preview_portfolio_return(portfolio, closing_cash, booked)

        orders = []
        for row in prepared:
            order = self._create_order(
                symbol=row["symbol"], portfolio=portfolio, order_type="market",
                source="close_portfolio",
                qty=row["qty"], status="pending", requested_price=row["price"],
                created_dt=row["price_dt"],
            )
            row["order_id"] = order.id
            orders.append(order)
        account._commit_close_orders(prepared, released_cash)
        for order, row in zip(orders, prepared):
            self._update_order(
                order, status="filled", filled_qty=row["qty"],
                avg_price=row["price"], updated_dt=row["price_dt"],
            )
            self._after_order_filled(order, old_size=-row["qty"], price=row["price"], dt=row["price_dt"])
        self._expire_empty_positions()
        self._cancel_pending_orders_for_portfolio(portfolio)
        if portfolio != DEFAULT_PORTFOLIO:
            self._close_portfolio_account(portfolio)
        return orders

    def set_exit(
        self,
        order_id: str,
        *,
        stop_loss_price: Optional[float] = None,
        take_profit_price: Optional[float] = None,
        trailing_stop_pct: Optional[float] = None,
        trailing_stop_amount: Optional[float] = None,
    ) -> ExitConfig:
        self._assert_writable()
        if not self._exit_params_provided(
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
        ):
            raise ValueError("at least one exit condition must be provided")
        if order_id not in self.orders:
            raise ValueError(f"order not found: {order_id}")
        order = self.orders[order_id]
        if not order.filled_qty:
            raise ValueError(f"exit requires an actual fill, got {order.status}")
        self._require_current_exit_order(order)
        position = self.get_position(order.symbol, portfolio=order.portfolio)
        if position is None or position.is_empty():
            raise ValueError(f"position is empty: {order.symbol}")
        reference_price = self.get_last_price(order.symbol) or order.avg_price
        self._validate_exit_params(
            position_size=position.size,
            reference_price=reference_price,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct,
            trailing_stop_amount=trailing_stop_amount,
        )
        self._activate_standard_exit(
            order, reference_price=reference_price,
            stop_loss_price=stop_loss_price, take_profit_price=take_profit_price,
            trailing_stop_pct=trailing_stop_pct, trailing_stop_amount=trailing_stop_amount,
        )
        return self._exit_states[order.id].to_config()

    def clear_exit(
        self,
        order_id: str,
        *,
        stop_loss_price: bool = True,
        take_profit_price: bool = True,
        trailing_stop: bool = True,
        custom: bool = True,
    ) -> ExitConfig:
        self._assert_writable()
        if not any((stop_loss_price, take_profit_price, trailing_stop, custom)):
            raise ValueError("at least one clear flag must be true")
        if order_id not in self.orders:
            raise ValueError(f"order not found: {order_id}")
        order = self.orders[order_id]
        self._require_current_exit_order(order)
        state = self._get_or_create_exit_state(order)
        self._triggered_exits.pop(order_id, None)
        if stop_loss_price:
            state.stop_loss_price = None
        if take_profit_price:
            state.take_profit_price = None
        if trailing_stop:
            state.trailing_stop_pct = None
            state.trailing_stop_amount = None
            state.trailing_anchor = None
        if custom:
            state.custom_rules.clear()
        self._activate_exit_state(order, state)
        return state.to_config()

    def get_exit(self, order_id: str) -> Optional[ExitConfig]:
        state = self._exit_states.get(order_id)
        return None if state is None else state.to_config()

    def add_exit(
        self,
        order_id: str,
        *,
        name: Optional[str] = None,
        condition,
        state=None,
    ) -> ExitRule:
        self._assert_writable()
        if order_id not in self.orders:
            raise ValueError(f"order not found: {order_id}")
        order = self.orders[order_id]
        if not order.filled_qty:
            raise ValueError(f"exit requires an actual fill, got {order.status}")
        self._require_current_exit_order(order)
        if not callable(condition):
            raise TypeError("condition must be callable")
        resolved_state = state() if callable(state) else state
        if resolved_state is None:
            resolved_state = {}
        if not isinstance(resolved_state, dict):
            raise TypeError("state must be a dict, a callable returning dict, or None")
        rule = ExitRule(
            name=name or getattr(condition, "__name__", "exit_rule"),
            condition=condition,
            state=resolved_state,
        )
        exit_state = self._get_or_create_exit_state(order)
        exit_state.custom_rules.append(rule)
        self._activate_exit_state(order, exit_state)
        return rule

    def check_exit_rules(self, dt=None, data=None) -> None:
        self._assert_writable()
        self._advance_dt(self._trading_dt(dt))
        for order_id in list(self._active_exit_order_by_position.values()):
            state = self._exit_states[order_id]
            if not state.active:
                continue
            order = self.orders.get(order_id)
            if order is None or not order.filled_qty:
                state.active = False
                continue
            if not self._position_has_active_exit(order.portfolio, order.symbol, order_id):
                continue
            position = self.get_position(order.symbol, portfolio=order.portfolio)
            if position is None or position.is_empty():
                state.active = False
                key = (order.portfolio, order.symbol)
                self._active_exit_order_by_position.pop(key, None)
                self._position_order_ids.pop(key, None)
                continue
            price = self.get_last_price(order.symbol)
            if price is None:
                continue
            reason = self._triggered_exits.get(order_id) or self._exit_trigger_reason(state, order, position, price, dt, data)
            if reason is None:
                continue
            if self.execution != "legacy_immediate":
                self._triggered_exits[order_id] = reason
                pending = inflight_order(self.orders.values(), order.symbol, order.portfolio)
                if pending is not None:
                    if pending.source not in ("close_position", "close_portfolio"):
                        self._cancel_pending_order(pending, reason="exit triggered")
                    else:
                        continue
            close_order = self.close_position(order.symbol, portfolio=order.portfolio)
            if close_order.status == "filled":
                state.active = False
                self._active_exit_order_by_position.pop((order.portfolio, order.symbol), None)
                self.logger.info(f"Exit triggered: order={order_id}, symbol={order.symbol}, reason={reason}, dt={dt}")
            else:
                self.logger.warning(
                    f"Exit rejected: order={order_id}, symbol={order.symbol}, reason={reason}, dt={dt}, "
                    f"order_status={close_order.status}"
                )

    def _exit_trigger_reason(
        self,
        config: _ExitState,
        order: Order,
        position: Position,
        price: float,
        dt,
        data,
    ) -> Optional[str]:
        if position.size > 0:
            if config.stop_loss_price is not None and price <= config.stop_loss_price:
                return "stop_loss_price"
            if config.take_profit_price is not None and price >= config.take_profit_price:
                return "take_profit_price"
            if config.trailing_stop_pct is not None or config.trailing_stop_amount is not None:
                config.trailing_anchor = price if config.trailing_anchor is None else max(config.trailing_anchor, price)
                if config.trailing_stop_pct is not None:
                    stop_price = config.trailing_anchor * (1 - config.trailing_stop_pct)
                else:
                    stop_price = config.trailing_anchor - config.trailing_stop_amount
                if price <= stop_price:
                    return "trailing_stop"
        else:
            if config.stop_loss_price is not None and price >= config.stop_loss_price:
                return "stop_loss_price"
            if config.take_profit_price is not None and price <= config.take_profit_price:
                return "take_profit_price"
            if config.trailing_stop_pct is not None or config.trailing_stop_amount is not None:
                config.trailing_anchor = price if config.trailing_anchor is None else min(config.trailing_anchor, price)
                if config.trailing_stop_pct is not None:
                    stop_price = config.trailing_anchor * (1 + config.trailing_stop_pct)
                else:
                    stop_price = config.trailing_anchor + config.trailing_stop_amount
                if price >= stop_price:
                    return "trailing_stop"

        for rule in list(config.custom_rules):
            ctx = ExitContext(
                order_id=order.id,
                symbol=order.symbol,
                portfolio=order.portfolio,
                dt=dt,
                price=price,
                position=position,
                broker=self,
                data=data,
                state=rule.get_state(),
            )
            if rule.condition(ctx):
                return rule.name
        return None

    def get_order(self, order_id: str) -> Optional[Order]:
        return self.orders.get(order_id)

    def get_orders(
        self,
        *,
        portfolio: Optional[str] = None,
        symbol: Optional[str] = None,
    ) -> List[Order]:
        if symbol is not None:
            symbol = normalize_symbol(symbol)
        if portfolio is not None:
            self._require_portfolio(portfolio)
        return [
            order
            for order in self.orders.values()
            if (portfolio is None or order.portfolio == portfolio)
            and (symbol is None or order.symbol == symbol)
            and order.source != "cancel_order"
        ]

    def get_active_order(self, symbol: str, *, portfolio: Optional[str] = None) -> Optional[Order]:
        symbol = normalize_symbol(symbol)
        portfolio = self._resolve_portfolio(portfolio)
        order_id = self._active_exit_order_by_position.get((portfolio, symbol))
        if order_id is None:
            return None
        return self.orders.get(order_id)

    def get_all_portfolio_equity(self) -> float:
        return _finite_sum((portfolio.get_portfolio_equity() for portfolio in self.portfolios.values()), "broker equity")

    def get_total_equity(self) -> float:
        return self.get_all_portfolio_equity()

    def get_total_pnl(self, symbol: Optional[str] = None) -> Pnl:
        """查询全账户累计盈亏，包括已关闭分仓；净盈亏与总权益减初始资金一致。

        指定 symbol 时只汇总该标的，全仓穿仓的账户结算调整不归属任何标的。
        """
        if symbol is not None:
            symbol = normalize_symbol(symbol)
        results = [portfolio.get_pnl(symbol) for portfolio in self.portfolios.values()]
        for archived in self._closed_pnl.values():
            results.extend(archived.values() if symbol is None else (archived.get(symbol, Pnl()),))
        return _sum_pnl(results)

    def get_pnl(self, symbol: Optional[str] = None, *, portfolio: Optional[str] = None) -> Pnl:
        """查询一个分仓名称的累计盈亏，默认 main；关闭及同名重建后仍包含历史。

        未知标的返回零值。内部资金划拨不计入盈亏，因此分仓净盈亏不能直接用
        分仓当前权益减初始资金计算。
        """
        if symbol is not None:
            symbol = normalize_symbol(symbol)
        name = DEFAULT_PORTFOLIO if portfolio is None else portfolio
        self._require_pnl_portfolio(name)
        archived = self._closed_pnl.get(name, {})
        results = list(archived.values()) if symbol is None else [archived.get(symbol, Pnl())]
        active = self.portfolios.get(name)
        if active is not None:
            results.append(active.get_pnl(symbol))
        return _sum_pnl(results)

    def get_pnl_records(
        self,
        *,
        portfolio: Optional[str] = None,
        symbol: Optional[str] = None,
        order_id: Optional[str] = None,
    ) -> List[PnlRecord]:
        """按实际记账顺序返回成交及风险结算明细，默认全部，筛选条件取交集。

        未成交订单没有明细，系统结算的 order_id 为 None。返回新列表和不可变记录。
        """
        if symbol is not None:
            symbol = normalize_symbol(symbol)
        if portfolio is not None:
            self._require_pnl_portfolio(portfolio)
        return [
            record
            for record in self._pnl_records
            if (portfolio is None or record.portfolio == portfolio)
            and (symbol is None or record.symbol == symbol)
            and (order_id is None or record.order_id == order_id)
        ]

    def get_portfolios(self) -> List[str]:
        return list(self.portfolios.keys())

    def get_portfolio_equity(self, portfolio: Optional[str] = None) -> float:
        portfolio = self._resolve_portfolio(portfolio)
        return self.portfolios[portfolio].get_portfolio_equity()

    def get_portfolio_initial_cash(self, portfolio: Optional[str] = None) -> float:
        portfolio = self._resolve_portfolio(portfolio)
        return self.portfolios[portfolio].initial_cash

    def get_equity(self, portfolio: Optional[str] = None) -> float:
        portfolio = self._resolve_portfolio(portfolio)
        return self.portfolios[portfolio].get_portfolio_equity()

    def get_cash(self, portfolio: Optional[str] = None, include_locked: bool = False) -> float:
        portfolio = self._resolve_portfolio(portfolio)
        return self.portfolios[portfolio].get_cash(include_locked)

    def get_position(
        self,
        symbol: str,
        portfolio: Optional[str] = None,
    ) -> Optional[Position]:
        portfolio = self._resolve_portfolio(portfolio)
        return self.portfolios[portfolio].get_position(symbol, create_if_missing=False)

    def get_position_size(self, symbol: str, portfolio: Optional[str] = None) -> float:
        portfolio = self._resolve_portfolio(portfolio)
        return self.portfolios[portfolio].get_position_size(symbol)

    def get_position_sizes(self, portfolio: Optional[str] = None) -> Dict[str, float]:
        portfolio = self._resolve_portfolio(portfolio)
        return self.portfolios[portfolio].get_position_sizes()

    def get_positions(self, portfolio: Optional[str] = None) -> Dict[str, Position]:
        portfolio = self._resolve_portfolio(portfolio)
        return self.portfolios[portfolio].get_positions()
