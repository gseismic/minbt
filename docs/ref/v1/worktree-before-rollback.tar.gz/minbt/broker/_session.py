"""模拟账户的事件会话，保留同一账本在两种时钟下的执行语义。"""

from types import MappingProxyType

from ..events import AccountUpdate, SessionEvent


class SimSession:
    """账户写入由运行线程推进；这里只绑定许可和标准通知，不建立第二份账本。"""

    def __init__(self, broker):
        self.broker = broker  # 唯一的模拟账户事实来源。
        self.ready = False  # 首条可见行情后才能达到行情就绪。
        self.context = None  # 启动时绑定本次运行。
        self.emit = None  # 只投递通知，不调用策略。
        self.version = 0  # 已应用账户事实版本。
        self.last_state = None  # 估值变化不默认重复触发账户通知。

    def start(self, context, emit):
        with self.broker._run_lock:
            if self.broker._session_started:
                raise RuntimeError("Broker session has already started")
            self.broker._session_started = True
            self.broker._run_consumed = True
        self.context, self.emit = context, emit
        self.broker._session_context = context
        self.broker._event_sink = emit
        self.broker._account_sink = self.notify_account

    def on_market(self, batch):
        self.broker._session_applying = True
        try:
            self.broker.process_market_batch(batch)
            self.ready = True
            self.notify_account()
        finally:
            self.broker._session_applying = False

    def notify_account(self):
        broker = self.broker
        ready = self.ready and self.context.permissions.enabled
        positions = broker.get_position_sizes()
        state = (broker.get_cash(include_locked=True), tuple(sorted(positions.items())), ready)
        if state == self.last_state:
            return
        self.last_state = state
        self.version += 1
        self.emit(SessionEvent("sim", "on_account", AccountUpdate(
            "sim", self.version, self.context.now(), broker.get_cash(), broker.get_total_equity(),
            MappingProxyType(dict(positions)), ready,
        )))

    def apply(self, event):
        raise ValueError(f"simulated Broker does not accept external facts: {event.kind}")

    def request_stop(self):
        self.notify_account()

    def close(self, timeout):
        self.broker._event_sink = None
        self.broker._account_sink = None
        if self.broker.execution == "legacy_immediate":
            self.broker._session_context = None
