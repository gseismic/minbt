from dataclasses import dataclass
from typing import Any, Literal, Optional


OrderType = Literal["market", "limit"]
OrderSource = Literal[
    "submit_market_order",
    "submit_limit_order",
    "target_size",
    "target_value",
    "target_percent",
    "close_position",
    "close_portfolio",
    "cancel_order",
]
OrderSide = Literal["buy", "sell", "none"]
OrderStatus = Literal["pending", "filled", "canceled", "rejected", "skipped", "partially_filled", "unknown", "expired"]


@dataclass
class Order:
    id: str
    symbol: str
    portfolio: str
    order_type: OrderType
    source: OrderSource
    side: OrderSide
    qty: float
    status: OrderStatus
    requested_price: Optional[float] = None
    limit_price: Optional[float] = None
    filled_qty: float = 0.0
    avg_price: Optional[float] = None
    reason: Optional[str] = None
    created_dt: Any = None
    updated_dt: Any = None
    client_order_id: Optional[str] = None  # 稳定远端请求标识。
    exchange_order_id: Optional[str] = None  # 普通订单的远端 ID。
    execution_state: Optional[str] = None  # 请求执行细分阶段。
    reason_code: Optional[str] = None  # 程序可读的原因。

    @property
    def remaining_qty(self) -> float:
        return self.qty - self.filled_qty

    @property
    def is_done(self) -> bool:
        return self.status in ("filled", "canceled", "rejected", "skipped", "expired")
