"""模拟和外部账户共用的目标占用规则，避免各自计算重复敞口。"""


def inflight_order(orders, symbol, portfolio):
    """每个净持仓只容纳一个变仓意图，unknown 也必须占用。"""
    return next((o for o in orders if o.symbol == symbol and o.portfolio == portfolio and not o.is_done), None)


def same_target(order, target, targets):
    """目标在提交时固定为数量，行情更新不在后台自动修改它。"""
    return order is not None and targets.get(order.id) == target

