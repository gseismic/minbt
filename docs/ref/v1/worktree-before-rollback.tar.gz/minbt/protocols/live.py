"""实时源与事件账户的公开扩展边界，只依赖核心类型和标准库。"""

from dataclasses import dataclass
from typing import Any, Callable, Mapping, Optional, Protocol, runtime_checkable

from .broker import BrokerProtocol
from ..permissions import TradingPermissions


@dataclass(frozen=True)
class RunContext:
    """运行专属依赖，给插件显式时钟、身份和许可而不泄露其他插件对象。"""

    session_id: str  # 本次运行身份。
    clock: str  # virtual 或 wall。
    now: Callable  # 运行时钟读取函数。
    permissions: TradingPermissions  # 共享许可，输入线程只可 revoke。
    capabilities: Mapping[str, Any]  # 只读装配能力说明。
    history_limit: Optional[int] = None  # None 表示全量，否则保留窗口。
    result_dir: Optional[str] = None  # 显式完整结果目录。


@runtime_checkable
class BrokerSessionProtocol(Protocol):
    """一次运行的账户写入边界；emit 通知不授予调用 Strategy 的权限。"""

    ready: bool  # 账户与保护均已核实；行情许可另由运行器验证。

    def start(self, context: RunContext, emit: Callable) -> None: ...
    def on_market(self, batch) -> None: ...
    def apply(self, event) -> None: ...
    def request_stop(self) -> None: ...
    def close(self, timeout: float) -> Any: ...


@runtime_checkable
class EventBrokerProtocol(BrokerProtocol, Protocol):
    """事件型账户另行声明能力，不给旧 Broker 增加必需方法。"""

    def create_session(self) -> BrokerSessionProtocol: ...


@runtime_checkable
class MarketSourceProtocol(Protocol):
    """有界实时生产者，异常通过事件交付，停止和关闭不撤单不平仓。"""

    def start(self, emit: Callable) -> None: ...
    def stop(self) -> None: ...
    def close(self) -> Any: ...

