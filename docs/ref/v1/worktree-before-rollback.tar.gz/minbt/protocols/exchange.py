"""Exchange 对象契约，区别于薄配置入口的 EngineProtocol。"""

from typing import Protocol, runtime_checkable

from .result import ResultProtocol


@runtime_checkable
class ExchangeProtocol(Protocol):
    """独立插件可自行实现运行器，不要求继承内置类或调用私有函数。"""

    clock: str  # virtual 或 wall；不得从凭证或数据阻塞方式猜测。

    def add_strategy(self, strategy) -> None: ...
    def get_current_dt(self): ...
    def describe(self): ...
    def run(self, *, end=None, control=None, history_limit="auto", result_dir=None) -> ResultProtocol: ...

