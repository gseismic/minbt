"""跨实现的冻结业务事实；不包含 SDK 对象或策略回调。"""

from dataclasses import dataclass
from typing import Any, Mapping, Optional


@dataclass(frozen=True)
class Fill:
    """一笔唯一的已确认成交，保留有符号数量与原手续费资产以便核账。"""

    id: str  # 来源成交唯一标识。
    order_id: str  # 稳定本地订单标识。
    symbol: str  # 交易标的。
    portfolio: str  # 成交归属。
    qty: float  # 买正卖负。
    price: float  # 确认成交价。
    fee: float  # 原资产的实际手续费。
    fee_asset: str  # 原手续费币种。
    dt: Any  # 来源成交时间。


@dataclass(frozen=True)
class AccountUpdate:
    """当前账户冻结视图；ready 同时约束账户、保护和行情的可交易性。"""

    account_id: str  # 账户别名，不是凭证。
    version: int  # 本地应用版本，查询至少可见此版本。
    as_of: Any  # 最近应用时刻。
    cash: float  # 可用现金。
    equity: float  # 可验证权益。
    positions: Mapping[str, float]  # 冻结净持仓。
    ready: bool  # 该事实是否允许后续交易决策。


@dataclass(frozen=True)
class SessionEvent:
    """会话输入与标准通知的信封，区分事实应用和只向策略交付的通知。"""

    source: str  # 来源会话标识。
    kind: str  # market、连接事实或 on_order/on_fill/on_account。
    payload: Any  # 已复制的事实或冻结业务记录。
    sequence: int = 0  # 来源接受序号。
    received_at: Optional[float] = None  # 来源原始 UTC 接收时间，单位秒。

