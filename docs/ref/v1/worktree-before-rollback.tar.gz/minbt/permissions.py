"""发送许可服务：关闸和最终授权共享短临界区，后台只能撤销许可。"""

from contextlib import contextmanager
from threading import RLock, get_ident
import time

from .errors import TradingPermissionError


class TradingPermissions:
    """一次运行的许可与代次；插件在最终传输钩子消费授权，不把入队当发送。"""

    def __init__(self, monotonic=time.monotonic):
        self._lock = RLock()  # 关闸与最终发送决定的线性化边界。
        self._monotonic = monotonic  # 期限只依赖单调时间，便于故障注入。
        self._owner = get_ident()  # 只有运行线程能重新开闸。
        self.epoch = 0  # 任何失效都使旧请求永久失效。
        self.enabled = False  # 初始化、恢复和停止默认禁发。
        self.phase = None  # 同步只读回调不改变持久请求代次。
        self.reason = "initializing"  # 最近关闸诊断。
        self._checks = []  # 发送前同步复核，不允许网络等待。

    def add_check(self, check):
        if get_ident() != self._owner:
            raise RuntimeError("only the run thread may configure trading checks")
        self._checks.append(check)

    def _check_current(self):
        try:
            for check in self._checks:
                check()
        except BaseException:
            self.revoke("permission_check_failed")
            raise

    def revoke(self, reason):
        with self._lock:
            self.enabled = False
            self.epoch += 1
            self.reason = reason

    def open(self):
        if get_ident() != self._owner:
            raise RuntimeError("only the run thread may enable trading")
        with self._lock:
            self.enabled = True
            self.reason = None

    def assert_writable(self):
        if get_ident() != self._owner:
            raise RuntimeError("Broker can only be changed by its run thread")
        with self._lock:
            if self.phase is not None or not self.enabled:
                raise TradingPermissionError(f"Broker is read-only: {self.phase or self.reason}")
            self._check_current()

    def authorize(self, epoch, expires_at, *, validate=None, _controlled=False):
        """最终发送边界的一次决定；返回后即视为在途，禁止再等待业务队列。"""
        with self._lock:
            controlled_ready = _controlled and self.reason in ("pause", "not_ready", "account_sync_pending",
                                                               "account_reconciling", "permission_check_failed")
            if (not self.enabled and not controlled_ready) or epoch != self.epoch:
                raise TradingPermissionError("gate_revoked")
            if self._monotonic() >= expires_at:
                raise TradingPermissionError("intent_expired")
            self._check_current()
            if validate is not None:
                validate()

    def authorize_controlled(self, epoch, expires_at, *, validate):
        """受控保护/恢复许可，调用方必须核对当前持仓、归属与业务义务。"""
        return self.authorize(epoch, expires_at, validate=validate, _controlled=True)

    @contextmanager
    def readonly(self, phase):
        previous = self.phase
        self.phase = phase
        try:
            yield
        finally:
            self.phase = previous
