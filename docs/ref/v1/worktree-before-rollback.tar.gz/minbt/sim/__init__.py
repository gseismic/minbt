"""历史与实时共用的模拟交易账户。"""

from ..broker import Broker

__all__ = ["Broker"]
