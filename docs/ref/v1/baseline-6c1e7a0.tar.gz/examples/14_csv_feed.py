import os
from pathlib import Path

import matplotlib.pyplot as plt

from minbt import Broker, Exchange, Strategy
from minbt.plugins.binance import BinanceKlineCsvFeed


SYMBOL = "BTCUSDT"
CSV_ROOT = Path(
    os.environ.get(
        "MINBT_CSV_ROOT",
        "/media/lsl/Z1/findata/crypto/binance/future_usdt/kline.csv/1m",
    )
)
START = "2023-01-01"
END = "2023-01-03"


class CsvFeedStrategy(Strategy):
    def on_init(self):
        self.bar_count = 0

    def on_bars(self, dt, bars):
        price = bars[SYMBOL]["close"]
        if self.bar_count == 0:
            self.broker.order_target_percent(SYMBOL, 0.8, price=price)
        self.bar_count += 1

    def on_finish(self):
        print(f"final_equity={self.broker.get_total_equity():.2f}")
        print(f"bar_count={self.bar_count}")


def run_strategy():
    exchange = Exchange()
    exchange.add_feed(
        BinanceKlineCsvFeed(
            root=CSV_ROOT,
            symbols=[SYMBOL],
            interval="1m",
            start=START,
            end=END,
        )
    )
    broker = Broker(initial_cash=10_000, fee_rate=0.001)
    strategy = CsvFeedStrategy(strategy_id="csv_feed", broker=broker)
    exchange.add_strategy(strategy)
    exchange.run()
    return strategy, broker


if __name__ == "__main__":
    strategy, _ = run_strategy()
    plt.plot(strategy.get_hist_equity())
    plt.title("CSV Feed Equity")
    plt.xlabel("Bar")
    plt.ylabel("Equity")
    plt.show()
