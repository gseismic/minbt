import matplotlib.pyplot as plt

from minbt import Broker, Exchange, Strategy

SYMBOL = "BTCUSDT"


def build_sample_data():
    return [
        {"dt": "2026-05-01", "symbol": SYMBOL, "close": 100.0},
        {"dt": "2026-05-02", "symbol": SYMBOL, "close": 99.0},
        {"dt": "2026-05-03", "symbol": SYMBOL, "close": 96.0},
        {"dt": "2026-05-04", "symbol": SYMBOL, "close": 94.0},
        {"dt": "2026-05-05", "symbol": SYMBOL, "close": 97.0},
        {"dt": "2026-05-06", "symbol": SYMBOL, "close": 105.0},
    ]


class LimitOrderStrategy(Strategy):
    """限价单示例：撤销一个挂单，另一个成交后通过止盈退出。"""

    def on_init(self):
        self.limit_order = None
        self.canceled_order = None
        self.position_log = []

    def on_bars(self, dt, bars):
        price = bars[SYMBOL]["close"]
        if self.limit_order is None:
            self.limit_order = self.broker.submit_limit_order(
                SYMBOL,
                qty=1,
                limit_price=95,
                stop_loss_price=90,
                take_profit_price=104,
            )
            self.canceled_order = self.broker.submit_limit_order(SYMBOL, qty=1, limit_price=97)
        elif self.canceled_order.status == "pending":
            # 在价格跌至 97 前撤单，后续即使到价也不会成交。
            self.broker.cancel_order(self.canceled_order.id)
        self.position_log.append((dt, price, self.broker.get_position_size(SYMBOL)))

    def on_finish(self):
        print(f"final_equity={self.broker.get_total_equity():.2f}")
        print(f"limit_order_status={self.limit_order.status}")
        print(f"canceled_order_status={self.canceled_order.status}")
        print(f"final_position={self.broker.get_position_size(SYMBOL):.6f}")
        print(f"position_log={self.position_log}")


def run_strategy():
    exchange = Exchange()
    exchange.set_bars(build_sample_data())

    broker = Broker(initial_cash=1_000, fee_rate=0)
    strategy = LimitOrderStrategy(strategy_id="scenario_limit_order", broker=broker)

    exchange.add_strategy(strategy)
    exchange.run()

    return strategy, broker


if __name__ == "__main__":
    strategy, _ = run_strategy()
    plt.plot(strategy.get_hist_equity())
    plt.title("Limit Order Equity")
    plt.xlabel("Bar")
    plt.ylabel("Equity")
    plt.show()
