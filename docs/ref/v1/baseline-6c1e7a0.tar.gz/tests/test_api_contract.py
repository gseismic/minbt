import inspect
from importlib.util import find_spec

import minbt
import minbt.broker as broker_package
import minbt.plugins.binance as binance_package
import minbt.plugins.storage as storage_package
import pytest
from minbt import Broker, Exchange, ExitConfig, Strategy


POSITIONAL = inspect.Parameter.POSITIONAL_OR_KEYWORD
KEYWORD_ONLY = inspect.Parameter.KEYWORD_ONLY


def test_retired_data_bars_module_is_removed():
    """R8-13：具体读取器只保留插件入口，不再分发失效的旧转发模块。"""
    assert find_spec("minbt.data.bars") is None
    assert storage_package.CsvBarFeed.__module__ == "minbt.plugins.storage.bar_feed"


def _parameters(callable_obj):
    return {
        name: parameter
        for name, parameter in inspect.signature(callable_obj).parameters.items()
        if name != "self"
    }


def _assert_parameter_contract(callable_obj, positional, keyword_only):
    parameters = _parameters(callable_obj)
    assert list(parameters) == [*positional, *keyword_only]
    assert all(parameters[name].kind is POSITIONAL for name in positional)
    assert all(parameters[name].kind is KEYWORD_ONLY for name in keyword_only)


def test_exchange_public_signatures_match_design():
    _assert_parameter_contract(
        Exchange.set_bars,
        ["data"],
        ["date_key", "symbol_key", "feed_priority"],
    )
    _assert_parameter_contract(
        Exchange.set_books,
        ["data"],
        ["date_key", "symbol_key", "feed_priority"],
    )
    _assert_parameter_contract(
        Exchange.set_trades,
        ["data"],
        ["date_key", "symbol_key", "feed_priority"],
    )
    _assert_parameter_contract(Exchange.set_news, ["data"], ["date_key", "symbol_key", "feed_priority"])
    _assert_parameter_contract(Exchange.add_feed, ["feed"], ["feed_priority"])
    _assert_parameter_contract(Exchange.run, [], ["start", "end", "control", "load_mode"])
    assert not hasattr(Exchange, "set_data")


def test_bar_feed_names_separate_generic_storage_from_binance_kline_format():
    assert hasattr(storage_package, "CsvBarFeed")
    assert hasattr(storage_package, "IosqlBarFeed")
    assert hasattr(binance_package, "BinanceKlineCsvFeed")
    assert hasattr(binance_package, "BinanceKlineIosqlFeed")
    assert hasattr(binance_package, "BinanceKlineFeed")
    assert not hasattr(storage_package, "CsvBarsFeed")
    assert not hasattr(storage_package, "IosqlBarsFeed")
    assert not hasattr(binance_package, "BarsReplayFeed")


def test_broker_constructor_signature_matches_design():
    _assert_parameter_contract(
        Broker.__init__,
        ["initial_cash", "fee_rate"],
        [
            "leverage",
            "margin_mode",
            "warning_margin_level",
            "min_margin_level",
            "market",
            "mark_price",
            "mark_price_aggregation",
            "mark_price_missing",
            "logger",
        ],
    )
    parameters = _parameters(Broker.__init__)
    assert parameters["leverage"].default == 1.0
    assert parameters["margin_mode"].default == "cross"
    assert parameters["warning_margin_level"].default == 0.2
    assert parameters["min_margin_level"].default == 0.1
    assert parameters["market"].default is None
    assert parameters["mark_price"].default == "kline.close"
    assert parameters["mark_price_aggregation"].default == "error"
    assert parameters["mark_price_missing"].default == "keep"
    assert parameters["logger"].default is None
    assert "mark_price_source" not in parameters


def test_broker_order_signatures_match_design():
    exit_parameters = [
        "stop_loss_price",
        "take_profit_price",
        "trailing_stop_pct",
        "trailing_stop_amount",
    ]
    _assert_parameter_contract(
        Broker.submit_market_order,
        ["symbol", "qty", "price"],
        ["leverage", "price_dt", "portfolio", *exit_parameters],
    )
    _assert_parameter_contract(
        Broker.submit_limit_order,
        ["symbol", "qty", "limit_price"],
        ["price_dt", "portfolio", *exit_parameters],
    )
    for method, target_name in (
        (Broker.order_target_size, "target_size"),
        (Broker.order_target_value, "target_value"),
        (Broker.order_target_percent, "target_percent"),
    ):
        _assert_parameter_contract(
            method,
            ["symbol", target_name, "price"],
            ["leverage", "price_dt", "portfolio", *exit_parameters],
        )
    _assert_parameter_contract(
        Broker.close_position,
        ["symbol", "price"],
        ["price_dt", "portfolio"],
    )
    _assert_parameter_contract(Broker.close_portfolio, ["portfolio"], [])
    assert _parameters(Broker.close_portfolio)["portfolio"].default is inspect.Parameter.empty


def test_broker_exit_signatures_match_design():
    _assert_parameter_contract(
        Broker.set_exit,
        ["order_id"],
        [
            "stop_loss_price",
            "take_profit_price",
            "trailing_stop_pct",
            "trailing_stop_amount",
        ],
    )
    _assert_parameter_contract(
        Broker.clear_exit,
        ["order_id"],
        ["stop_loss_price", "take_profit_price", "trailing_stop", "custom"],
    )
    _assert_parameter_contract(
        Broker.add_exit,
        ["order_id"],
        ["name", "condition", "state"],
    )
    _assert_parameter_contract(Broker.get_exit, ["order_id"], [])


def test_broker_query_signatures_match_design():
    _assert_parameter_contract(Broker.add_market, ["name", "market", "symbols"], [])
    _assert_parameter_contract(Broker.get_market, ["symbol"], [])
    _assert_parameter_contract(Broker.get_order, ["order_id"], [])
    _assert_parameter_contract(Broker.get_orders, [], ["portfolio", "symbol"])
    _assert_parameter_contract(
        Broker.get_active_order,
        ["symbol"],
        ["portfolio"],
    )
    _assert_parameter_contract(Broker.get_equity, ["portfolio"], [])
    _assert_parameter_contract(Broker.get_cash, ["portfolio", "include_locked"], [])
    _assert_parameter_contract(Broker.get_position, ["symbol", "portfolio"], [])
    _assert_parameter_contract(Broker.get_position_size, ["symbol", "portfolio"], [])
    _assert_parameter_contract(Broker.get_position_sizes, ["portfolio"], [])
    _assert_parameter_contract(Broker.get_positions, ["portfolio"], [])
    _assert_parameter_contract(Broker.get_total_pnl, ["symbol"], [])
    _assert_parameter_contract(Broker.get_pnl, ["symbol"], ["portfolio"])
    _assert_parameter_contract(Broker.get_pnl_records, [], ["portfolio", "symbol", "order_id"])


def test_broker_does_not_expose_mutable_market_attribute():
    broker = Broker(initial_cash=1000, fee_rate=0)

    assert not hasattr(broker, "market")


def test_public_defaults_match_design():
    bars = _parameters(Exchange.set_bars)
    assert bars["date_key"].default == "dt"
    assert bars["symbol_key"].default == "symbol"
    assert bars["feed_priority"].default == 0

    market_order = _parameters(Broker.submit_market_order)
    assert market_order["price"].default is None
    assert market_order["leverage"].default is None
    assert market_order["price_dt"].default is None
    assert market_order["portfolio"].default is None

    cash = _parameters(Broker.get_cash)
    assert cash["portfolio"].default is None
    assert cash["include_locked"].default is False

    clear_exit = _parameters(Broker.clear_exit)
    assert all(
        clear_exit[name].default is True
        for name in ("stop_loss_price", "take_profit_price", "trailing_stop", "custom")
    )


def test_internal_control_parameters_are_not_public():
    for method in (
        Broker.submit_market_order,
        Broker.submit_limit_order,
        Broker.order_target_size,
        Broker.order_target_value,
        Broker.order_target_percent,
    ):
        parameters = _parameters(method)
        assert "source" not in parameters
        assert "normalize_qty" not in parameters
        assert "create_if_missing" not in parameters


def test_internal_broker_models_are_not_recommended_exports():
    assert "Portfolio" not in broker_package.__all__
    assert "Cash" not in broker_package.__all__
    assert "Position" not in broker_package.__all__


def test_strategy_and_package_do_not_export_legacy_entry_points():
    for name in ("on_data", "market_buy", "market_sell", "market_order"):
        assert not hasattr(Strategy, name)
    for name in ("MarketModel", "SimpleMarket", "CryptoMarket", "ChinaAStockMarket"):
        assert not hasattr(minbt, name)
    for name in ("I18nLogger", "configure_logging", "disable_logging", "create_logger"):
        assert not hasattr(minbt, name)


def test_exit_config_fields_match_design():
    assert list(ExitConfig.__dataclass_fields__) == [
        "order_id",
        "symbol",
        "portfolio",
        "active",
        "stop_loss_price",
        "take_profit_price",
        "trailing_stop_pct",
        "trailing_stop_amount",
        "trailing_anchor",
        "custom_rules",
    ]


def test_get_active_order_rejects_unknown_portfolio():
    broker = Broker(initial_cash=1000, fee_rate=0)

    with pytest.raises(ValueError, match="portfolio not found"):
        broker.get_active_order("TEST", portfolio="missing")
